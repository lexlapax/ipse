defmodule Ipse.MCP.HTTPTest do
  use ExUnit.Case, async: false
  alias Ipse.MCP
  alias Ipse.MCP.Config

  defmodule Model do
    def complete(_, messages, _tools, _emit) do
      if Enum.any?(messages, &(&1["role"] == "tool")) do
        {:ok, %{"role" => "assistant", "content" => "Finished"}, %{}}
      else
        calls =
          for n <- 1..2,
              do: %{
                "id" => "network-#{n}",
                "type" => "function",
                "function" => %{
                  "name" => "mcp__remote__write",
                  "arguments" => Jason.encode!(%{"text" => "synthetic"})
                }
              }

        {:ok, %{"role" => "assistant", "content" => "", "tool_calls" => calls}, %{}}
      end
    end
  end

  defmodule DiscoveryOwner do
    use GenServer
    def init({observer, job}), do: {:ok, {observer, job}}

    def handle_call({:mcp_register, job, transport}, _, {observer, job} = state) do
      send(observer, {:discovery_transport, transport})
      {:reply, :ok, state}
    end
  end

  setup do
    root = Path.join(System.tmp_dir!(), "ipse-http-mcp-#{System.unique_integer([:positive])}")
    File.mkdir_p!(root)
    previous = System.get_env("IPSE_MCP_FIXTURE_TOKEN")
    System.put_env("IPSE_MCP_FIXTURE_TOKEN", "synthetic-bearer-token")

    on_exit(fn ->
      if previous,
        do: System.put_env("IPSE_MCP_FIXTURE_TOKEN", previous),
        else: System.delete_env("IPSE_MCP_FIXTURE_TOKEN")

      File.rm_rf!(root)
    end)

    %{root: root}
  end

  test "explicit HTTP configuration binds endpoint/auth identity without persisting tokens",
       ctx do
    path = Path.join(ctx.root, "config.json")

    entry = %{
      "id" => "remote",
      "transport" => "http",
      "url" => "https://example.test/mcp",
      "tools" => ["write"],
      "bearer_env" => "IPSE_MCP_FIXTURE_TOKEN"
    }

    File.write!(path, Jason.encode!(%{"servers" => [entry]}))
    assert {:ok, [first]} = Config.load(path)
    refute inspect(Config.manifest(first)) =~ "synthetic-bearer-token"
    assert Config.manifest(first).endpoint == entry["url"]
    System.put_env("IPSE_MCP_FIXTURE_TOKEN", "rotated-fixture-token")
    assert {:ok, [rotated]} = Config.load(path)
    assert first.fingerprint == rotated.fingerprint

    for invalid <- [
          Map.put(entry, "url", "http://example.test/mcp"),
          Map.put(entry, "url", "https://user:password@example.test/mcp"),
          Map.put(entry, "url", "https://example.test/mcp?token=x"),
          Map.put(entry, "url", "https://example.test/mcp#fragment"),
          Map.put(entry, "bearer_env", "OPENAI_API_KEY"),
          Map.put(entry, "sandbox", "native"),
          Map.put(entry, "command", "/bin/sh"),
          Map.put(entry, "transport", "sse")
        ] do
      File.write!(path, Jason.encode!(%{"servers" => [invalid]}))
      assert {:error, _} = Config.load(path)
    end

    local = Map.put(entry, "url", "http://127.0.0.1:1234/mcp")
    File.write!(path, Jason.encode!(%{"servers" => [local]}))
    assert {:error, _} = Config.load(path)

    File.write!(
      path,
      Jason.encode!(%{"servers" => [Map.put(local, "allow_insecure_loopback", true)]})
    )

    assert {:ok, [_]} = Config.load(path)
  end

  for mode <- [:json, :sse] do
    test "#{mode} handles initialization, private session headers, exact calls and DELETE", ctx do
      {server, agent} = fixture(ctx, unquote(mode))
      assert {:ok, [tool]} = MCP.discover_server(server, ctx.root)
      assert {:ok, text} = MCP.call(tool, %{"text" => "synthetic"}, ctx.root)
      assert text =~ "synthetic"
      refute text =~ "synthetic-bearer-token"
      refute text =~ "fixture-session-token"
      requests = Agent.get(agent, & &1.requests)
      assert Enum.count(requests, &(&1.method == "DELETE")) == 2

      assert Enum.all?(
               requests,
               &(&1.headers["authorization"] == "Bearer synthetic-bearer-token")
             )

      assert Enum.all?(requests, &(&1.headers["mcp-protocol-version"] == "2025-11-25"))

      assert Enum.all?(requests, fn request ->
               if request.rpc["method"] == "initialize",
                 do: is_nil(request.headers["mcp-session-id"]),
                 else: request.headers["mcp-session-id"] == "fixture-session-token"
             end)
    end
  end

  @tag :discovery_unknown
  test "bulk discovery retains local transport-loss uncertainty and never starts the next server",
       ctx do
    {uncertain, first} = fixture(ctx, :hold_initialize)
    {later, second} = fixture(ctx, :json)
    job = make_ref()
    {:ok, owner} = GenServer.start_link(DiscoveryOwner, {self(), job})
    on_exit(fn -> if Process.alive?(owner), do: GenServer.stop(owner) end)

    task =
      Task.async(fn ->
        MCP.discover([uncertain, later], ctx.root, %{owner: owner, job_ref: job})
      end)

    assert_receive {:discovery_transport, transport}, 3000
    assert_receive {:http_initialization_held, peer}, 3000
    Process.exit(transport, :kill)
    assert {:unknown, message} = Task.await(task, 5000)
    assert_receive {:http_initialization_closed, ^peer}, 3000
    assert message =~ "unknown"
    refute message =~ "synthetic-bearer-token"
    refute message =~ "fixture-session-token"
    requests = Agent.get(first, & &1.requests)
    assert Enum.count(requests, &(&1.rpc["method"] == "initialize")) == 1
    assert Enum.count(requests, &(&1.method == "DELETE")) == 0
    assert Agent.get(second, & &1.requests) == []

    assert {:ok, [_]} = MCP.discover([later], ctx.root)
    assert Enum.count(Agent.get(second, & &1.requests), &(&1.rpc["method"] == "initialize")) == 1
  end

  @tag :discovery_unknown_session
  test "draft discovery preserves unknown setup and resumes without starting discovery again",
       ctx do
    {server, agent} = fixture(ctx, :hold_initialize)
    {pid, opts} = session(ctx, server, :ask)
    id = Ipse.Session.info(pid).id
    assert :ok = Ipse.Session.start_draft(pid, "Synthetic draft with uncertain discovery")
    assert_receive {:http_initialization_held, peer}, 5000
    [transport] = Map.keys(:sys.get_state(pid).mcp_resources)
    Process.exit(transport, :kill)
    assert_receive {:ipse, ^pid, {:error, message}}, 10_000
    assert message =~ "cleanup could not be confirmed"
    refute message =~ "Unexpected worker result"
    assert_receive {:ipse, ^pid, {:done, :error}}, 3000
    assert_receive {:http_initialization_closed, ^peer}, 3000
    if Process.alive?(pid), do: Ipse.Session.close_confirmed(pid)
    assert {:ok, events} = Ipse.Journal.load(opts[:state_dir], id)

    [pending] = Enum.filter(events, &(&1["type"] == "draft_mcp_setup_intent"))
    refute Enum.any?(events, &(&1["type"] == "draft_mcp_setup_result"))
    refute Enum.any?(events, &(&1["type"] == "mcp_catalog"))
    assert {:ok, saved} = Ipse.Session.Saved.restore(events, id)
    assert saved.draft_mcp_interrupted
    assert saved.draft_mcp_pending == pending
    before = Agent.get(agent, & &1.requests)

    assert {:ok, resumed} =
             DynamicSupervisor.start_child(
               Ipse.Sessions,
               {Ipse.Session, Keyword.put(opts, :id, id)}
             )

    assert Ipse.Session.info(resumed).phase == :idle
    assert Agent.get(agent, & &1.requests) == before
    assert {:ok, after_resume} = Ipse.Journal.load(opts[:state_dir], id)
    assert Enum.count(after_resume, &(&1["type"] == "draft_mcp_setup_intent")) == 1
    assert :ok = Ipse.Session.close_confirmed(resumed)
  end

  @tag :extension_discovery_unknown
  test "extension discovery retains transport uncertainty without a tool call", ctx do
    {server, first} = fixture(ctx, :hold_initialize)
    job = make_ref()
    {:ok, owner} = GenServer.start_link(DiscoveryOwner, {self(), job})
    on_exit(fn -> if Process.alive?(owner), do: GenServer.stop(owner) end)
    resource = %{owner: owner, job_ref: job}

    request = %{
      "op" => "mcp.call",
      "version" => 1,
      "binding" => "documents",
      "arguments" => %{"text" => "synthetic"},
      "timeout_ms" => 3000
    }

    tool = Config.tool_id(server.id, "write")
    assert :ok = Ipse.Extension.MCPCall.validate(request)

    assert {:error, :invalid_extension_mcp_call} =
             Ipse.Extension.MCPCall.discover(
               server,
               tool,
               Map.put(request, "version", 2),
               ctx.root,
               resource
             )

    assert Agent.get(first, & &1.requests) == []

    task =
      Task.async(fn ->
        Ipse.Extension.MCPCall.discover(server, tool, request, ctx.root, resource)
      end)

    assert_receive {:discovery_transport, transport}, 3000
    assert_receive {:http_initialization_held, peer}, 3000
    Process.exit(transport, :kill)
    assert {:unknown, %{}} = Task.await(task, 5000)
    assert_receive {:http_initialization_closed, ^peer}, 3000
    requests = Agent.get(first, & &1.requests)
    assert Enum.count(requests, &(&1.rpc["method"] == "initialize")) == 1
    assert Enum.all?(requests, &(&1.rpc["method"] != "tools/call"))

    {healthy, second} = fixture(ctx, :json)

    assert {:ok, descriptor, public} =
             Ipse.Extension.MCPCall.discover(
               healthy,
               Config.tool_id(healthy.id, "write"),
               request,
               ctx.root,
               resource
             )

    assert descriptor.server == healthy
    assert public["alias"] == "documents"
    refute inspect(public) =~ "synthetic-bearer-token"
    refute inspect(public) =~ "fixture-session-token"
    assert Agent.get(second, & &1.calls) == 0
  end

  test "authentication, redirects, oversized bodies/headers and malformed streams fail closed",
       ctx do
    for mode <- [
          :unauthorized,
          :redirect,
          :huge_body,
          :huge_error,
          :huge_headers,
          :bad_sse,
          :mixed_sse,
          :wrong_id,
          :only_ping,
          :changed_session
        ] do
      {server, agent} = fixture(ctx, mode)
      result = MCP.discover_server(server, ctx.root)
      assert match?({:error, _}, result) or match?({:unknown, _}, result)
      refute inspect(result) =~ "synthetic-bearer-token"
      if mode == :redirect, do: assert(length(Agent.get(agent, & &1.requests)) == 1)
    end
  end

  test "descriptor drift prevents dispatch", ctx do
    {server, agent} = fixture(ctx, :drift)
    assert {:ok, [tool]} = MCP.discover_server(server, ctx.root)
    assert {:error, message} = MCP.call(tool, %{"text" => "synthetic"}, ctx.root)
    assert message =~ "changed"
    assert Agent.get(agent, & &1.calls) == 0
  end

  test "HTTP preserves exact resource and prompt selection through the shared catalog", ctx do
    {server, _} = fixture(ctx, :catalog)
    assert {:ok, descriptors} = MCP.discover_server(server, ctx.root)
    assert length(descriptors) == 3
    resource = Enum.find(descriptors, &(Map.get(&1, :kind) == :resource))
    prompt = Enum.find(descriptors, &(Map.get(&1, :kind) == :prompt))
    assert {:ok, text} = MCP.call(resource, %{}, ctx.root)
    assert text =~ "Synthetic resource data"
    assert {:ok, text} = MCP.call(prompt, %{"topic" => "synthetic"}, ctx.root)
    assert text =~ "Synthetic prompt data: synthetic"
  end

  test "ordinary HTTP tool errors retain diagnostics and possible effects without idle replay",
       ctx do
    {server, agent} = fixture(ctx, :tool_error)
    {pid, opts} = session(ctx, server, :allow)
    :ok = Ipse.Session.prompt(pid, "Synthetic network write")
    assert_receive {:ipse, ^pid, {:done, :ok}}, 5000
    assert Agent.get(agent, & &1.calls) == 2
    id = Ipse.Session.info(pid).id
    assert {:ok, events} = Ipse.Journal.load(opts[:state_dir], id)

    messages =
      for event <- events, get_in(event, ["message", "role"]) == "tool", do: event["message"]

    assert length(messages) == 2

    for message <- messages do
      assert message["ipse_tool_outcome"]["status"] == "error"
      assert message["content"] =~ "Effects may have happened"
      assert message["content"] =~ "synthetic"
      refute message["content"] =~ "synthetic-bearer-token"
    end

    assert :ok = Ipse.Session.close_confirmed(pid)

    assert {:ok, resumed} =
             DynamicSupervisor.start_child(
               Ipse.Sessions,
               {Ipse.Session, Keyword.put(opts, :id, id)}
             )

    assert Ipse.Session.info(resumed).phase == :idle
    assert Agent.get(agent, & &1.calls) == 2
    assert :ok = Ipse.Session.close_confirmed(resumed)
  end

  test "post-dispatch disconnect is unknown, stops the batch and never replays on resume", ctx do
    {server, agent} = fixture(ctx, :disconnect)
    {pid, opts} = session(ctx, server, :allow)
    :ok = Ipse.Session.prompt(pid, "Synthetic network write")
    assert_receive {:ipse, ^pid, {:done, :error}}, 5000
    assert Agent.get(agent, & &1.calls) == 1
    id = Ipse.Session.info(pid).id
    {:ok, events} = Ipse.Journal.load(opts[:state_dir], id)

    outcomes =
      for e <- events,
          get_in(e, ["message", "role"]) == "tool",
          do: get_in(e, ["message", "ipse_tool_outcome", "status"])

    assert outcomes == ["unknown", "not_started"]
    :ok = Ipse.Session.close(pid)
    {:ok, closed_events} = Ipse.Journal.load(opts[:state_dir], id)
    assert Enum.take(closed_events, length(events)) == events

    assert [
             %{
               "type" => "lifecycle_epoch_closed",
               "session_id" => ^id,
               "closure" => "close",
               "cleanup_confirmed" => true
             }
           ] = Enum.drop(closed_events, length(events))

    {:ok, resumed} =
      DynamicSupervisor.start_child(Ipse.Sessions, {Ipse.Session, Keyword.put(opts, :id, id)})

    assert {:ok, ^closed_events} = Ipse.Journal.load(opts[:state_dir], id)
    :ok = Ipse.Session.close(resumed)
    assert Agent.get(agent, & &1.calls) == 1
  end

  test "HTTP calls retain full approvals and headless denial", ctx do
    {server, agent} = fixture(ctx, :json)
    {denied, _} = session(ctx, server, :deny)
    :ok = Ipse.Session.prompt(denied, "Denied network effects")
    assert_receive {:ipse, ^denied, {:done, :ok}}, 5000
    assert Agent.get(agent, & &1.calls) == 0
    {pid, opts} = session(ctx, server, :ask)
    :ok = Ipse.Session.prompt(pid, "Approved network effects")

    for _ <- 1..2 do
      assert_receive {:ipse, ^pid,
                      {:approval, ref, "mcp__remote__write", %{"text" => "synthetic"}}},
                     5000

      :ok = Ipse.Session.approve(pid, ref, true)
    end

    assert_receive {:ipse, ^pid, {:done, :ok}}, 5000
    assert Agent.get(agent, & &1.calls) == 2
    {:ok, events} = Ipse.Journal.load(opts[:state_dir], Ipse.Session.info(pid).id)

    assert Enum.all?(
             Enum.filter(events, &(&1["type"] == "tool_started")),
             &(get_in(&1, ["mcp", "origin", "transport"]) == "streamable_http" and
                 &1["approval"] == "approved")
           )
  end

  test "cancel and owner death close private network clients after dispatch", ctx do
    for action <- [:cancel, :death] do
      {server, _} = fixture(ctx, :hold)
      {pid, _} = session(ctx, server, :allow)
      :ok = Ipse.Session.prompt(pid, "Wait for network response")
      assert_receive {:http_dispatched, handler}, 5000

      if action == :cancel,
        do: assert(:ok == Ipse.Session.cancel(pid)),
        else: Process.exit(pid, :kill)

      assert_receive {:http_socket_closed, ^handler}, 3000
    end
  end

  test "abrupt request worker death waits for its private pool guardian before confirming cleanup",
       ctx do
    {server, _} = fixture(ctx, :hold)

    {:ok, transport} =
      Ipse.MCP.HTTPTransport.start_link(owner: self(), cleanup_owner: self(), server: server)

    :ok =
      Ipse.MCP.HTTPTransport.send_message(transport, %{
        "jsonrpc" => "2.0",
        "id" => 1,
        "method" => "initialize",
        "params" => %{}
      })

    assert_receive {:mcp_message, %{"id" => 1}}, 5000

    :ok =
      Ipse.MCP.HTTPTransport.send_message(transport, %{
        "jsonrpc" => "2.0",
        "id" => 2,
        "method" => "tools/call",
        "params" => %{"name" => "write", "arguments" => %{"text" => "synthetic"}}
      })

    assert_receive {:http_dispatched, handler}, 5000
    worker = :sys.get_state(transport).task.pid
    guardian = Ipse.HTTP.finch_guardian(worker)
    assert is_pid(guardian)
    :erlang.suspend_process(guardian)

    try do
      Process.exit(worker, :kill)
      assert_receive {:mcp_transport_closed, :http_worker_stopped}, 2000
      refute_receive {:mcp_cleanup, ^transport, _}, 100
    after
      :erlang.resume_process(guardian)
    end

    assert_receive {:mcp_cleanup, ^transport, :ok}, 3000
    refute Process.alive?(guardian)
    assert_receive {:http_socket_closed, ^handler}, 3000
  end

  defp session(ctx, server, approval) do
    opts = [
      cwd: ctx.root,
      state_dir: Path.join(ctx.root, "sessions"),
      subscriber: self(),
      config: %{
        provider: :demo,
        model: "fixture",
        provider_module: Model,
        home: Path.join(ctx.root, "home"),
        mcp_servers: [server],
        approval: approval
      }
    ]

    {:ok, pid} = DynamicSupervisor.start_child(Ipse.Sessions, {Ipse.Session, opts})
    on_exit(fn -> if Process.alive?(pid), do: Ipse.Session.close(pid) end)
    {pid, opts}
  end

  defp fixture(ctx, mode) do
    test = self()
    {:ok, agent} = Agent.start_link(fn -> %{requests: [], calls: 0, lists: 0} end)
    {:ok, sup} = Task.Supervisor.start_link()

    {:ok, listener} =
      :gen_tcp.listen(0, [:binary, active: false, reuseaddr: true, ip: {127, 0, 0, 1}])

    {:ok, {_, port}} = :inet.sockname(listener)
    Task.Supervisor.start_child(sup, fn -> accept(listener, sup, agent, mode, test) end)

    on_exit(fn ->
      :gen_tcp.close(listener)
      stop_fixture(sup)
      stop_fixture(agent)
    end)

    path = Path.join(ctx.root, "config-#{port}.json")

    File.write!(
      path,
      Jason.encode!(%{
        "servers" => [
          %{
            "id" => if(mode == :hold_initialize, do: "holding", else: "remote"),
            "transport" => "http",
            "url" => "http://127.0.0.1:#{port}/mcp",
            "allow_insecure_loopback" => true,
            "tools" => ["write"],
            "resources" => if(mode == :catalog, do: ["fixture://guide"], else: []),
            "prompts" => if(mode == :catalog, do: ["summarize"], else: []),
            "bearer_env" => "IPSE_MCP_FIXTURE_TOKEN",
            "timeout_ms" => 5000
          }
        ]
      })
    )

    {:ok, [server]} = Config.load(path)
    {server, agent}
  end

  defp accept(listener, sup, agent, mode, test) do
    case :gen_tcp.accept(listener) do
      {:ok, socket} ->
        {:ok, worker} =
          Task.Supervisor.start_child(sup, fn ->
            receive do
              :serve -> serve(socket, agent, mode, test)
            end
          end)

        :ok = :gen_tcp.controlling_process(socket, worker)
        send(worker, :serve)
        accept(listener, sup, agent, mode, test)

      _ ->
        :ok
    end
  end

  defp serve(socket, agent, mode, test, transport \\ :gen_tcp) do
    try do
      {method, headers, rpc} = read_request(socket, "", transport)

      count =
        Agent.get_and_update(agent, fn s ->
          next = %{
            s
            | requests: s.requests ++ [%{method: method, headers: headers, rpc: rpc}],
              calls: s.calls + if(rpc["method"] == "tools/call", do: 1, else: 0),
              lists: s.lists + if(rpc["method"] == "tools/list", do: 1, else: 0)
          }

          {next.lists, next}
        end)

      result =
        case rpc["method"] do
          "initialize" ->
            %{
              "protocolVersion" => "2025-11-25",
              "capabilities" => %{"tools" => %{}, "resources" => %{}, "prompts" => %{}},
              "serverInfo" => %{"name" => "fixture", "version" => "1"}
            }

          "tools/list" ->
            %{
              "tools" => [
                %{
                  "name" => "write",
                  "description" =>
                    if(mode == :drift and count > 1, do: "changed", else: "stable"),
                  "inputSchema" => %{
                    "type" => "object",
                    "properties" => %{"text" => %{"type" => "string"}},
                    "required" => ["text"]
                  }
                }
              ]
            }

          "resources/list" ->
            %{
              "resources" => [
                %{"uri" => "fixture://guide", "name" => "guide", "mimeType" => "text/plain"}
              ]
            }

          "resources/read" ->
            %{
              "contents" => [
                %{
                  "uri" => "fixture://guide",
                  "mimeType" => "text/plain",
                  "text" => "Synthetic resource data"
                }
              ]
            }

          "prompts/list" ->
            %{
              "prompts" => [
                %{
                  "name" => "summarize",
                  "arguments" => [%{"name" => "topic", "required" => true}]
                }
              ]
            }

          "prompts/get" ->
            %{
              "messages" => [
                %{
                  "role" => "user",
                  "content" => %{
                    "type" => "text",
                    "text" => "Synthetic prompt data: " <> rpc["params"]["arguments"]["topic"]
                  }
                }
              ]
            }

          "tools/call" ->
            %{
              "isError" => mode == :tool_error,
              "content" => [
                %{
                  "type" => "text",
                  "text" => "synthetic synthetic-bearer-token fixture-session-token"
                }
              ]
            }

          _ ->
            %{}
        end

      if rpc["method"] == "tools/call" and mode in [:disconnect, :hold] do
        if mode == :hold do
          send(test, {:http_dispatched, self()})
          {:error, :closed} = transport.recv(socket, 0, 5000)
          send(test, {:http_socket_closed, self()})
        end
      else
        if rpc["method"] == "initialize" and mode == :hold_initialize do
          send(test, {:http_initialization_held, self()})
          {:error, :closed} = transport.recv(socket, 0, 5000)
          send(test, {:http_initialization_closed, self()})
        else
          response(socket, method, rpc, result, mode, transport)
        end
      end
    after
      transport.close(socket)
    end
  end

  defp response(socket, method, rpc, result, mode, transport) do
    status =
      cond do
        mode == :unauthorized -> 401
        mode == :redirect -> 302
        mode == :huge_error -> 401
        method == "DELETE" or is_nil(rpc["id"]) -> 202
        true -> 200
      end

    envelope = %{
      "jsonrpc" => "2.0",
      "id" => if(mode == :wrong_id, do: rpc["id"] + 99, else: rpc["id"]),
      "result" => result
    }

    body =
      cond do
        status == 202 ->
          ""

        mode in [:huge_body, :huge_error] ->
          String.duplicate("x", 262_145)

        mode == :only_ping ->
          "data: " <>
            Jason.encode!(%{"jsonrpc" => "2.0", "id" => "ping", "method" => "ping"}) <> "\n\n"

        mode in [:sse, :bad_sse, :mixed_sse] ->
          "data: " <>
            Jason.encode!(envelope) <>
            if(mode == :bad_sse, do: "\n", else: "\n\n") <>
            if(mode == :mixed_sse, do: "data: invalid\n\n", else: "")

        true ->
          Jason.encode!(envelope)
      end

    type =
      if mode in [:sse, :bad_sse, :mixed_sse, :only_ping],
        do: "text/event-stream",
        else: "application/json"

    session_id =
      if mode == :changed_session and rpc["method"] != "initialize",
        do: "changed-token",
        else: "fixture-session-token"

    extra = if mode == :huge_headers, do: "x-big: #{String.duplicate("x", 17000)}\r\n", else: ""

    socket_info = if transport == :gen_tcp, do: :inet, else: :ssl
    {:ok, {_, port}} = socket_info.sockname(socket)

    extra =
      extra <>
        if(mode == :redirect, do: "location: http://127.0.0.1:#{port}/redirected\r\n", else: "")

    transport.send(
      socket,
      "HTTP/1.1 #{status} Fixture\r\ncontent-type: #{type}\r\nmcp-session-id: #{session_id}\r\n#{extra}content-length: #{byte_size(body)}\r\nconnection: close\r\n\r\n"
    )

    transport.send(socket, body)
  end

  defp read_request(socket, buffer, transport) do
    case :binary.split(buffer, "\r\n\r\n") do
      [raw, body] ->
        [first | lines] = String.split(raw, "\r\n")

        headers =
          Map.new(lines, fn line ->
            [key, value] = String.split(line, ":", parts: 2)
            {String.downcase(key), String.trim(value)}
          end)

        size = String.to_integer(headers["content-length"] || "0")
        body = read_body(socket, body, size, transport)
        method = hd(String.split(first, " "))
        {method, headers, if(body == "", do: %{}, else: Jason.decode!(body))}

      [_] ->
        {:ok, bytes} = transport.recv(socket, 0, 5000)
        read_request(socket, buffer <> bytes, transport)
    end
  end

  defp read_body(_, body, size, _transport) when byte_size(body) >= size, do: body

  defp read_body(socket, body, size, transport) do
    {:ok, bytes} = transport.recv(socket, 0, 5000)
    read_body(socket, body <> bytes, size, transport)
  end

  defp stop_fixture(pid) do
    monitor = Process.monitor(pid)

    try do
      GenServer.stop(pid)
    catch
      :exit, _ -> if Process.alive?(pid), do: Process.exit(pid, :kill)
    end

    receive do
      {:DOWN, ^monitor, :process, ^pid, _} -> :ok
    after
      2000 -> raise "Fixture cleanup unconfirmed"
    end
  end

  test "HTTPS accepts a trusted matching hostname and rejects a trusted wrong hostname", ctx do
    certificate =
      :public_key.pkix_test_data(%{
        root: [digest: :sha256, key: {:rsa, 2048, 65537}],
        peer: [
          digest: :sha256,
          key: {:rsa, 2048, 65537},
          extensions: [{:Extension, {2, 5, 29, 17}, false, [{:dNSName, ~c"localhost"}]}]
        ]
      })

    original =
      Enum.map(:public_key.cacerts_get(), fn
        {:cert, der, _} -> der
        der when is_binary(der) -> der
      end)

    original_path = Path.join(ctx.root, "original-ca.pem")
    trusted_path = Path.join(ctx.root, "fixture-ca.pem")

    pem = fn certs ->
      :public_key.pem_encode(Enum.map(certs, &{:Certificate, &1, :not_encrypted}))
    end

    File.write!(original_path, pem.(original))
    File.write!(trusted_path, pem.(certificate[:cacerts]))
    :ok = :public_key.cacerts_load(trusted_path)

    try do
      for host <- ["localhost", "127.0.0.1"] do
        {:ok, agent} = Agent.start_link(fn -> %{requests: [], calls: 0, lists: 0} end)
        {:ok, supervisor} = Task.Supervisor.start_link()

        {:ok, listener} =
          :ssl.listen(
            0,
            [:binary, active: false, reuseaddr: true, ip: {127, 0, 0, 1}] ++ certificate
          )

        {:ok, {_, port}} = :ssl.sockname(listener)
        test = self()

        Task.Supervisor.start_child(supervisor, fn ->
          accept_tls(listener, supervisor, agent, test)
        end)

        try do
          path = Path.join(ctx.root, "trusted-tls.json")

          File.write!(
            path,
            Jason.encode!(%{
              "servers" => [
                %{
                  "id" => "remote",
                  "transport" => "http",
                  "url" => "https://#{host}:#{port}/mcp",
                  "tools" => ["write"],
                  "timeout_ms" => 3000
                }
              ]
            })
          )

          {:ok, [server]} = Config.load(path)

          if host == "localhost" do
            assert {:ok, [tool]} = MCP.discover_server(server, ctx.root)
            assert {:ok, _} = MCP.call(tool, %{"text" => "synthetic"}, ctx.root)
            assert Agent.get(agent, & &1.calls) == 1
          else
            assert {:error, _} = MCP.discover_server(server, ctx.root)

            assert_receive {:tls_fixture_failure, {:error, {:tls_alert, {alert, _}}}},
                           5000

            assert alert in [:bad_certificate, :handshake_failure]

            assert Agent.get(agent, & &1.requests) == []
          end
        after
          :ssl.close(listener)
          stop_fixture(supervisor)
          stop_fixture(agent)
        end
      end
    after
      :ok = :public_key.cacerts_load(original_path)
    end
  end

  defp accept_tls(listener, supervisor, agent, test) do
    case :ssl.transport_accept(listener) do
      {:ok, socket} ->
        {:ok, worker} =
          Task.Supervisor.start_child(supervisor, fn ->
            receive do
              :serve ->
                case :ssl.handshake(socket, 5000) do
                  {:ok, secure} ->
                    serve(secure, agent, :json, test, :ssl)

                  error ->
                    send(test, {:tls_fixture_failure, error})
                    :ssl.close(socket)
                end
            end
          end)

        :ok = :ssl.controlling_process(socket, worker)
        send(worker, :serve)
        accept_tls(listener, supervisor, agent, test)

      _ ->
        :ok
    end
  end

  test "HTTPS rejects an untrusted fixture certificate without dispatch", ctx do
    certificate =
      :public_key.pkix_test_data(%{
        root: [digest: :sha256, key: {:rsa, 2048, 65537}],
        peer: [digest: :sha256, key: {:rsa, 2048, 65537}]
      })

    {:ok, listener} =
      :ssl.listen(0, [:binary, active: false, reuseaddr: true, ip: {127, 0, 0, 1}] ++ certificate)

    {:ok, {_, port}} = :ssl.sockname(listener)

    handshake =
      Task.async(fn ->
        {:ok, socket} = :ssl.transport_accept(listener, 5000)
        result = :ssl.handshake(socket, 5000)
        :ssl.close(socket)
        result
      end)

    path = Path.join(ctx.root, "tls.json")

    File.write!(
      path,
      Jason.encode!(%{
        "servers" => [
          %{
            "id" => "remote",
            "transport" => "http",
            "url" => "https://127.0.0.1:#{port}/mcp",
            "tools" => ["write"],
            "timeout_ms" => 3000
          }
        ]
      })
    )

    {:ok, [server]} = Config.load(path)
    assert {:error, _} = MCP.discover_server(server, ctx.root)
    assert {:error, {:tls_alert, {:unknown_ca, _}}} = Task.await(handshake, 5000)
    :ssl.close(listener)
  end
end
