//! Private matched-tty lease probes. The inert mode writes no terminal bytes;
//! the synthetic display candidate has no production or Review call site.
use crate::ipse_lease_sink as sink;
use crate::ipse_owner_control as controls;
use std::fs::File;
use std::io::{self, Read, Write};
use std::os::fd::{AsRawFd, FromRawFd};
use std::os::unix::fs::MetadataExt;
use std::os::unix::net::UnixStream;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

#[repr(C)]
struct Poll {
    fd: i32,
    events: i16,
    revents: i16,
}
unsafe extern "C" {
    fn poll(fds: *mut Poll, count: usize, timeout: i32) -> i32;
    fn pipe2(fds: *mut i32, flags: i32) -> i32;
    fn fork() -> i32;
    fn kill(pid: i32, signal: i32) -> i32;
    fn waitpid(pid: i32, status: *mut i32, options: i32) -> i32;
    fn _exit(status: i32) -> !;
    #[cfg(ipse_terminal_display_test_hook)]
    fn raise(signal: i32) -> i32;
}
const INPUT: i16 = 1;
const OUTPUT: i16 = 4;
const BAD: i16 = 8 | 16 | 32;
fn err() -> String {
    "terminal lease probe unavailable".into()
}

fn wall_current(expiry: u64) -> bool {
    expiry > 0
        && expiry <= 9_007_199_254_740_991
        && SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .is_ok_and(|n| n.as_millis() < u128::from(expiry))
}

fn wait_reader_command(
    reader_control: &mut File,
    watched: &[i32],
    deadline: Instant,
    want: u8,
) -> bool {
    loop {
        let left = deadline.saturating_duration_since(Instant::now());
        if left.is_zero() {
            return false;
        }
        let mut fds = vec![Poll {
            fd: reader_control.as_raw_fd(),
            events: INPUT,
            revents: 0,
        }];
        fds.extend(watched.iter().map(|fd| Poll {
            fd: *fd,
            events: INPUT,
            revents: 0,
        }));
        let n = unsafe {
            poll(
                fds.as_mut_ptr(),
                fds.len(),
                left.as_millis().max(1).min(20) as i32,
            )
        };
        if n < 0 && io::Error::last_os_error().kind() == io::ErrorKind::Interrupted {
            continue;
        }
        if n < 0 || fds[0].revents & BAD != 0 || fds.iter().skip(1).any(|p| p.revents != 0) {
            return false;
        }
        if fds[0].revents & INPUT != 0 {
            let mut byte = [0u8; 1];
            return matches!(reader_control.read(&mut byte), Ok(1)) && byte == [want];
        }
    }
}

fn synthetic_write(
    tty: &mut File,
    control: i32,
    guardian: i32,
    watched: &[i32],
    payload: &[u8],
    expiry: u64,
    deadline: Instant,
) -> bool {
    let mut guards = watched.to_vec();
    guards.push(guardian);
    let mut at = 0;
    #[cfg(ipse_terminal_display_test_hook)]
    let mut prewrite_stop = std::env::var_os("IPSE_TEST_TTY_PREWRITE_STOP").is_some();
    while at < payload.len() {
        if !wall_current(expiry)
            || sink::ready_watch(tty.as_raw_fd(), OUTPUT, control, &guards, deadline).is_err()
            || !wall_current(expiry)
        {
            return false;
        }
        #[cfg(ipse_terminal_display_test_hook)]
        if prewrite_stop {
            prewrite_stop = false;
            unsafe {
                raise(19);
            }
        }
        match tty.write(&payload[at..(at + 4096).min(payload.len())]) {
            Ok(0) => return false,
            Ok(n) => {
                at += n;
                #[cfg(ipse_terminal_display_test_hook)]
                if at < payload.len() && std::env::var_os("IPSE_TEST_TTY_PARTIAL_STOP").is_some() {
                    unsafe {
                        raise(19);
                    }
                }
            }
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(_) => return false,
        }
    }
    wall_current(expiry)
        && Instant::now() < deadline
        && crate::ipse_lease_transfer::control_quiet(control)
        && guards
            .iter()
            .all(|fd| crate::ipse_lease_transfer::control_quiet(*fd))
}

struct ChildGuard(i32);
impl Drop for ChildGuard {
    fn drop(&mut self) {
        if self.0 <= 0 {
            return;
        }
        unsafe {
            kill(self.0, 9);
        }
        let mut status = 0;
        loop {
            let n = unsafe { waitpid(self.0, &mut status, 0) };
            if n == self.0
                || (n < 0 && io::Error::last_os_error().kind() != io::ErrorKind::Interrupted)
            {
                break;
            }
        }
    }
}

fn frame(
    output: &mut File,
    control: i32,
    watched: &[i32],
    kind: u8,
    body: &[u8],
    deadline: Instant,
) -> Result<(), String> {
    let mut frame = vec![kind];
    frame.extend_from_slice(&(body.len() as u32).to_be_bytes());
    frame.extend_from_slice(body);
    let mut at = 0;
    while at < frame.len() {
        sink::ready_watch(output.as_raw_fd(), OUTPUT, control, watched, deadline)
            .map_err(|_| err())?;
        match output.write(&frame[at..]) {
            Ok(0) => return Err(err()),
            Ok(n) => at += n,
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(_) => return Err(err()),
        }
    }
    Ok(())
}

// `D` is native write progress only, never an effect or Review receipt. A
// partially delivered or late status remains unknown to any future caller.
fn display_frame(
    output: &mut File,
    control: i32,
    watched: &[i32],
    body: &[u8],
    expiry: u64,
    deadline: Instant,
) -> Result<(), String> {
    let mut bytes = vec![b'D'];
    bytes.extend_from_slice(&(body.len() as u32).to_be_bytes());
    bytes.extend_from_slice(body);
    let mut at = 0;
    while at < bytes.len() {
        if !wall_current(expiry) {
            return Err(err());
        }
        sink::ready_watch(output.as_raw_fd(), OUTPUT, control, watched, deadline)
            .map_err(|_| err())?;
        if !wall_current(expiry) {
            return Err(err());
        }
        match output.write(&bytes[at..]) {
            Ok(0) => return Err(err()),
            Ok(n) => at += n,
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(_) => return Err(err()),
        }
    }
    if wall_current(expiry) && Instant::now() < deadline {
        Ok(())
    } else {
        Err(err())
    }
}

fn read_command(
    control: &mut File,
    watched: &[i32],
    deadline: Instant,
    out: &mut [u8],
) -> Result<(), String> {
    let mut at = 0;
    while at < out.len() {
        let left = deadline.saturating_duration_since(Instant::now());
        if left.is_zero() {
            return Err(err());
        }
        let mut fds = vec![Poll {
            fd: control.as_raw_fd(),
            events: INPUT,
            revents: 0,
        }];
        fds.extend(watched.iter().map(|fd| Poll {
            fd: *fd,
            events: INPUT,
            revents: 0,
        }));
        let n = unsafe {
            poll(
                fds.as_mut_ptr(),
                fds.len(),
                left.as_millis().max(1).min(20) as i32,
            )
        };
        if n < 0 && io::Error::last_os_error().kind() == io::ErrorKind::Interrupted {
            continue;
        }
        if n < 0 || fds[0].revents & BAD != 0 || fds.iter().skip(1).any(|p| p.revents != 0) {
            return Err(err());
        }
        if fds[0].revents & INPUT == 0 {
            continue;
        }
        match control.read(&mut out[at..]) {
            Ok(0) => return Err(err()),
            Ok(n) => at += n,
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(_) => return Err(err()),
        }
    }
    Ok(())
}

fn send_peer(
    peer: &mut UnixStream,
    bytes: &[u8],
    control: i32,
    watched: &[i32],
    deadline: Instant,
) -> Result<(), String> {
    let mut at = 0;
    while at < bytes.len() {
        sink::ready_watch(peer.as_raw_fd(), OUTPUT, control, watched, deadline)
            .map_err(|_| err())?;
        match peer.write(&bytes[at..]) {
            Ok(0) => return Err(err()),
            Ok(n) => at += n,
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(_) => return Err(err()),
        }
    }
    Ok(())
}
fn read_peer(
    peer: &mut UnixStream,
    bytes: &mut [u8],
    control: i32,
    watched: &[i32],
    deadline: Instant,
) -> Result<(), String> {
    let mut at = 0;
    while at < bytes.len() {
        sink::ready_watch(peer.as_raw_fd(), INPUT, control, watched, deadline)
            .map_err(|_| err())?;
        match peer.read(&mut bytes[at..]) {
            Ok(0) => return Err(err()),
            Ok(n) => at += n,
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(_) => return Err(err()),
        }
    }
    Ok(())
}

pub(crate) fn run(
    mut control: File,
    mut output: File,
    mut tty: File,
    channel: File,
    deadline: Instant,
    synthetic_display: bool,
) -> Result<(), String> {
    sink::nonblocking(control.as_raw_fd()).map_err(|_| err())?;
    sink::nonblocking(output.as_raw_fd()).map_err(|_| err())?;
    let control_fd = control.as_raw_fd();
    let mut header = [0u8; 5];
    sink::read_exact(&mut control, &mut header, None, None, deadline).map_err(|_| err())?;
    let size = u32::from_be_bytes(header[1..].try_into().unwrap()) as usize;
    let max_size = if synthetic_display { 8721 } else { 493 };
    if header[0] != b'I' || !(238..=max_size).contains(&size) {
        return Err(err());
    }
    let mut body = vec![0u8; size];
    sink::read_exact(&mut control, &mut body, None, None, deadline).map_err(|_| err())?;
    let operation: [u8; 16] = body[..16].try_into().unwrap();
    let count = body[16] as usize;
    let manifest_size = 153 + 85 * count;
    if operation.iter().all(|b| *b == 0) || !(1..=4).contains(&count) || size < manifest_size {
        return Err(err());
    }
    let (payload, expiry, tty_identity) = if synthetic_display {
        if size < manifest_size + 37 {
            return Err(err());
        }
        let extra = &body[manifest_size..];
        let dev = u64::from_be_bytes(extra[..8].try_into().unwrap());
        let ino = u64::from_be_bytes(extra[8..16].try_into().unwrap());
        let rdev = u64::from_be_bytes(extra[16..24].try_into().unwrap());
        let expiry = u64::from_be_bytes(extra[24..32].try_into().unwrap());
        let length = u32::from_be_bytes(extra[32..36].try_into().unwrap()) as usize;
        if !(1..=8192).contains(&length) || extra.len() != 36 + length || !wall_current(expiry) {
            return Err(err());
        }
        let payload = &extra[36..];
        if !std::str::from_utf8(payload)
            .is_ok_and(|s| s.chars().all(|c| !c.is_control() || c == '\n' || c == '\t'))
        {
            return Err(err());
        }
        let m = tty.metadata().map_err(|_| err())?;
        if (m.dev(), m.ino(), m.rdev()) != (dev, ino, rdev) {
            return Err(err());
        }
        (payload, expiry, Some((dev, ino, rdev)))
    } else {
        if size != manifest_size {
            return Err(err());
        }
        (&[][..], 0, None)
    };
    let session_entry = &body[17..85];
    let host_entry = &body[85..153];
    let mut raw = Vec::new();
    for entry in [session_entry, host_entry] {
        raw.push(entry);
    }
    let mut requests = Vec::new();
    for chunk in body[153..manifest_size].chunks_exact(85) {
        if chunk[0] > 2 || chunk[1..17].iter().all(|b| *b == 0) {
            return Err(err());
        }
        let op: [u8; 16] = chunk[1..17].try_into().unwrap();
        requests.push((chunk[0], op, &chunk[17..85]));
        raw.push(&chunk[17..85]);
    }
    for (i, a) in raw.iter().enumerate() {
        for b in raw.iter().skip(i + 1) {
            if a[4..20] == b[4..20] || a[20..52] == b[20..52] || a[52..68] == b[52..68] {
                return Err(err());
            }
        }
    }
    let mut ready = operation.to_vec();
    ready.push(count as u8);
    frame(&mut output, control_fd, &[], b'H', &ready, deadline)?;
    let mut owners = Vec::new();
    let mut watched = Vec::new();
    for (role, entry) in [(1, session_entry), (2, host_entry)] {
        let (owner, expected, peer) =
            controls::collect(entry, &operation, role, control_fd, &watched, deadline)?;
        watched.extend([
            owner.as_raw_fd(),
            expected.process.as_raw_fd(),
            peer.as_raw_fd(),
        ]);
        owners.push((owner, expected, peer));
    }
    let mut leases = Vec::new();
    let mut entries = Vec::new();
    let mut peers = Vec::new();
    for (slot, op, bytes) in requests {
        let item = sink::expected(bytes).map_err(|_| err())?;
        if entries
            .iter()
            .any(|(prior_slot, _, old): &(u8, [u8; 16], sink::Expected)| {
                *prior_slot == slot && old.pid == item.pid
            })
        {
            return Err(err());
        }
        let mut peer =
            sink::open_peer_watch(&item, control_fd, &watched, deadline).map_err(|_| err())?;
        let lease =
            sink::receive_watch(&peer, &item, control_fd, &watched, deadline).map_err(|_| err())?;
        let mut guards = watched.clone();
        guards.push(item.process.as_raw_fd());
        send_peer(&mut peer, b"A", control_fd, &guards, deadline)?;
        watched.push(item.process.as_raw_fd());
        leases.push(lease);
        entries.push((slot, op, item));
        peers.push(peer);
    }
    // During a synthetic display, retained lease peer EOF is also loss even if
    // its exporter process remains alive. Settlement F/G becomes readable
    // only after the reader has stopped, so those sockets are not watched as
    // unexpected input during the later ordered close protocol.
    let mut display_watch = watched.clone();
    if synthetic_display {
        display_watch.extend(peers.iter().map(|peer| peer.as_raw_fd()));
    }
    // Both forked processes inherit every exact lease and owner descriptor.
    let mut pipe = [-1; 2];
    if unsafe { pipe2(pipe.as_mut_ptr(), 0x80000 | 0x800) } != 0 {
        return Err(err());
    }
    let mut reader_control = unsafe { File::from_raw_fd(pipe[0]) };
    let mut guardian_control = unsafe { File::from_raw_fd(pipe[1]) };
    let mut event_pipe = [-1; 2];
    if unsafe { pipe2(event_pipe.as_mut_ptr(), 0x80000 | 0x800) } != 0 {
        return Err(err());
    }
    let mut reader_events = unsafe { File::from_raw_fd(event_pipe[0]) };
    let mut reader_emit = unsafe { File::from_raw_fd(event_pipe[1]) };
    let child = unsafe { fork() };
    if child < 0 {
        return Err(err());
    }
    if child == 0 {
        drop(guardian_control);
        drop(reader_events);
        if synthetic_display {
            if !wait_reader_command(&mut reader_control, &display_watch, deadline, b'A')
                || !synthetic_write(
                    &mut tty,
                    control_fd,
                    reader_control.as_raw_fd(),
                    &display_watch,
                    payload,
                    expiry,
                    deadline,
                )
            {
                unsafe { _exit(2) }
            }
            let mut guards = display_watch.clone();
            guards.push(reader_control.as_raw_fd());
            if sink::ready_watch(
                reader_emit.as_raw_fd(),
                OUTPUT,
                control_fd,
                &guards,
                deadline,
            )
            .is_err()
                || !matches!(reader_emit.write(b"D"), Ok(1))
            {
                unsafe { _exit(2) }
            }
        }
        let success = wait_reader_command(&mut reader_control, &display_watch, deadline, b'C');
        unsafe { _exit(if success { 0 } else { 2 }) }
    }
    drop(reader_control);
    drop(reader_emit);
    let mut child_guard = ChildGuard(child);
    let child_process = if synthetic_display {
        Some(sink::pidfd(child as u32).map_err(|_| err())?)
    } else {
        None
    };
    let mut active_watch = display_watch.clone();
    if let Some(process) = &child_process {
        active_watch.push(process.as_raw_fd());
    }
    let mut collected = ready.clone();
    collected.extend_from_slice(&(child as u32).to_be_bytes());
    frame(
        &mut output,
        control_fd,
        &active_watch,
        b'L',
        &collected,
        deadline,
    )?;
    if synthetic_display {
        let mut activation_header = [0u8; 5];
        read_command(
            &mut control,
            &active_watch,
            deadline,
            &mut activation_header,
        )?;
        let activation_len =
            u32::from_be_bytes(activation_header[1..].try_into().unwrap()) as usize;
        if activation_header[0] != b'A' || activation_len != body.len() {
            return Err(err());
        }
        let mut activation = vec![0u8; activation_len];
        read_command(&mut control, &active_watch, deadline, &mut activation)?;
        let m = tty.metadata().map_err(|_| err())?;
        if activation != body
            || !wall_current(expiry)
            || Some((m.dev(), m.ino(), m.rdev())) != tty_identity
        {
            return Err(err());
        }
        guardian_control.write_all(b"A").map_err(|_| err())?;
        sink::ready_watch(
            reader_events.as_raw_fd(),
            INPUT,
            control_fd,
            &active_watch,
            deadline,
        )
        .map_err(|_| err())?;
        let mut done = [0u8; 1];
        if !matches!(reader_events.read(&mut done), Ok(1))
            || done != [b'D']
            || !wall_current(expiry)
            || !crate::ipse_lease_transfer::control_quiet(control_fd)
            || active_watch
                .iter()
                .any(|fd| !crate::ipse_lease_transfer::control_quiet(*fd))
        {
            return Err(err());
        }
        display_frame(
            &mut output,
            control_fd,
            &active_watch,
            &ready,
            expiry,
            deadline,
        )?;
    }
    let mut close = [0u8; 17];
    read_command(&mut control, &active_watch, deadline, &mut close)?;
    if close[0] != b'C' || close[1..] != operation {
        return Err(err());
    }
    guardian_control.write_all(b"C").map_err(|_| err())?;
    let mut status = 0;
    loop {
        let n = unsafe { waitpid(child, &mut status, 1) };
        if n == child {
            break;
        }
        if n < 0 && io::Error::last_os_error().kind() != io::ErrorKind::Interrupted {
            return Err(err());
        }
        if Instant::now() >= deadline
            || !crate::ipse_lease_transfer::control_quiet(control_fd)
            || watched
                .iter()
                .any(|fd| !crate::ipse_lease_transfer::control_quiet(*fd))
        {
            return Err(err());
        }
        std::thread::sleep(Duration::from_millis(1));
    }
    child_guard.0 = -1;
    if status != 0 {
        return Err(err());
    }
    drop(leases);
    for (index, (slot, op, _)) in entries.iter().enumerate() {
        let mut receipt = [0u8; 18];
        receipt[0] = b'C';
        receipt[1..17].copy_from_slice(op);
        receipt[17] = *slot;
        send_peer(&mut peers[index], &receipt, control_fd, &watched, deadline)?;
    }
    for (index, (slot, op, _)) in entries.iter().enumerate() {
        let mut ack = [0u8; 18];
        read_peer(&mut peers[index], &mut ack, control_fd, &watched, deadline)?;
        if ack[0] != b'F' || ack[1..17] != *op || ack[17] != *slot {
            return Err(err());
        }
        ack[0] = b'G';
        send_peer(&mut peers[index], &ack, control_fd, &watched, deadline)?;
        let mut fds = [Poll {
            fd: peers[index].as_raw_fd(),
            events: INPUT,
            revents: 0,
        }];
        loop {
            if Instant::now() >= deadline
                || !crate::ipse_lease_transfer::control_quiet(control_fd)
                || watched
                    .iter()
                    .any(|fd| !crate::ipse_lease_transfer::control_quiet(*fd))
            {
                return Err(err());
            }
            let n = unsafe { poll(fds.as_mut_ptr(), fds.len(), 10) };
            if n < 0 && io::Error::last_os_error().kind() == io::ErrorKind::Interrupted {
                continue;
            }
            if n < 0 || fds[0].revents & (8 | 32) != 0 {
                return Err(err());
            }
            if fds[0].revents & (INPUT | 16) != 0 {
                let mut byte = [0u8; 1];
                match peers[index].read(&mut byte) {
                    Ok(0) => break,
                    Err(e)
                        if matches!(
                            e.kind(),
                            io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                        ) =>
                    {
                        ()
                    }
                    _ => return Err(err()),
                }
            }
        }
    }
    // Retain matched tty, channel, owner controls and peer state until all
    // original exporters have completed their per-slot close protocol.
    drop((tty, channel, owners, peers));
    frame(&mut output, control_fd, &[], b'C', &ready, deadline)?;
    Ok(())
}
