defmodule Ipse.Test.ShareHostProbe do
  # Compiled only into this isolated fixture's Host, immediately after the
  # real Session has admitted and journaled the worker's action.
  def pause(owner, job, worker, intent) do
    test = Process.whereis(:ipse_share_host_fixture)
    send(test, {:host_ready, self(), owner, job, worker, intent})
    loop(test, owner, job, intent)
  end

  defp loop(test, owner, job, intent) do
    receive do
      {:probe, command} ->
        result =
          case command do
            {:begin, candidate} ->
              Ipse.Extension.Host.begin_session_share(owner, job, candidate)

            {:controlled_begin, candidate} ->
              Ipse.Extension.Host.begin_controlled_session_share(owner, job, candidate)

            {:stale_preparation, candidate} ->
              stale_preparation(owner, job, candidate)

            {:configure_session, cap, recipient, name, secret} ->
              Ipse.Extension.Host.configure_session_control(
                owner,
                job,
                cap,
                recipient,
                name,
                secret
              )

            {:configure_host, port, operation, recipient, name, secret} ->
              Ipse.Runner.send_owner_control(port, operation, :host, recipient, name, secret)

            {:controlled_abort, cap, port} ->
              Ipse.Extension.Host.abort_controlled_session_share(owner, job, cap, port)

            {:export, cap, request} ->
              Ipse.Extension.Host.export_session_share(owner, job, cap, request)

            {:settle, cap} ->
              Ipse.Extension.Host.settle_session_share(owner, job, cap)

            {:finish, cap} ->
              Ipse.Extension.Host.finish_session_share(owner, job, cap)

            {:abort, cap} ->
              Ipse.Extension.Host.abort_session_share(owner, job, cap)

            :open_owner_control ->
              Ipse.Runner.open_owner_control()

            {:await_owner_control, port} ->
              await_owner_control(port)

            {:send_owner_control, port, operation, role, recipient, name, secret} ->
              Ipse.Runner.send_owner_control(port, operation, role, recipient, name, secret)
          end

        send(test, {:probe_result, command, result})
        loop(test, owner, job, intent)

      :continue ->
        :ok
    after
      20_000 -> exit(:fixture_timeout)
    end
  end

  defp await_owner_control(port, buffer \\ <<>>) do
    case buffer do
      <<?R, 16::32, "owner-control-v1">> ->
        :ok

      _ ->
        receive do
          {^port, {:data, bytes}} when byte_size(buffer) + byte_size(bytes) <= 64 ->
            await_owner_control(port, buffer <> bytes)

          {^port, {:exit_status, _}} ->
            {:error, :owner_control_unavailable}
        after
          5_000 -> {:error, :owner_control_unavailable}
        end
    end
  end

  defp stale_preparation(owner, job, intent) do
    {:ok, ticket, operation, deadline} =
      GenServer.call(owner, {:session_control_ticket, job, intent})

    {:ok, prepared} = Ipse.Runner.prepare_owner_control(job, intent, ticket, operation, deadline)
    {:ok, port} = Ipse.Runner.open_prepared_owner_control(prepared, self(), job, intent)
    :ok = await_owner_control(port)
    changed = Map.put(prepared, :helper, "/tmp/not-the-pinned-helper")
    first = GenServer.call(owner, {:session_share_begin_controlled, job, intent, changed, port})
    replay = GenServer.call(owner, {:session_share_begin_controlled, job, intent, prepared, port})
    :ok = Ipse.Runner.close_owner_control(port)
    {first, replay}
  end
end

defmodule Ipse.Session.ShareHostJobTest do
  use ExUnit.Case, async: false
  @moduletag skip: if(:os.type() == {:unix, :linux}, do: false, else: "Linux native share")
  alias Ipse.{JSON, Runner, Session, Usage}
  alias Ipse.Extension.{Artifact, Catalog, Config, Registry}

  setup_all do
    # This source-only hook runs in the real Host task; it is never present in
    # the production Host BEAM. Refuse if the exact insertion point changes.
    source = File.read!("lib/ipse/extension/host.ex")
    needle = "case execute_admitted_action(context, worker, intent, request) do"
    assert length(String.split(source, needle)) == 2

    instrumented =
      String.replace(
        source,
        needle,
        "Ipse.Test.ShareHostProbe.pause(owner, job_ref, worker, intent)\n        " <> needle
      )

    Code.compiler_options(ignore_module_conflict: true)

    [{Ipse.Extension.Host, beam}] =
      Code.compile_string(instrumented, "share-host-instrumented.ex")

    path = Application.app_dir(:ipse, "ebin/Elixir.Ipse.Extension.Host.beam")
    File.write!(path, beam)
    :code.purge(Ipse.Extension.Host)
    :code.delete(Ipse.Extension.Host)

    assert {:module, Ipse.Extension.Host} =
             :code.load_abs(String.to_charlist(Path.rootname(path)))

    if evidence = System.get_env("IPSE_SHARE_HOST_SOURCE_EVIDENCE"),
      do: File.write!(evidence, instrumented)

    root = Path.join(System.tmp_dir!(), "ipse-share-host-artifact-" <> Usage.id())
    File.mkdir_p!(Path.join(root, "ebin"))
    File.chmod!(root, 0o700)
    on_exit(fn -> File.rm_rf!(root) end)

    paths =
      :code.get_path()
      |> Enum.reject(&(&1 == ~c"."))
      |> Enum.flat_map(&["-pa", List.to_string(&1)])

    {out, status} =
      System.cmd(
        System.find_executable("elixirc"),
        ["--erl", "+S 2:2"] ++
          paths ++ ["-o", Path.join(root, "ebin"), "test/support/share_host_worker.exs"],
        stderr_to_stdout: true
      )

    assert status == 0, out
    File.write!(Path.join(root, "LICENSE"), "Apache-2.0 synthetic fixture")

    descriptor = %{
      "id" => "share",
      "description" => "Synthetic Session share action",
      "arguments_schema" => %{"type" => "object"},
      "result_schema" => %{"type" => "object"}
    }

    exports = Catalog.empty() |> Map.put("commands", [descriptor])
    capabilities = ~w(invoke.command host.actions host.context)

    files =
      for path <- ["LICENSE", "ebin/Elixir.IpseTest.ShareHostWorker.beam"] do
        bytes = File.read!(Path.join(root, path))
        %{"path" => path, "bytes" => byte_size(bytes), "sha256" => JSON.sha256(bytes)}
      end

    manifest = %{
      "format" => 1,
      "id" => "fixture/share-host",
      "version" => "0.1.0",
      "sdk" => 1,
      "protocol" => 1,
      "backend" => "elixir_worker",
      "entrypoint" => "IpseTest.ShareHostWorker",
      "license_file" => "LICENSE",
      "files" => files,
      "capabilities" => capabilities,
      "exports" => exports,
      "options_schema" => %{"type" => "object"},
      "runtime" => %{
        "elixir" => ">= 1.18.0",
        "otp" => [String.to_integer(System.otp_release())],
        "platforms" => [to_string(:erlang.system_info(:system_architecture))]
      }
    }

    File.write!(Path.join(root, "extension.json"), Jason.encode!(manifest))

    if evidence = System.get_env("IPSE_SHARE_HOST_ARTIFACT_EVIDENCE") do
      refute File.exists?(evidence)
      assert {:ok, _} = File.cp_r(root, evidence)
    end

    %{artifact: root, capabilities: capabilities}
  end

  setup c do
    root = Path.join(System.tmp_dir!(), "ipse-share-host-" <> Usage.id())
    home = Path.join(root, "home")
    cwd = Path.join(root, "cwd")
    File.mkdir_p!(home)
    File.mkdir!(cwd)
    File.chmod!(home, 0o700)
    on_exit(fn -> File.rm_rf!(root) end)
    {:ok, artifact} = Artifact.import(c.artifact, Path.join(home, "extensions/artifacts"))

    data = %{
      "extensions" => [
        %{
          "instance" => "fixture",
          "artifact" => artifact.digest,
          "enabled" => true,
          "options" => %{},
          "order" => 0,
          "lifetime" => "session"
        }
      ],
      "extension_trust" => [
        %{
          "artifact" => artifact.digest,
          "capabilities" => c.capabilities,
          "allow_project" => false,
          "allow_children" => false
        }
      ]
    }

    {:ok, selected} = Config.resolve([%{scope: "operator", path: "/fixture", data: data}], [])
    assert Artifact.compatible?(artifact.manifest)
    assert {:ok, _} = Registry.lookup(Path.join(home, "extensions/artifacts"), artifact.digest)
    {:ok, entries} = Registry.prepare(selected, home)
    assert Registry.valid_identity?(hd(entries).identity)

    config = %{
      provider: :demo,
      model: "fixture",
      home: home,
      extensions: entries,
      approval: :deny
    }

    opts = [config: config, cwd: cwd, state_dir: Path.join(home, "sessions"), subscriber: self()]
    {:ok, session} = Session.start_share_candidate_link(opts)
    Process.unlink(session)
    on_exit(fn -> if Process.alive?(session), do: Process.exit(session, :kill) end)
    Process.register(self(), :ipse_share_host_fixture)

    reader =
      spawn(fn ->
        receive do
          :stop -> :ok
        end
      end)

    on_exit(fn -> if Process.alive?(reader), do: Process.exit(reader, :kill) end)
    assert {:ok, _channel} = Session.open_input_channel(session, reader)

    on_exit(fn ->
      if Process.whereis(:ipse_share_host_fixture) == self(),
        do: Process.unregister(:ipse_share_host_fixture)
    end)

    assert :ok = Session.invoke_export(session, :command, "ext__fixture__share", %{})
    assert_receive {:host_ready, host, ^session, job, worker, intent}, 10_000
    assert Process.alive?(worker)
    assert :sys.get_state(session).invocation.action.intent == intent

    %{
      session: session,
      host: host,
      job: job,
      worker: worker,
      intent: intent,
      root: root,
      reader: reader
    }
  end

  test "actual Host, selected artifact and worker bind the sealed action and reject foreign controls",
       c do
    assert {:error, :session_share_refused} =
             GenServer.call(c.session, {:session_share_begin, c.job, c.intent})

    probe(
      c.host,
      {:begin, Map.put(c.intent, "operation_id", "wrong")},
      {:error, :session_share_refused}
    )

    send(c.host, {:probe, {:begin, c.intent}})
    assert_receive {:probe_result, {:begin, _}, {:ok, cap, _transport, snapshot}}, 5_000
    assert snapshot.job_ref == c.job

    assert {:error, :session_share_frozen} =
             GenServer.call(c.session, {:managed_sources, c.job, nil, []})

    assert {:error, :session_share_frozen} =
             GenServer.call(c.session, {:session_share_abort, c.job, cap})

    probe(c.host, {:abort, cap}, :ok)
    send(c.host, :continue)
    assert_receive {:ipse, _, {:done, :ok}}, 10_000
    assert :ok = Session.close_confirmed(c.session)
  end

  test "cancellation kills the real Host and worker while its Writer drain is suspended", c do
    writer = :sys.get_state(c.session).journal_writer
    :ok = :sys.suspend(writer)
    host_ref = Process.monitor(c.host)
    worker_ref = Process.monitor(c.worker)
    send(c.host, {:probe, {:begin, c.intent}})
    await_phase(c.session, :draining)
    assert {:error, :cleanup_unconfirmed} = Session.cancel(c.session)
    assert_receive {:DOWN, ^host_ref, :process, _, _}, 5_000
    assert_receive {:DOWN, ^worker_ref, :process, _, _}, 5_000
    assert :sys.get_state(c.session).share_barrier.phase == :poisoned
    :ok = :sys.resume(writer)
    assert {:error, :cleanup_unconfirmed} = Session.close_confirmed(c.session)
  end

  @tag :share_late_reply
  test "a Writer reply after the setup deadline cannot arm the real Host", c do
    writer = :sys.get_state(c.session).journal_writer
    :ok = :sys.suspend(writer)
    host_ref = Process.monitor(c.host)
    send(c.host, {:probe, {:begin, c.intent}})
    await_phase(c.session, :draining)

    :sys.replace_state(c.session, fn s ->
      put_in(s, [:share_barrier, :deadline], System.monotonic_time(:millisecond) - 1)
    end)

    :ok = :sys.resume(writer)
    assert_receive {:DOWN, ^host_ref, :process, _, _}, 5_000
    assert :sys.get_state(c.session).share_barrier.phase == :poisoned
    assert {:error, :cleanup_unconfirmed} = Session.close_confirmed(c.session)
  end

  @tag :native_sandbox
  @tag :host_share_positive
  test "real Host settles the native recipient before Writer and Session thaw", c do
    send(c.host, {:probe, {:begin, c.intent}})
    assert_receive {:probe_result, {:begin, _}, {:ok, cap, transport, _snapshot}}, 5_000
    state = :sys.get_state(c.session)
    helper = Path.join(to_string(:code.priv_dir(:ipse)), "ipse-runner")

    collector =
      Port.open({:spawn_executable, String.to_charlist(helper)}, [
        :binary,
        :exit_status,
        :use_stdio,
        :hide,
        args: ["--lease-collect-close-ready-v3"]
      ])

    {:os_pid, collector_pid} = Port.info(collector, :os_pid)
    {:os_pid, exporter_pid} = Port.info(state.lock, :os_pid)
    path = Path.join(state.dir, state.id <> ".lock")
    stat = File.stat!(path)
    name = :crypto.strong_rand_bytes(16)
    secret = :crypto.strong_rand_bytes(32)

    entry =
      <<exporter_pid::32, name::binary, secret::binary, stat.major_device::64, stat.inode::64>>

    init = <<10_000::64, transport::binary, 1, 0, entry::binary>>
    assert Port.command(collector, <<?I, byte_size(init)::32, init::binary>>)
    assert receive_frame(collector, ?H) == <<transport::binary, 1>>

    request =
      <<collector_pid::32, name::binary, secret::binary, stat.major_device::64, stat.inode::64>>

    probe(c.host, {:export, cap, request}, :ok)
    assert receive_frame(collector, ?L) == <<transport::binary, 1>>
    assert {:error, _} = Runner.protected_lock(path)
    probe(c.host, {:finish, cap}, {:error, :session_share_frozen})

    assert {:error, :session_share_frozen} =
             GenServer.call(c.session, {:session_share_finish, c.job, cap})

    assert {:error, :session_share_frozen} =
             GenServer.call(c.session, {:session_sources, :snapshot, %{}})

    assert Port.command(collector, <<?C, transport::binary>>)
    probe(c.host, {:settle, cap}, :ok)
    assert receive_frame(collector, ?C) == <<transport::binary, 1>>
    assert_receive {^collector, {:exit_status, 0}}, 8_000
    probe(c.host, {:finish, cap}, :ok)
    assert :sys.get_state(c.session).share_barrier == nil
    send(c.host, :continue)
    assert_receive {:ipse, _, {:done, :ok}}, 10_000
    assert :ok = Session.close_confirmed(c.session)
  end

  @tag :native_sandbox
  @tag :host_share_lost
  test "post-transfer cancellation is unknown and recipient remains the last holder", c do
    send(c.host, {:probe, {:begin, c.intent}})
    assert_receive {:probe_result, {:begin, _}, {:ok, cap, transport, _snapshot}}, 5_000
    state = :sys.get_state(c.session)
    helper = Path.join(to_string(:code.priv_dir(:ipse)), "ipse-runner")

    collector =
      Port.open({:spawn_executable, String.to_charlist(helper)}, [
        :binary,
        :exit_status,
        :use_stdio,
        :hide,
        args: ["--lease-collect-close-ready-v3"]
      ])

    {:os_pid, collector_pid} = Port.info(collector, :os_pid)

    on_exit(fn ->
      if Port.info(collector), do: System.cmd("kill", ["-CONT", Integer.to_string(collector_pid)])
    end)

    {:os_pid, exporter_pid} = Port.info(state.lock, :os_pid)
    path = Path.join(state.dir, state.id <> ".lock")
    stat = File.stat!(path)
    name = :crypto.strong_rand_bytes(16)
    secret = :crypto.strong_rand_bytes(32)

    entry =
      <<exporter_pid::32, name::binary, secret::binary, stat.major_device::64, stat.inode::64>>

    init = <<10_000::64, transport::binary, 1, 0, entry::binary>>
    assert Port.command(collector, <<?I, byte_size(init)::32, init::binary>>)
    assert receive_frame(collector, ?H) == <<transport::binary, 1>>

    request =
      <<collector_pid::32, name::binary, secret::binary, stat.major_device::64, stat.inode::64>>

    probe(c.host, {:export, cap, request}, :ok)
    assert receive_frame(collector, ?L) == <<transport::binary, 1>>
    assert {_, 0} = System.cmd("kill", ["-STOP", Integer.to_string(collector_pid)])
    host_ref = Process.monitor(c.host)
    assert {:error, :cleanup_unconfirmed} = Session.cancel(c.session)
    assert_receive {:DOWN, ^host_ref, :process, _, _}, 5_000
    assert {:error, :cleanup_unconfirmed} = Session.close_confirmed(c.session)
    assert {:error, _} = Runner.protected_lock(path)
    assert {_, 0} = System.cmd("kill", ["-CONT", Integer.to_string(collector_pid)])
    assert_receive {^collector, {:exit_status, _}}, 8_000
    assert {:ok, contender} = Runner.protected_lock(path)
    assert :ok = Runner.unlock(contender)
  end

  @tag :native_sandbox
  @tag :host_share_wrong_inode
  test "wrong lock identity poisons the actual Host export", c do
    send(c.host, {:probe, {:begin, c.intent}})
    assert_receive {:probe_result, {:begin, _}, {:ok, cap, transport, _snapshot}}, 5_000
    state = :sys.get_state(c.session)
    helper = Path.join(to_string(:code.priv_dir(:ipse)), "ipse-runner")

    collector =
      Port.open({:spawn_executable, String.to_charlist(helper)}, [
        :binary,
        :exit_status,
        :use_stdio,
        :hide,
        args: ["--lease-collect-close-ready-v3"]
      ])

    {:os_pid, collector_pid} = Port.info(collector, :os_pid)
    {:os_pid, exporter_pid} = Port.info(state.lock, :os_pid)
    path = Path.join(state.dir, state.id <> ".lock")
    stat = File.stat!(path)
    name = :crypto.strong_rand_bytes(16)
    secret = :crypto.strong_rand_bytes(32)

    entry =
      <<exporter_pid::32, name::binary, secret::binary, stat.major_device::64, stat.inode::64>>

    init = <<10_000::64, transport::binary, 1, 0, entry::binary>>
    assert Port.command(collector, <<?I, byte_size(init)::32, init::binary>>)
    assert receive_frame(collector, ?H) == <<transport::binary, 1>>

    request =
      <<collector_pid::32, name::binary, secret::binary, stat.major_device::64,
        stat.inode + 1::64>>

    host_ref = Process.monitor(c.host)
    send(c.host, {:probe, {:export, cap, request}})
    assert_receive {:DOWN, ^host_ref, :process, _, _}, 5_000
    assert :sys.get_state(c.session).share_barrier.phase == :poisoned
    assert {:error, :cleanup_unconfirmed} = Session.close_confirmed(c.session)
    assert_receive {^collector, {:exit_status, _}}, 8_000
  end

  @tag :native_sandbox
  @tag :owner_control_host
  test "cancellation closes a control Port owned by the actual Host task", c do
    send(c.host, {:probe, :open_owner_control})
    assert_receive {:probe_result, :open_owner_control, {:ok, port}}, 5_000
    assert Port.info(port, :connected) == {:connected, c.host}
    probe(c.host, {:await_owner_control, port}, :ok)
    {:os_pid, sender} = Port.info(port, :os_pid)
    info = File.stat!("/proc/#{sender}/fd/0")
    helper = Path.join(to_string(:code.priv_dir(:ipse)), "ipse-runner")

    observer =
      Port.open({:spawn_executable, String.to_charlist(helper)}, [
        :binary,
        :exit_status,
        :use_stdio,
        :hide,
        args: ["--owner-control-observe-v1"]
      ])

    assert receive_frame(observer, ?H) == "owner-observer-v1"
    {:os_pid, recipient} = Port.info(observer, :os_pid)
    operation = :crypto.strong_rand_bytes(16)
    name = :crypto.strong_rand_bytes(16)
    secret = :crypto.strong_rand_bytes(32)
    entry = <<sender::32, name::binary, secret::binary, info.major_device::64, info.inode::64>>
    request = <<operation::binary, 2, entry::binary, 30_000::64>>
    assert Port.command(observer, <<?I, byte_size(request)::32, request::binary>>)

    assert {:error, :owner_control_unavailable} =
             Runner.send_owner_control(port, operation, :host, recipient, name, secret)

    probe(c.host, {:send_owner_control, port, operation, :host, recipient, name, secret}, :ok)
    assert receive_frame(observer, ?L) == <<operation::binary, 2>>
    host_ref = Process.monitor(c.host)
    assert :ok = Session.cancel(c.session)
    assert_receive {:DOWN, ^host_ref, :process, _, _}, 5_000
    assert receive_frame(observer, ?D) == <<operation::binary, 2>>
    assert_receive {^observer, {:exit_status, 0}}, 5_000
    assert Process.alive?(c.session)
    assert :ok = Session.close_confirmed(c.session)
  end

  @tag :controlled_partial
  test "real Session cancellation closes both owner Ports before suspended Writer drains", c do
    writer = :sys.get_state(c.session).journal_writer
    :ok = :sys.suspend(writer)
    send(c.host, {:probe, {:controlled_begin, c.intent}})
    await_phase(c.session, :draining)
    b = :sys.get_state(c.session).share_barrier
    assert b.controlled and Port.info(b.owner_port, :connected) == {:connected, c.session}
    assert Port.info(b.host_port, :connected) == {:connected, c.host}
    host_ref = Process.monitor(c.host)
    assert {:error, :cleanup_unconfirmed} = Session.cancel(c.session)
    assert Port.info(b.owner_port) == nil
    assert_receive {:DOWN, ^host_ref, :process, _, _}, 5_000
    assert Port.info(b.host_port) == nil
    assert :sys.get_state(c.session).share_barrier.phase == :poisoned
    :ok = :sys.resume(writer)
    assert {:error, :cleanup_unconfirmed} = Session.close_confirmed(c.session)
  end

  @tag :controlled_timeout
  test "the original setup deadline closes both controls while Writer is suspended", c do
    writer = :sys.get_state(c.session).journal_writer
    :ok = :sys.suspend(writer)
    send(c.host, {:probe, {:controlled_begin, c.intent}})
    await_phase(c.session, :draining)
    b = :sys.get_state(c.session).share_barrier
    host_ref = Process.monitor(c.host)
    await_phase(c.session, :poisoned, 700)
    assert_receive {:DOWN, ^host_ref, :process, _, _}, 5_000
    assert Port.info(b.owner_port) == nil
    assert Port.info(b.host_port) == nil
    :ok = :sys.resume(writer)
    assert {:error, :cleanup_unconfirmed} = Session.close_confirmed(c.session)
  end

  @tag :controlled_client_loss
  test "loss of the bound actual input reader poisons both controls", c do
    send(c.host, {:probe, {:controlled_begin, c.intent}})

    assert_receive {:probe_result, {:controlled_begin, _},
                    {:ok, _cap, _transport, snapshot, controls}},
                   5_000

    assert snapshot.job_ref == c.job
    b = :sys.get_state(c.session).share_barrier
    assert controls.channel_id == b.channel.id
    host_ref = Process.monitor(c.host)
    Process.exit(c.reader, :kill)
    assert_receive {:DOWN, ^host_ref, :process, _, _}, 5_000
    assert Port.info(b.owner_port) == nil
    assert Port.info(b.host_port) == nil
    assert :sys.get_state(c.session).share_barrier.phase == :poisoned
    assert {:error, :cleanup_unconfirmed} = Session.close_confirmed(c.session)
  end

  @tag :controlled_stale
  test "altered helper preparation and its replay refuse before the seal", c do
    expected = {{:error, :session_share_refused}, {:error, :session_share_refused}}
    probe(c.host, {:stale_preparation, c.intent}, expected)
    assert :sys.get_state(c.session).share_barrier == nil
    send(c.host, :continue)
    assert_receive {:ipse, _, {:done, :ok}}, 10_000
    assert :ok = Session.close_confirmed(c.session)
  end

  @tag :controlled_abort
  test "the matching Host closes both controls before pre-export thaw", c do
    send(c.host, {:probe, {:controlled_begin, c.intent}})

    assert_receive {:probe_result, {:controlled_begin, _},
                    {:ok, cap, _transport, _snapshot, controls}},
                   5_000

    b = :sys.get_state(c.session).share_barrier
    probe(c.host, {:controlled_abort, cap, controls.host_port}, :ok)
    assert Port.info(b.owner_port) == nil
    assert Port.info(b.host_port) == nil
    assert :sys.get_state(c.session).share_barrier == nil
    send(c.host, :continue)
    assert_receive {:ipse, _, {:done, :ok}}, 10_000
    assert :ok = Session.close_confirmed(c.session)
  end

  @tag :controlled_bad_frame
  test "an out-of-order control frame poisons the bound operation", c do
    send(c.host, {:probe, {:controlled_begin, c.intent}})

    assert_receive {:probe_result, {:controlled_begin, _},
                    {:ok, _cap, _transport, _snapshot, controls}},
                   5_000

    b = :sys.get_state(c.session).share_barrier
    host_ref = Process.monitor(c.host)
    send(c.session, {b.owner_port, {:data, <<?T, 17::32, controls.operation::binary, 1>>}})
    assert_receive {:DOWN, ^host_ref, :process, _, _}, 5_000
    assert Port.info(b.owner_port) == nil
    assert Port.info(b.host_port) == nil
    assert :sys.get_state(c.session).share_barrier.phase == :poisoned
    assert {:error, :cleanup_unconfirmed} = Session.close_confirmed(c.session)
  end

  @tag :controlled_late_control
  test "a control frame processed after the setup deadline cannot report transfer", c do
    send(c.host, {:probe, {:controlled_begin, c.intent}})

    assert_receive {:probe_result, {:controlled_begin, _},
                    {:ok, _cap, _transport, _snapshot, controls}},
                   5_000

    b = :sys.get_state(c.session).share_barrier

    :sys.replace_state(c.session, fn s ->
      s
      |> put_in([:share_barrier, :deadline], System.monotonic_time(:millisecond) - 1)
      |> put_in([:share_barrier, :owner_phase], :bound)
    end)

    host_ref = Process.monitor(c.host)
    send(c.session, {b.owner_port, {:data, <<?T, 17::32, controls.operation::binary, 1>>}})
    assert_receive {:DOWN, ^host_ref, :process, _, _}, 5_000
    assert :sys.get_state(c.session).share_barrier.phase == :poisoned
    assert Port.info(b.owner_port) == nil
    assert Port.info(b.host_port) == nil
    assert {:error, :cleanup_unconfirmed} = Session.close_confirmed(c.session)
  end

  @tag :controlled_poison_sticky
  test "a delayed transfer frame cannot change a poisoned control", c do
    send(c.host, {:probe, {:controlled_begin, c.intent}})

    assert_receive {:probe_result, {:controlled_begin, _},
                    {:ok, _cap, _transport, _snapshot, controls}},
                   5_000

    :sys.replace_state(c.session, fn s -> put_in(s, [:share_barrier, :owner_phase], :bound) end)
    b = :sys.get_state(c.session).share_barrier
    assert {:error, :cleanup_unconfirmed} = Session.cancel(c.session)
    send(c.session, {b.owner_port, {:data, <<?T, 17::32, controls.operation::binary, 1>>}})
    poisoned = :sys.get_state(c.session).share_barrier
    assert poisoned.phase == :poisoned and poisoned.owner_phase == :bound
    assert {:error, :cleanup_unconfirmed} = Session.close_confirmed(c.session)
  end

  @tag :native_sandbox
  @tag :controlled_both_transfer
  test "actual Session cancellation closes both transferred controls before Writer drains", c do
    send(c.host, {:probe, {:controlled_begin, c.intent}})

    assert_receive {:probe_result, {:controlled_begin, _},
                    {:ok, cap, transport, _snapshot, controls}},
                   5_000

    {:os_pid, host_pid} = Port.info(controls.host_port, :os_pid)

    {session_observer, session_recipient, session_name, session_secret} =
      control_observer(controls.session_pid, controls.operation, 1)

    {host_observer, host_recipient, host_name, host_secret} =
      control_observer(host_pid, controls.operation, 2)

    assert {:error, :session_share_frozen} =
             GenServer.call(
               c.session,
               {:session_control_configure, c.job, cap, session_recipient, session_name,
                session_secret}
             )

    probe(c.host, {:configure_session, cap, session_recipient, session_name, session_secret}, :ok)

    probe(
      c.host,
      {:configure_host, controls.host_port, controls.operation, host_recipient, host_name,
       host_secret},
      :ok
    )

    assert receive_frame(session_observer, ?L) == <<controls.operation::binary, 1>>
    assert receive_frame(host_observer, ?L) == <<controls.operation::binary, 2>>
    await_control_phase(c.session, :transferred)
    state = :sys.get_state(c.session)
    path = Path.join(state.dir, state.id <> ".lock")
    stat = File.stat!(path)
    {:os_pid, exporter} = Port.info(state.lock, :os_pid)
    helper = Path.join(to_string(:code.priv_dir(:ipse)), "ipse-runner")

    collector =
      Port.open({:spawn_executable, String.to_charlist(helper)}, [
        :binary,
        :exit_status,
        :use_stdio,
        :hide,
        args: ["--lease-collect-close-ready-v3"]
      ])

    {:os_pid, collector_pid} = Port.info(collector, :os_pid)

    on_exit(fn ->
      if Port.info(collector), do: System.cmd("kill", ["-CONT", Integer.to_string(collector_pid)])
    end)

    name = :crypto.strong_rand_bytes(16)
    secret = :crypto.strong_rand_bytes(32)
    entry = <<exporter::32, name::binary, secret::binary, stat.major_device::64, stat.inode::64>>
    initial = <<10_000::64, transport::binary, 1, 0, entry::binary>>
    assert Port.command(collector, <<?I, byte_size(initial)::32, initial::binary>>)
    assert receive_frame(collector, ?H) == <<transport::binary, 1>>

    request =
      <<collector_pid::32, name::binary, secret::binary, stat.major_device::64, stat.inode::64>>

    probe(c.host, {:export, cap, request}, :ok)
    assert receive_frame(collector, ?L) == <<transport::binary, 1>>
    assert {_, 0} = System.cmd("kill", ["-STOP", Integer.to_string(collector_pid)])
    writer = state.journal_writer
    :ok = :sys.suspend(writer)
    host_ref = Process.monitor(c.host)
    started = System.monotonic_time(:millisecond)
    assert {:error, :cleanup_unconfirmed} = Session.cancel(c.session)
    assert System.monotonic_time(:millisecond) - started < 1_000
    assert receive_frame(session_observer, ?D) == <<controls.operation::binary, 1>>
    assert receive_frame(host_observer, ?D) == <<controls.operation::binary, 2>>
    assert_receive {:DOWN, ^host_ref, :process, _, _}, 5_000
    assert_receive {^session_observer, {:exit_status, 0}}, 5_000
    assert_receive {^host_observer, {:exit_status, 0}}, 5_000
    :ok = :sys.resume(writer)
    assert {:error, :cleanup_unconfirmed} = Session.close_confirmed(c.session)
    assert {:error, _} = Runner.protected_lock(path)
    assert {_, 0} = System.cmd("kill", ["-CONT", Integer.to_string(collector_pid)])
    assert_receive {^collector, {:exit_status, _}}, 8_000
    assert {:ok, contender} = Runner.protected_lock(path)
    assert :ok = Runner.unlock(contender)
  end

  defp control_observer(sender, operation, role) do
    info = File.stat!("/proc/#{sender}/fd/0")
    helper = Path.join(to_string(:code.priv_dir(:ipse)), "ipse-runner")

    observer =
      Port.open({:spawn_executable, String.to_charlist(helper)}, [
        :binary,
        :exit_status,
        :use_stdio,
        :hide,
        args: ["--owner-control-observe-v1"]
      ])

    assert receive_frame(observer, ?H) == "owner-observer-v1"
    {:os_pid, recipient} = Port.info(observer, :os_pid)
    name = :crypto.strong_rand_bytes(16)
    secret = :crypto.strong_rand_bytes(32)
    entry = <<sender::32, name::binary, secret::binary, info.major_device::64, info.inode::64>>
    request = <<operation::binary, role, entry::binary, 30_000::64>>
    assert Port.command(observer, <<?I, byte_size(request)::32, request::binary>>)
    {observer, recipient, name, secret}
  end

  defp receive_frame(port, kind, buffer \\ <<>>) do
    case buffer do
      <<^kind, length::32, body::binary-size(length)>> ->
        body

      _ ->
        receive do
          {^port, {:data, bytes}} when byte_size(buffer) + byte_size(bytes) <= 256 ->
            receive_frame(port, kind, buffer <> bytes)

          {^port, {:exit_status, status}} ->
            flunk("collector exited before reply: #{status}")
        after
          8_000 -> flunk("collector response timed out")
        end
    end
  end

  defp probe(host, command, expected) do
    send(host, {:probe, command})
    assert_receive {:probe_result, ^command, ^expected}, 5_000
  end

  defp await_phase(session, phase, attempts \\ 100)

  defp await_phase(session, phase, 0),
    do: assert(%{phase: ^phase} = :sys.get_state(session).share_barrier)

  defp await_phase(session, phase, attempts) do
    case :sys.get_state(session).share_barrier do
      %{phase: ^phase} ->
        :ok

      _ ->
        Process.sleep(10)
        await_phase(session, phase, attempts - 1)
    end
  end

  defp await_control_phase(session, phase, attempts \\ 100)

  defp await_control_phase(session, phase, 0),
    do: assert(%{owner_phase: ^phase} = :sys.get_state(session).share_barrier)

  defp await_control_phase(session, phase, attempts) do
    case :sys.get_state(session).share_barrier do
      %{owner_phase: ^phase} ->
        :ok

      _ ->
        Process.sleep(10)
        await_control_phase(session, phase, attempts - 1)
    end
  end
end
