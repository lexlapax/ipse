defmodule Ipse.Session.ReleaseReceipt do
  @moduledoc """
  Closed, signed facts for a Session lock release. This module does not observe
  a helper, write a sidecar, or authorize execution; trusted host code must only
  sign after observing the exact release and other cleanup receipts.

  The signature separates an observed release from an unsigned or replayed
  sidecar. Journal and protected storage remain a cooperative same-user trust
  boundary; this is not containment of hostile BEAM or process-memory access.
  """

  alias Ipse.JSON
  @domain "ipse.session.release-receipt.v1\0"
  @intent_keys ~w(type version session_id owner_id operation_id epoch_id closure_sha256 origin_sha256 lock_device lock_inode helper_sha256 public_key)
  @owner_keys ~w(type version session_id owner_id)
  @body_keys ~w(type version session_id operation_id intent_sha256 native_outcome)
  @receipt_keys ~w(body signature)
  @error {:error, :invalid_release_receipt}
  @max_bytes 2_048

  defmodule SigningKey do
    @moduledoc false
    @enforce_keys [:owner, :bytes]
    defstruct @enforce_keys

    defimpl Inspect do
      def inspect(_, _), do: "#Session.ReleaseReceipt.SigningKey<private>"
    end
  end

  @doc false
  def owner_started(session) do
    if id?(session),
      do:
        {:ok,
         %{
           "type" => "session_release_owner_started",
           "version" => 1,
           "session_id" => session,
           "owner_id" => Ipse.Usage.id()
         }},
      else: @error
  end

  @doc false
  def prepare(session, owner, epoch, closure, origin, lock, helper_sha) do
    with true <- id?(session),
         true <- id?(owner),
         true <- valid_closure?(closure, session, epoch),
         {:ok, ^origin} <-
           Ipse.Journal.SourceOrigin.recorded(
             %{
               "source_origin_layout" => Ipse.Journal.SourceOrigin.layout(),
               "source_origin" => origin
             },
             session
           ),
         true <- is_map(lock),
         true <- JSON.safe_uint?(lock[:device]) and JSON.safe_uint?(lock[:inode]),
         true <- lock[:inode] > 0 and JSON.sha256?(helper_sha) do
      {public, private} = :crypto.generate_key(:eddsa, :ed25519)

      intent = %{
        "type" => "session_release_intent",
        "version" => 1,
        "session_id" => session,
        "owner_id" => owner,
        "operation_id" => Ipse.Usage.id(),
        "epoch_id" => epoch,
        "closure_sha256" => if(closure, do: JSON.digest([closure])),
        "origin_sha256" => JSON.digest([origin]),
        "lock_device" => lock.device,
        "lock_inode" => lock.inode,
        "helper_sha256" => helper_sha,
        "public_key" => encode(public)
      }

      if valid_intent?(intent),
        do: {:ok, intent, %SigningKey{owner: self(), bytes: private}},
        else: @error
    else
      _ -> @error
    end
  rescue
    _ -> @error
  end

  @doc false
  def seal(intent, %SigningKey{owner: owner, bytes: private})
      when owner == self() and is_binary(private) and byte_size(private) == 32 do
    with true <- valid_intent?(intent),
         {:ok, public} <- decode(intent["public_key"], 32) do
      body = body(intent)
      signature = :crypto.sign(:eddsa, :none, message(intent, body), [private, :ed25519])

      if :crypto.verify(:eddsa, :none, message(intent, body), signature, [public, :ed25519]) do
        {:ok, Jason.encode!(%{"body" => body, "signature" => encode(signature)})}
      else
        @error
      end
    else
      _ -> @error
    end
  rescue
    _ -> @error
  end

  def seal(_, _), do: @error

  @doc false
  def verify(intent, bytes) when is_binary(bytes) and byte_size(bytes) <= @max_bytes do
    with true <- valid_intent?(intent),
         {:ok, receipt} <- JSON.decode_bounded(bytes, @max_bytes),
         true <- keys?(receipt, @receipt_keys),
         body when is_map(body) <- receipt["body"],
         true <- keys?(body, @body_keys) and body === body(intent),
         {:ok, public} <- decode(intent["public_key"], 32),
         {:ok, signature} <- decode(receipt["signature"], 64),
         true <-
           :crypto.verify(:eddsa, :none, message(intent, body), signature, [public, :ed25519]) do
      :ok
    else
      _ -> @error
    end
  rescue
    _ -> @error
  end

  def verify(_, _), do: @error

  @doc false
  def classify(_intent, nil), do: :unknown

  # A signature is a claim from trusted host code, not an observation of the
  # native outcome or proof of sidecar publication and cleanup by itself.
  def classify(intent, bytes),
    do: if(verify(intent, bytes) == :ok, do: :signed_release_claim, else: :unknown)

  @doc false
  def intents(events, session) when is_list(events) do
    header = List.first(events) || %{}

    with true <- id?(session),
         {:ok, _} <- Ipse.Session.RuntimeLifecycle.restore(events, session),
         {:ok, origin} <- Ipse.Journal.SourceOrigin.recorded(header["metadata"], session) do
      scan_intents(events, session, origin)
    else
      _ -> @error
    end
  rescue
    _ -> @error
  end

  def intents(_, _), do: @error

  defp scan_intents(events, session, origin) do
    Enum.reduce_while(
      events,
      {:ok,
       %{
         closures: %{},
         epochs: MapSet.new(),
         ids: MapSet.new(),
         owners: MapSet.new(),
         used_owners: MapSet.new(),
         intents: [],
         current_owner: nil,
         current_epoch: nil,
         last_closed: nil
       }},
      fn
        %{"type" => "session_release_owner_started"} = marker, {:ok, acc} ->
          owner = marker["owner_id"]

          if keys?(marker, @owner_keys) and marker["version"] === 1 and
               marker["session_id"] == session and id?(owner) and
               not MapSet.member?(acc.owners, owner) do
            {:cont,
             {:ok,
              %{
                acc
                | owners: MapSet.put(acc.owners, owner),
                  current_owner: owner,
                  current_epoch: nil,
                  last_closed: nil
              }}}
          else
            {:halt, @error}
          end

        %{"type" => "lifecycle_epoch_started", "epoch_id" => epoch}, {:ok, acc} ->
          {:cont, {:ok, %{acc | current_epoch: epoch, last_closed: nil}}}

        %{"type" => "lifecycle_epoch_closed", "epoch_id" => epoch} = closure, {:ok, acc} ->
          if epoch == acc.current_epoch and not Map.has_key?(acc.closures, epoch) do
            {:cont,
             {:ok, %{acc | closures: Map.put(acc.closures, epoch, closure), last_closed: epoch}}}
          else
            {:halt, @error}
          end

        %{"type" => "session_release_intent"} = intent, {:ok, acc} ->
          epoch = intent["epoch_id"]
          closure = if epoch, do: acc.closures[epoch]

          if valid_intent?(intent) and intent["session_id"] == session and is_map(origin) and
               intent["origin_sha256"] == JSON.digest([origin]) and
               intent["owner_id"] == acc.current_owner and
               not MapSet.member?(acc.used_owners, intent["owner_id"]) and
               not MapSet.member?(acc.ids, intent["operation_id"]) and
               ((is_nil(epoch) and is_nil(acc.current_epoch)) or
                  (not is_nil(epoch) and acc.last_closed == epoch and
                     not MapSet.member?(acc.epochs, epoch))) and
               valid_closure?(closure, session, epoch) and
               intent["closure_sha256"] == if(closure, do: JSON.digest([closure])) do
            next = %{
              acc
              | ids: MapSet.put(acc.ids, intent["operation_id"]),
                used_owners: MapSet.put(acc.used_owners, intent["owner_id"]),
                epochs: if(epoch, do: MapSet.put(acc.epochs, epoch), else: acc.epochs),
                intents: [intent | acc.intents]
            }

            {:cont, {:ok, next}}
          else
            {:halt, @error}
          end

        event, acc when is_map(event) ->
          {:cont, acc}

        _, _ ->
          {:halt, @error}
      end
    )
    |> case do
      {:ok, state} -> {:ok, Enum.reverse(state.intents)}
      error -> error
    end
  end

  @doc false
  def valid_intent?(intent) do
    keys?(intent, @intent_keys) and intent["type"] == "session_release_intent" and
      intent["version"] === 1 and id?(intent["session_id"]) and id?(intent["owner_id"]) and
      id?(intent["operation_id"]) and
      ((is_nil(intent["epoch_id"]) and is_nil(intent["closure_sha256"])) or
         (id?(intent["epoch_id"]) and JSON.sha256?(intent["closure_sha256"]))) and
      JSON.sha256?(intent["origin_sha256"]) and JSON.sha256?(intent["helper_sha256"]) and
      JSON.safe_uint?(intent["lock_device"]) and JSON.safe_uint?(intent["lock_inode"]) and
      intent["lock_inode"] > 0 and match?({:ok, _}, decode(intent["public_key"], 32))
  end

  defp valid_closure?(nil, _, nil), do: true

  defp valid_closure?(closure, session, epoch) when is_map(closure) do
    Ipse.Session.RuntimeLifecycle.valid_record?(closure) and
      closure["type"] == "lifecycle_epoch_closed" and closure["session_id"] == session and
      closure["epoch_id"] == epoch and closure["closure"] == "close" and
      closure["cleanup_confirmed"] === false
  end

  defp valid_closure?(_, _, _), do: false

  defp body(intent),
    do: %{
      "type" => "session_release_receipt",
      "version" => 1,
      "session_id" => intent["session_id"],
      "operation_id" => intent["operation_id"],
      "intent_sha256" => JSON.digest([intent]),
      "native_outcome" => "unlocked_exit_0"
    }

  defp message(intent, body), do: @domain <> JSON.digest([intent, body])
  defp encode(bytes), do: Base.url_encode64(bytes, padding: false)

  defp decode(value, size) when is_binary(value) do
    with {:ok, bytes} <- Base.url_decode64(value, padding: false),
         true <- byte_size(bytes) == size and encode(bytes) == value,
         do: {:ok, bytes}
  end

  defp decode(_, _), do: @error
  defp id?(value), do: is_binary(value) and Regex.match?(~r/\A[0-9a-f]{32}\z/, value)
  defp keys?(map, keys), do: is_map(map) and Enum.sort(Map.keys(map)) == Enum.sort(keys)
end
