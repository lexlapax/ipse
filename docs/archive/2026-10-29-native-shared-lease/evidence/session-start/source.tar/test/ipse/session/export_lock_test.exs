defmodule Ipse.Session.ExportLockTest do
  use ExUnit.Case, async: false

  alias Ipse.{Runner, Session.Lock}

  setup do
    if :os.type() != {:unix, :linux}, do: flunk("this focused fixture requires Linux")
    root = Path.join(System.tmp_dir!(), "ipse-export-lock-" <> Ipse.Usage.id())
    File.mkdir!(root)
    File.chmod!(root, 0o700)
    on_exit(fn -> File.rm_rf!(root) end)
    %{root: root, path: Path.join(root, String.duplicate("a", 32) <> ".lock")}
  end

  test "initial export-capable holder remains exclusive until owner and tracked peer stop", c do
    parent = self()

    owner =
      spawn(fn ->
        {:ok, port} = Lock.acquire_export_candidate(c.path)
        guard = Lock.current()
        peer = spawn(fn -> receive do: (:stop -> :ok) end)
        worker = spawn(fn -> receive do: (:stop -> :ok) end)
        :ok = Lock.track(peer, :peer)
        :ok = Lock.track(worker, :worker)
        send(parent, {:candidate_ready, self(), guard, peer, worker, port})
        receive do: (:stop -> :ok)
      end)

    assert_receive {:candidate_ready, ^owner, guard, peer, worker, port}, 5_000

    on_exit(fn ->
      if Process.alive?(owner), do: Process.exit(owner, :kill)
      if Process.alive?(peer), do: send(peer, :stop)
      if Process.alive?(worker), do: Process.exit(worker, :kill)
    end)

    guard_ref = Process.monitor(guard)
    owner_ref = Process.monitor(owner)
    worker_ref = Process.monitor(worker)
    initial = File.stat!(c.path)
    assert Port.info(port)
    assert {:error, _} = Runner.protected_lock(c.path)
    assert File.stat!(c.path).inode == initial.inode

    Process.exit(owner, :kill)
    assert_receive {:DOWN, ^owner_ref, :process, ^owner, :killed}, 5_000
    assert_receive {:DOWN, ^worker_ref, :process, ^worker, :killed}, 5_000
    assert Process.alive?(peer)
    assert Process.alive?(guard)
    assert {:error, _} = Runner.protected_lock(c.path)
    assert File.stat!(c.path).inode == initial.inode
    refute_receive {:DOWN, ^guard_ref, :process, ^guard, _}, 100

    send(peer, :stop)
    assert_receive {:DOWN, ^guard_ref, :process, ^guard, :normal}, 5_000
    assert File.stat!(c.path).inode == initial.inode
    assert {:ok, reopened} = Runner.protected_lock(c.path)
    assert :ok = Runner.unlock(reopened)
  end

  test "candidate refuses unsupported names without falling back to a legacy lock", c do
    invalid = Path.join(c.root, "not-a-session.lock")
    assert {:error, _} = Lock.acquire_export_candidate(invalid)
    refute File.exists?(invalid)
    assert {:ok, legacy} = Runner.protected_lock(invalid)
    assert :ok = Runner.unlock(legacy)
  end
end
