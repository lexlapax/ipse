defmodule Ipse.Session.NativeHeaderSessionTest do
  use ExUnit.Case, async: false
  @moduletag skip: if(:os.type() == {:unix, :linux}, do: false, else: "Linux header helper")
  alias Ipse.{Journal, Runner, Session}

  defmodule Model do
    def complete(_, _, _, _),
      do: {:ok, %{"role" => "assistant", "content" => "fixture answer"}, %{}}
  end

  setup do
    root = Path.join(System.tmp_dir!(), "ipse-native-header-session-" <> Ipse.Usage.id())
    File.mkdir!(root)
    File.chmod!(root, 0o700)
    dir = Path.join(root, "state")
    File.mkdir!(dir)
    File.chmod!(dir, 0o700)
    on_exit(fn -> File.rm_rf!(root) end)

    opts = [
      config: %{
        provider: :demo,
        provider_module: Model,
        model: "fixture",
        home: root,
        approval: :deny
      },
      cwd: root,
      state_dir: dir,
      subscriber: self()
    ]

    %{root: root, dir: dir, opts: opts}
  end

  test "fresh Session binds actual header inode under the lock and resumes", c do
    {:ok, session} = Session.start_link(c.opts)
    Process.unlink(session)
    state = :sys.get_state(session)
    assert :sys.get_state(state.lock_guard).mode == :header_v1
    journal = Path.join(c.dir, state.id <> ".jsonl")
    lock = Path.join(c.dir, state.id <> ".lock")
    refute Enum.any?(File.ls!(c.dir), &String.starts_with?(&1, ".pending-header-"))
    assert {:ok, [%{"metadata" => metadata} | _]} = Journal.load(c.dir, state.id)
    origin = metadata["source_origin"]
    stat = File.stat!(journal)

    assert {origin["major_device"], origin["inode"], origin["uid"]} ==
             {stat.major_device, stat.inode, stat.uid}

    assert :ok = Ipse.Journal.SourceOrigin.check_path(c.dir, state.id, metadata)
    assert {:error, _} = Runner.protected_lock(lock)
    assert :ok = Session.prompt(session, "synthetic header session")
    assert_receive {:ipse, ^session, {:done, _}}, 10_000
    assert :ok = Session.close_confirmed(session)
    {:ok, resumed} = Session.start_link(Keyword.put(c.opts, :id, state.id))
    Process.unlink(resumed)
    assert :sys.get_state(:sys.get_state(resumed).lock_guard).mode == :legacy
    assert :ok = Session.close_confirmed(resumed)
  end
end
