defmodule Ipse.Session.Lock do
  @moduledoc "Retains the session lock through owner death until tracked workers and writer exit."
  use GenServer
  @key {__MODULE__, :guard}

  def acquire(path), do: start(path, :legacy)

  @doc false
  def acquire_header(path), do: start(path, :header_v1)

  @doc false
  # Inactive internal candidate: current Session startup still uses acquire/1.
  def acquire_export_candidate(path), do: start(path, :export_v1)

  defp start(path, mode) do
    case GenServer.start(__MODULE__, {path, self(), mode}) do
      {:ok, guard} ->
        port = GenServer.call(guard, :port)
        Process.put(@key, guard)
        {:ok, port}

      error ->
        error
    end
  end

  def current, do: Process.get(@key)

  def track(pid, kind) do
    case current() do
      nil -> :ok
      guard -> GenServer.call(guard, {:track, pid, kind})
    end
  end

  def for_owner(owner) do
    case Registry.lookup(Ipse.Registry, {__MODULE__, owner}) do
      [{guard, _}] -> guard
      [] -> nil
    end
  end

  def track_in(nil, _, _), do: :ok
  def track_in(guard, pid, kind), do: GenServer.call(guard, {:track, pid, kind})

  def track_child_scope(nil, _), do: :ok
  def track_child_scope(guard, pid), do: GenServer.call(guard, {:track_child_scope, pid})

  def track_session(child) do
    guard = for_owner(child)
    if is_nil(guard), do: exit(:child_lock_unavailable)
    :ok = track(guard, :peer)
    track(child, :worker)
  end

  def release(guard), do: GenServer.call(guard, :release, :infinity)

  @doc false
  def begin_header(guard, deadline), do: header_call(guard, {:begin_header, deadline}, deadline)

  @doc false
  def write_header(guard, bytes, deadline),
    do: header_call(guard, {:write_header, bytes, deadline}, deadline)

  @doc false
  def header_identity(guard, deadline),
    do: header_call(guard, {:header_identity, deadline}, deadline)

  defp header_call(guard, request, deadline) when is_integer(deadline) do
    timeout = max(deadline - System.monotonic_time(:millisecond), 0) + 1_000
    GenServer.call(guard, request, timeout)
  catch
    :exit, _ -> {:error, :header_unconfirmed}
  end

  defp header_call(_, _, _), do: {:error, :header_unconfirmed}

  @impl true
  def init({path, owner, mode}) do
    Process.flag(:trap_exit, true)
    monitor = Process.monitor(owner)

    result =
      case mode do
        :legacy -> Ipse.Runner.protected_lock(path)
        :export_v1 -> Ipse.Runner.protected_export_lock(path)
        :header_v1 -> Ipse.Runner.protected_header_lock(path)
      end

    case result do
      {:ok, port} ->
        {:ok, _} = Registry.register(Ipse.Registry, {__MODULE__, owner}, nil)

        {:ok,
         %{
           owner: owner,
           owner_ref: monitor,
           port: port,
           mode: mode,
           dependents: %{},
           lost: false,
           header_phase: :ready,
           header_deadline: nil
         }}

      error ->
        {:stop, elem(error, 1)}
    end
  end

  @impl true
  def handle_call(:port, {owner, _}, %{owner: owner} = s), do: {:reply, s.port, s}

  def handle_call(
        {:begin_header, deadline},
        {owner, _},
        %{owner: owner, mode: :header_v1, header_phase: :ready} = s
      )
      when is_integer(deadline) do
    result = Ipse.Runner.session_header_begin(s.port, deadline)
    phase = if match?({:ok, _}, result), do: :prepared, else: :failed
    {:reply, result, %{s | header_phase: phase, header_deadline: deadline}}
  end

  def handle_call(
        {:write_header, bytes, deadline},
        {owner, _},
        %{owner: owner, mode: :header_v1, header_phase: :prepared, header_deadline: deadline} = s
      ) do
    result = Ipse.Runner.session_header_write(s.port, bytes, owner, deadline)
    phase = if result == :ok, do: :complete, else: :failed
    {:reply, result, %{s | header_phase: phase}}
  end

  def handle_call(
        {:header_identity, deadline},
        {owner, _},
        %{owner: owner, mode: :header_v1, header_phase: :complete} = s
      ) do
    {:reply, Ipse.Runner.session_header_lock_identity(s.port, deadline), s}
  end

  def handle_call({:track, pid, kind}, {caller, _}, s)
      when is_pid(pid) and kind in [:worker, :writer, :scope, :peer] do
    scoped =
      kind in [:worker, :peer] and
        Enum.any?(s.dependents, fn {_, pair} -> pair == {caller, :scope} end)

    writer =
      kind == :peer and Enum.any?(s.dependents, fn {_, pair} -> pair == {caller, :writer} end)

    if caller == s.owner or scoped or writer do
      ref = Process.monitor(pid)
      {:reply, :ok, %{s | dependents: Map.put(s.dependents, ref, {pid, kind})}}
    else
      {:reply, {:error, :session_lock_refused}, s}
    end
  end

  def handle_call({:track_child_scope, pid}, {caller, _}, s) when is_pid(pid) do
    parent_scope? = Enum.any?(s.dependents, fn {_, pair} -> pair == {caller, :scope} end)

    if parent_scope? and Process.alive?(caller) and Process.alive?(pid) do
      ref = Process.monitor(pid)
      {:reply, :ok, %{s | dependents: Map.put(s.dependents, ref, {pid, :scope})}}
    else
      {:reply, {:error, :session_lock_refused}, s}
    end
  end

  def handle_call(:release, {owner, _}, %{owner: owner} = s) do
    quiesce(s.dependents)
    result = unlock(s)
    {:stop, :normal, result, %{s | dependents: %{}}}
  end

  def handle_call(_, _, s), do: {:reply, {:error, :session_lock_refused}, s}

  @impl true
  def handle_info({:DOWN, ref, :process, _, _}, %{owner_ref: ref} = s) do
    quiesce(s.dependents)
    unlock(s)
    {:stop, :normal, %{s | dependents: %{}}}
  end

  def handle_info({:DOWN, ref, :process, _, _}, s),
    do: {:noreply, %{s | dependents: Map.delete(s.dependents, ref)}}

  def handle_info({port, {:exit_status, _}}, %{port: port} = s), do: lost(s)
  def handle_info({:EXIT, port, _}, %{port: port} = s), do: lost(s)
  def handle_info(_, s), do: {:noreply, s}

  defp lost(%{lost: false} = s) do
    send(s.owner, {s.port, {:exit_status, :lock_lost}})
    {:noreply, %{s | lost: true}}
  end

  defp lost(s), do: {:noreply, s}

  defp unlock(%{mode: :export_v1, port: port}), do: Ipse.Runner.unlock_export_candidate(port)
  defp unlock(%{mode: :header_v1, port: port}), do: Ipse.Runner.unlock_export_candidate(port)
  defp unlock(%{port: port}), do: Ipse.Runner.unlock(port)

  defp quiesce(dependents) do
    Enum.each(dependents, fn {_, {pid, kind}} ->
      case kind do
        :scope -> Ipse.Session.Resources.stop_async(pid)
        :peer -> :ok
        _ -> Process.exit(pid, :kill)
      end
    end)

    Enum.each(dependents, fn {ref, {pid, _}} ->
      receive do
        {:DOWN, ^ref, :process, ^pid, _} -> :ok
      end
    end)
  end

  @impl true
  def format_status(status) do
    Map.new(status, fn
      {key, _} when key in [:state, :message, :reason, :log] -> {key, :session_lock_guard}
      pair -> pair
    end)
  end
end
