//! Focused Linux protocol fixture for the private transaction helper export.
#[cfg(target_os = "linux")]
mod test {
    use std::env;
    use std::ffi::c_void;
    use std::fs::{DirBuilder, File, OpenOptions};
    use std::io::{self, Read, Write};
    use std::mem::{size_of, zeroed};
    use std::os::fd::{AsRawFd, FromRawFd};
    use std::os::linux::net::SocketAddrExt;
    use std::os::unix::fs::{DirBuilderExt, MetadataExt};
    use std::os::unix::net::{SocketAddr, UnixStream};
    use std::path::Path;
    use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};
    use std::sync::mpsc;
    use std::thread;
    use std::time::{Duration, Instant};

    #[repr(C)]
    struct Poll {
        fd: i32,
        events: i16,
        revents: i16,
    }
    #[repr(C)]
    struct IoVec {
        base: *mut c_void,
        len: usize,
    }
    #[repr(C)]
    struct Message {
        name: *mut c_void,
        name_len: u32,
        iov: *mut IoVec,
        iov_len: usize,
        control: *mut c_void,
        control_len: usize,
        flags: i32,
    }
    #[repr(C)]
    struct Header {
        len: usize,
        level: i32,
        kind: i32,
    }
    #[repr(C, align(8))]
    struct Descriptor {
        header: Header,
        fd: i32,
        padding: i32,
    }
    unsafe extern "C" {
        fn poll(fds: *mut Poll, count: usize, timeout: i32) -> i32;
        fn recvmsg(fd: i32, message: *mut Message, flags: i32) -> isize;
        fn flock(fd: i32, operation: i32) -> i32;
    }
    struct OwnedChild(Child);
    impl Drop for OwnedChild {
        fn drop(&mut self) {
            let _ = self.0.kill();
            let _ = self.0.wait();
        }
    }
    fn write_frame(
        out: &mut ChildStdin,
        tag: u8,
        seq: u64,
        depth: u8,
        extra: &[u8],
    ) -> io::Result<()> {
        let mut body = seq.to_be_bytes().to_vec();
        body.push(depth);
        body.extend_from_slice(extra);
        out.write_all(&[tag])?;
        out.write_all(&(body.len() as u32).to_be_bytes())?;
        out.write_all(&body)?;
        out.flush()
    }
    fn read_frame(input: &mut ChildStdout) -> io::Result<(u8, Vec<u8>)> {
        let mut p = Poll {
            fd: input.as_raw_fd(),
            events: 1,
            revents: 0,
        };
        if unsafe { poll(&mut p, 1, 8000) } <= 0 {
            return Err(io::Error::other("helper reply timed out"));
        }
        let mut header = [0u8; 5];
        input.read_exact(&mut header)?;
        let len = u32::from_be_bytes(header[1..].try_into().unwrap()) as usize;
        if len > 1024 {
            return Err(io::Error::other("oversized helper reply"));
        }
        let mut body = vec![0; len];
        input.read_exact(&mut body)?;
        Ok((header[0], body))
    }
    fn open_helper(
        helper: &Path,
        directory: &Path,
        source: bool,
    ) -> io::Result<(OwnedChild, ChildStdin, ChildStdout, std::path::PathBuf)> {
        DirBuilder::new().mode(0o700).create(directory)?;
        let lock = if source {
            directory.join(format!("{}.lock", "a".repeat(32)))
        } else {
            directory.join(".lock")
        };
        let mut command = Command::new(helper);
        if source {
            command.arg("--lock-export-v1").arg(&lock);
        } else {
            command.arg("--transaction-lock").arg("30000");
        }
        let mut child = OwnedChild(
            command
                .stdin(Stdio::piped())
                .stdout(Stdio::piped())
                .stderr(Stdio::null())
                .spawn()?,
        );
        let mut stdin = child
            .0
            .stdin
            .take()
            .ok_or_else(|| io::Error::other("missing stdin"))?;
        let mut stdout = child
            .0
            .stdout
            .take()
            .ok_or_else(|| io::Error::other("missing stdout"))?;
        if source {
            let (kind, payload) = read_frame(&mut stdout)?;
            if kind != b'L' || payload != b"locked" {
                return Err(io::Error::other("source lock acquisition failed"));
            }
        } else {
            write_frame(&mut stdin, b'A', 1, 0, lock.to_str().unwrap().as_bytes())?;
            let (kind, payload) = read_frame(&mut stdout)?;
            if kind != b'A' || payload.len() != 9 || payload[8] != 1 {
                return Err(io::Error::other("lock acquisition failed"));
            }
        }
        Ok((child, stdin, stdout, lock))
    }
    fn receive_fd(socket: &UnixStream) -> io::Result<File> {
        let mut byte = [0u8];
        let mut iov = IoVec {
            base: byte.as_mut_ptr().cast(),
            len: 1,
        };
        let mut descriptor: Descriptor = unsafe { zeroed() };
        let mut message = Message {
            name: std::ptr::null_mut(),
            name_len: 0,
            iov: &mut iov,
            iov_len: 1,
            control: (&mut descriptor as *mut Descriptor).cast(),
            control_len: size_of::<Descriptor>(),
            flags: 0,
        };
        let n = unsafe { recvmsg(socket.as_raw_fd(), &mut message, 0x4000_0000) };
        if n != 1
            || byte != [b'L']
            || message.flags & 8 != 0
            || descriptor.header.len != size_of::<Header>() + size_of::<i32>()
            || descriptor.header.level != 1
            || descriptor.header.kind != 1
            || descriptor.fd < 0
        {
            return Err(io::Error::other("descriptor not delivered"));
        }
        Ok(unsafe { File::from_raw_fd(descriptor.fd) })
    }
    fn connect(name: [u8; 16], secret: [u8; 32]) -> io::Result<UnixStream> {
        let mut abstract_name = b"ipse-lease-v1-".to_vec();
        abstract_name.extend_from_slice(&name);
        let address = SocketAddr::from_abstract_name(abstract_name)?;
        let end = Instant::now() + Duration::from_secs(5);
        let mut socket = loop {
            match UnixStream::connect_addr(&address) {
                Ok(socket) => break socket,
                Err(_) if Instant::now() < end => thread::sleep(Duration::from_millis(10)),
                Err(e) => return Err(e),
            }
        };
        socket.set_read_timeout(Some(Duration::from_secs(5)))?;
        socket.write_all(&secret)?;
        Ok(socket)
    }
    fn peer(
        name: [u8; 16],
        secret: [u8; 32],
        acknowledge: bool,
    ) -> io::Result<(File, Option<UnixStream>)> {
        let mut socket = connect(name, secret)?;
        let fd = receive_fd(&socket)?;
        if acknowledge {
            socket.write_all(b"A")?;
            Ok((fd, Some(socket)))
        } else {
            drop(socket);
            Ok((fd, None))
        }
    }
    fn request(pid: u32, name: [u8; 16], secret: [u8; 32], dev: u64, ino: u64) -> Vec<u8> {
        let mut bytes = vec![0];
        bytes.extend_from_slice(&pid.to_be_bytes());
        bytes.extend_from_slice(&name);
        bytes.extend_from_slice(&secret);
        bytes.extend_from_slice(&dev.to_be_bytes());
        bytes.extend_from_slice(&ino.to_be_bytes());
        bytes
    }
    fn locked(file: &File) -> io::Result<()> {
        if unsafe { flock(file.as_raw_fd(), 2 | 4) } == 0 {
            Ok(())
        } else {
            Err(io::Error::last_os_error())
        }
    }
    fn run_case(root: &Path, helper: &Path, mode: u8, source: bool) -> io::Result<()> {
        let directory = root.join(format!(
            "{}-{mode}",
            if source { "source" } else { "transaction" }
        ));
        let (mut child, mut input, mut output, lock_path) =
            open_helper(helper, &directory, source)?;
        if mode == 7 {
            input.write_all(&[b'C', 0, 0, 0, 0])?;
            input.flush()?;
            let (tag, body) = read_frame(&mut output)?;
            if tag != b'U' || body != b"unlocked" {
                return Err(io::Error::other("source cancellation failed"));
            }
            child.0.wait()?;
            let contender = OpenOptions::new().read(true).write(true).open(lock_path)?;
            locked(&contender)?;
            println!("SOURCE_EXPORT_CANCEL_RELEASED");
            return Ok(());
        }
        let second_lock = if mode == 6 || mode == 10 {
            let second = directory.join("second");
            DirBuilder::new().mode(0o700).create(&second)?;
            let path = second.join(".lock");
            write_frame(&mut input, b'A', 2, 1, path.to_str().unwrap().as_bytes())?;
            let (tag, payload) = read_frame(&mut output)?;
            if tag != b'A' || payload.len() != 9 || payload[8] != 2 {
                return Err(io::Error::other("second lock acquisition failed"));
            }
            Some(path)
        } else {
            None
        };
        let meta = std::fs::metadata(&lock_path)?;
        let mut name = [mode + if source { 20 } else { 10 }; 16];
        name[0..4].copy_from_slice(&std::process::id().to_be_bytes());
        let secret = [mode + 30; 32];
        let pid = if mode == 1 {
            std::process::id().saturating_add(100_000)
        } else {
            std::process::id()
        };
        let inode = if mode == 2 {
            meta.ino() ^ 1
        } else {
            meta.ino()
        };
        let request = request(pid, name, secret, meta.dev(), inode);
        write_frame(
            &mut input,
            b'X',
            if source {
                1
            } else if mode == 6 || mode == 10 {
                3
            } else {
                2
            },
            if mode == 6 || mode == 10 { 2 } else { 1 },
            if source { &request[1..] } else { &request },
        )?;
        if mode == 2 {
            let (tag, _) = read_frame(&mut output)?;
            if tag != b'E' {
                return Err(io::Error::other("wrong inode was not refused"));
            }
            let contender = OpenOptions::new().read(true).write(true).open(&lock_path)?;
            if !locked(&contender).is_err_and(|e| e.kind() == io::ErrorKind::WouldBlock) {
                return Err(io::Error::other("refusal lost the original lock"));
            }
            child.0.kill()?;
            child.0.wait()?;
            locked(&contender)?;
            println!(
                "{}_EXPORT_WRONG_INODE_REFUSED",
                if source { "SOURCE" } else { "TRANSACTION" }
            );
            return Ok(());
        }
        if mode == 5 {
            let (ready_tx, ready_rx) = mpsc::channel();
            let (proceed_tx, proceed_rx) = mpsc::channel();
            let (result_tx, result_rx) = mpsc::channel();
            let handle = thread::spawn(move || {
                let result = (|| {
                    let socket = connect(name, secret)?;
                    ready_tx
                        .send(())
                        .map_err(|_| io::Error::other("owner missing"))?;
                    proceed_rx
                        .recv_timeout(Duration::from_secs(5))
                        .map_err(|_| io::Error::other("owner missing"))?;
                    receive_fd(&socket)
                })();
                let _ = result_tx.send(result);
            });
            ready_rx
                .recv_timeout(Duration::from_secs(7))
                .map_err(|_| io::Error::other("peer did not connect"))?;
            drop(input);
            proceed_tx
                .send(())
                .map_err(|_| io::Error::other("peer stopped"))?;
            let (tag, _) = read_frame(&mut output)?;
            let received = result_rx
                .recv_timeout(Duration::from_secs(7))
                .map_err(|_| io::Error::other("peer timed out"))?;
            handle
                .join()
                .map_err(|_| io::Error::other("peer panicked"))?;
            child.0.wait()?;
            match received {
                Ok(lease) if tag == b'U' => {
                    let contender = OpenOptions::new().read(true).write(true).open(lock_path)?;
                    if !locked(&contender).is_err_and(|e| e.kind() == io::ErrorKind::WouldBlock) {
                        return Err(io::Error::other("transferred lock not retained"));
                    }
                    drop(lease);
                    locked(&contender)?;
                    println!(
                        "{}_EXPORT_OWNER_LOSS_UNKNOWN transfer_occurred=1",
                        if source { "SOURCE" } else { "TRANSACTION" }
                    );
                }
                Err(_) if tag == b'E' => println!(
                    "{}_EXPORT_OWNER_LOSS_REFUSED transfer_occurred=0",
                    if source { "SOURCE" } else { "TRANSACTION" }
                ),
                _ => return Err(io::Error::other("owner loss falsely reported success")),
            }
            return Ok(());
        }
        let (tx, rx) = mpsc::channel();
        let actual_secret = if mode == 3 { [99; 32] } else { secret };
        let handle = thread::spawn(move || {
            let result = peer(name, actual_secret, mode != 4);
            let _ = tx.send(result);
        });
        let (tag, body) = read_frame(&mut output)?;
        let received = rx
            .recv_timeout(Duration::from_secs(7))
            .map_err(|_| io::Error::other("receiver timed out"))?;
        handle
            .join()
            .map_err(|_| io::Error::other("receiver panicked"))?;
        if mode == 1 || mode == 3 {
            if tag != b'E' || received.is_ok() {
                return Err(io::Error::other("wrong peer or secret was accepted"));
            }
            let contender = OpenOptions::new().read(true).write(true).open(&lock_path)?;
            if !locked(&contender).is_err_and(|e| e.kind() == io::ErrorKind::WouldBlock) {
                return Err(io::Error::other("refusal lost the original lock"));
            }
            child.0.kill()?;
            child.0.wait()?;
            locked(&contender)?;
            println!(
                "{}_EXPORT_WRONG_{}_REFUSED",
                if source { "SOURCE" } else { "TRANSACTION" },
                if mode == 1 { "PID" } else { "SECRET" }
            );
            return Ok(());
        }
        let (lease, _socket) = received?;
        if mode == 8 || mode == 9 || mode == 10 || mode == 11 {
            if tag != b'X' || body.len() != 10 || body[9] != 0 {
                return Err(io::Error::other("export not acknowledged"));
            }
            if mode == 11 {
                write_frame(
                    &mut input,
                    b'X',
                    if source { 2 } else { 3 },
                    1,
                    if source { &request[1..] } else { &request },
                )?;
                let (duplicate, _) = read_frame(&mut output)?;
                if duplicate != b'E' {
                    return Err(io::Error::other("duplicate slot export accepted"));
                }
                println!(
                    "{}_DUPLICATE_SLOT_REFUSED",
                    if source { "SOURCE" } else { "TRANSACTION" }
                );
            }
            if mode == 9 {
                input.write_all(&[b'C', 0, 0, 0, 0])?;
                input.flush()?;
                let (release, _) = read_frame(&mut output)?;
                if release != b'E' {
                    return Err(io::Error::other(
                        "source cancellation falsely confirmed release",
                    ));
                }
            } else {
                let seq = if mode == 10 {
                    4
                } else if mode == 11 {
                    if source {
                        3
                    } else {
                        4
                    }
                } else if source {
                    2
                } else {
                    3
                };
                write_frame(&mut input, b'R', seq, if mode == 10 { 2 } else { 1 }, &[])?;
                let (release, _) = read_frame(&mut output)?;
                if release != b'U' {
                    return Err(io::Error::other("exported release was falsely confirmed"));
                }
            }
            child.0.wait()?;
        } else if mode == 4 {
            if tag != b'U' || body.len() != 10 {
                return Err(io::Error::other("missing ack did not become unknown"));
            }
            child.0.wait()?;
        } else {
            if tag != b'X' || body.len() != 10 || body[9] != 0 {
                return Err(io::Error::other("export not acknowledged"));
            }
            child.0.kill()?;
            child.0.wait()?;
        }
        let contender = OpenOptions::new().read(true).write(true).open(lock_path)?;
        if !locked(&contender).is_err_and(|e| e.kind() == io::ErrorKind::WouldBlock) {
            return Err(io::Error::other("exported lease failed to retain lock"));
        }
        if let Some(path) = second_lock {
            let second = OpenOptions::new().read(true).write(true).open(path)?;
            locked(&second)?;
            println!("TRANSACTION_PARENT_SLOT_EXPORT_PASSED nonexported_top_released=1");
        }
        drop(lease);
        locked(&contender)?;
        println!(
            "{}_EXPORT_{}_PASSED helper_dead=1 recipient_retained=1 last_close_released=1",
            if source { "SOURCE" } else { "TRANSACTION" },
            if mode == 8 || mode == 9 || mode == 10 || mode == 11 {
                "RELEASE_UNKNOWN"
            } else if mode == 4 {
                "MISSING_ACK_UNKNOWN"
            } else {
                "ACKNOWLEDGED"
            }
        );
        Ok(())
    }
    pub fn main() -> Result<(), String> {
        let args: Vec<_> = env::args_os().collect();
        if args.len() != 3 {
            return Err("usage: transaction-export-test PRIVATE_DIR IPSE_RUNNER".into());
        }
        for source in [false, true] {
            for mode in 0..=11 {
                if source && (mode == 6 || mode == 10) {
                    continue;
                }
                if !source && (mode == 7 || mode == 9) {
                    continue;
                }
                run_case(Path::new(&args[1]), Path::new(&args[2]), mode, source)
                    .map_err(|e| format!("source {source}, case {mode}: {e}"))?;
            }
        }
        let invalid_dir = Path::new(&args[1]).join("invalid-source");
        DirBuilder::new()
            .mode(0o700)
            .create(&invalid_dir)
            .map_err(|e| e.to_string())?;
        let invalid = Command::new(&args[2])
            .arg("--lock-export-v1")
            .arg(invalid_dir.join("bad.lock"))
            .stdin(Stdio::null())
            .output()
            .map_err(|e| e.to_string())?;
        if invalid.status.success() || invalid.stdout.first() != Some(&b'E') {
            return Err("invalid source name accepted".into());
        }
        let target = invalid_dir.join("target");
        File::create(&target).map_err(|e| e.to_string())?;
        let symlink = invalid_dir.join(format!("{}.lock", "b".repeat(32)));
        std::os::unix::fs::symlink(&target, &symlink).map_err(|e| e.to_string())?;
        let refused = Command::new(&args[2])
            .arg("--lock-export-v1")
            .arg(&symlink)
            .stdin(Stdio::null())
            .output()
            .map_err(|e| e.to_string())?;
        if refused.status.success() || refused.stdout.first() != Some(&b'E') {
            return Err("source symlink accepted".into());
        }
        println!("SOURCE_EXPORT_INVALID_NAME_AND_SYMLINK_REFUSED");
        Ok(())
    }
}
#[cfg(target_os = "linux")]
fn main() {
    if let Err(error) = test::main() {
        eprintln!("{error}");
        std::process::exit(1);
    }
}
#[cfg(not(target_os = "linux"))]
fn main() {
    eprintln!("Linux-only test");
    std::process::exit(1);
}
