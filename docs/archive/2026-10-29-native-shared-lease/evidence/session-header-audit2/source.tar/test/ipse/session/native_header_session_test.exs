defmodule Ipse.Session.NativeHeaderSessionTest do
  use ExUnit.Case, async: false
  @moduletag skip: if(:os.type() == {:unix, :linux}, do: false, else: "Linux header helper")
  alias Ipse.{Journal, Runner, Session}

  defmodule Model do
    def complete(_, _, _, _),
      do: {:ok, %{"role" => "assistant", "content" => "fixture answer"}, %{}}
  end

  setup do
    root = Path.join(System.tmp_dir!(), "ipse-native-header-session-" <> Ipse.Usage.id())
    File.mkdir!(root)
    File.chmod!(root, 0o700)
    dir = Path.join(root, "state")
    File.mkdir!(dir)
    File.chmod!(dir, 0o700)
    on_exit(fn -> File.rm_rf!(root) end)

    opts = [
      config: %{
        provider: :demo,
        provider_module: Model,
        model: "fixture",
        home: root,
        approval: :deny,
        observability: Map.put(Ipse.Observability.defaults(), "mode", "local")
      },
      cwd: root,
      state_dir: dir,
      subscriber: self()
    ]

    %{root: root, dir: dir, opts: opts}
  end

  test "fresh Session binds actual header inode under the lock and resumes", c do
    {:ok, session} = Session.start_link(c.opts)
    Process.unlink(session)
    state = :sys.get_state(session)
    assert state.lock_mode == :header_v1
    assert :sys.get_state(state.lock_guard).mode == :header_v1
    journal = Path.join(c.dir, state.id <> ".jsonl")
    lock = Path.join(c.dir, state.id <> ".lock")
    refute Enum.any?(File.ls!(c.dir), &String.starts_with?(&1, ".pending-header-"))
    assert {:ok, [%{"metadata" => metadata} | _]} = Journal.load(c.dir, state.id)
    origin = metadata["source_origin"]
    stat = File.stat!(journal)

    assert {origin["major_device"], origin["inode"], origin["uid"]} ==
             {stat.major_device, stat.inode, stat.uid}

    assert :ok = Ipse.Journal.SourceOrigin.check_path(c.dir, state.id, metadata)
    assert {:error, _} = Runner.protected_lock(lock)
    assert :ok = Session.prompt(session, "synthetic header session")
    assert_receive {:ipse, ^session, {:done, _}}, 10_000
    assert :ok = Session.close_confirmed(session)
    assert {:ok, events} = Journal.load(c.dir, state.id)

    assert %{"cleanup_confirmed" => false} =
             closure =
             Enum.find(events, &(&1["type"] == "lifecycle_epoch_closed"))

    assert {:ok, "session.close_committed", nil, nil, %{"cleanup_confirmed" => false}, _} =
             Ipse.Session.RuntimeLifecycle.describe(closure)

    assert {:ok, diagnosis} = Ipse.Session.Saved.inspect_saved(c.dir, state.id)
    refute Map.has_key?(diagnosis, "cleanup_confirmed")
    {:ok, resumed} = Session.start_link(Keyword.put(c.opts, :id, state.id))
    Process.unlink(resumed)
    assert :sys.get_state(:sys.get_state(resumed).lock_guard).mode == :legacy
    assert :ok = Session.close_confirmed(resumed)
  end

  test "close reports unknown when the actual lock helper dies before its release reply", c do
    {:ok, session} = Session.start_link(c.opts)
    Process.unlink(session)
    state = :sys.get_state(session)
    {:os_pid, native} = Port.info(state.lock, :os_pid)
    :ok = :sys.suspend(session)

    on_exit(fn ->
      if Process.alive?(session), do: :sys.resume(session)
      if Process.alive?(session), do: Process.exit(session, :kill)
    end)

    parent = self()
    writer_ref = Process.monitor(state.journal_writer)
    spawn(fn -> send(parent, {:close_result, Session.close_confirmed(session)}) end)
    wait_for_close(session, System.monotonic_time(:millisecond) + 5_000)
    {_, 0} = System.cmd("kill", ["-KILL", Integer.to_string(native)])
    wait_for_lock_loss(session, state.lock, System.monotonic_time(:millisecond) + 5_000)
    :ok = :sys.resume(session)
    assert_receive {:DOWN, ^writer_ref, :process, _, _}, 5_000
    assert_receive {:close_result, {:error, :cleanup_unconfirmed}}, 5_000
  end

  defp wait_for_close(session, deadline) do
    wait_until(session, deadline, fn messages ->
      Enum.any?(messages, &match?({:"$gen_call", _, :close}, &1))
    end)
  end

  defp wait_for_lock_loss(session, port, deadline) do
    wait_until(session, deadline, fn messages ->
      Enum.any?(messages, &match?({^port, {:exit_status, :lock_lost}}, &1))
    end)
  end

  defp wait_until(session, deadline, predicate) do
    {:messages, messages} = Process.info(session, :messages)

    unless predicate.(messages) do
      if System.monotonic_time(:millisecond) >= deadline, do: flunk("Session message timed out")
      Process.sleep(10)
      wait_until(session, deadline, predicate)
    end
  end
end
