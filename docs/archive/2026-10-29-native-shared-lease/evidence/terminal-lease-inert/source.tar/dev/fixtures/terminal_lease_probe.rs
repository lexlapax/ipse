//! Real-PTY, synthetic native owners for the inert four-lease guardian probe.
#[cfg(target_os = "linux")]
mod linux {
    use std::fs::{self, DirBuilder, File, OpenOptions};
    use std::io::{self, Read, Write};
    use std::os::fd::{AsRawFd, FromRawFd};
    use std::os::unix::fs::{DirBuilderExt, MetadataExt, OpenOptionsExt};
    use std::os::unix::process::CommandExt;
    use std::path::{Path, PathBuf};
    use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};
    use std::time::{Duration, Instant};
    #[repr(C)]
    struct Poll {
        fd: i32,
        events: i16,
        revents: i16,
    }
    unsafe extern "C" {
        fn poll(fds: *mut Poll, count: usize, timeout: i32) -> i32;
        fn posix_openpt(flags: i32) -> i32;
        fn grantpt(fd: i32) -> i32;
        fn unlockpt(fd: i32) -> i32;
        fn ptsname_r(fd: i32, buf: *mut i8, size: usize) -> i32;
        fn pipe2(fds: *mut i32, flags: i32) -> i32;
        fn fcntl(fd: i32, cmd: i32, ...) -> i32;
        fn dup2(from: i32, to: i32) -> i32;
        fn flock(fd: i32, op: i32) -> i32;
        fn kill(pid: i32, signal: i32) -> i32;
    }
    struct Owned(Child);
    impl Drop for Owned {
        fn drop(&mut self) {
            let _ = self.0.kill();
            let _ = self.0.wait();
        }
    }
    fn fail(msg: &str) -> io::Error {
        io::Error::other(msg)
    }
    fn frame<R: Read + AsRawFd>(r: &mut R) -> io::Result<(u8, Vec<u8>)> {
        let deadline = Instant::now() + Duration::from_secs(8);
        fn exact<R: Read + AsRawFd>(
            r: &mut R,
            mut out: &mut [u8],
            deadline: Instant,
        ) -> io::Result<()> {
            while !out.is_empty() {
                let left = deadline.saturating_duration_since(Instant::now());
                if left.is_zero() {
                    return Err(fail("frame timeout"));
                }
                let mut p = Poll {
                    fd: r.as_raw_fd(),
                    events: 1,
                    revents: 0,
                };
                let n = unsafe { poll(&mut p, 1, left.as_millis().max(1).min(5000) as i32) };
                if n < 0 && io::Error::last_os_error().kind() == io::ErrorKind::Interrupted {
                    continue;
                }
                if n <= 0 {
                    continue;
                }
                match r.read(out) {
                    Ok(0) => return Err(fail("frame EOF")),
                    Ok(n) => out = &mut out[n..],
                    Err(e)
                        if matches!(
                            e.kind(),
                            io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                        ) =>
                    {
                        ()
                    }
                    Err(e) => return Err(e),
                }
            }
            Ok(())
        }
        let mut header = [0; 5];
        exact(r, &mut header, deadline)?;
        let len = u32::from_be_bytes(header[1..].try_into().unwrap()) as usize;
        if len > 1024 {
            return Err(fail("frame too large"));
        }
        let mut body = vec![0; len];
        exact(r, &mut body, deadline)?;
        Ok((header[0], body))
    }
    fn packet<W: Write>(w: &mut W, tag: u8, body: &[u8]) -> io::Result<()> {
        w.write_all(&[tag])?;
        w.write_all(&(body.len() as u32).to_be_bytes())?;
        w.write_all(body)?;
        w.flush()
    }
    fn tx_frame(w: &mut ChildStdin, tag: u8, seq: u64, depth: u8, data: &[u8]) -> io::Result<()> {
        let mut body = seq.to_be_bytes().to_vec();
        body.push(depth);
        body.extend_from_slice(data);
        packet(w, tag, &body)
    }
    fn lock_owner(
        helper: &Path,
        dir: &Path,
    ) -> io::Result<(Owned, ChildStdin, ChildStdout, PathBuf)> {
        DirBuilder::new().mode(0o700).create(dir)?;
        let path = dir.join(".lock");
        let mut p = Owned(
            Command::new(helper)
                .args(["--transaction-lock", "30000"])
                .stdin(Stdio::piped())
                .stdout(Stdio::piped())
                .stderr(Stdio::null())
                .spawn()?,
        );
        let mut input = p.0.stdin.take().ok_or_else(|| fail("missing input"))?;
        let mut output = p.0.stdout.take().ok_or_else(|| fail("missing output"))?;
        tx_frame(&mut input, b'A', 1, 0, path.to_str().unwrap().as_bytes())?;
        if frame(&mut output)?.0 != b'A' {
            return Err(fail("lock failed"));
        }
        Ok((p, input, output, path))
    }
    fn control_owner(helper: &Path) -> io::Result<(Owned, ChildStdin, ChildStdout, u64, u64)> {
        let mut p = Owned(
            Command::new(helper)
                .arg("--owner-control-send-v1")
                .stdin(Stdio::piped())
                .stdout(Stdio::piped())
                .stderr(Stdio::null())
                .spawn()?,
        );
        let input =
            p.0.stdin
                .take()
                .ok_or_else(|| fail("missing owner input"))?;
        let mut output =
            p.0.stdout
                .take()
                .ok_or_else(|| fail("missing owner output"))?;
        if frame(&mut output)? != (b'R', b"owner-control-v1".to_vec()) {
            return Err(fail("owner readiness failed"));
        }
        let meta = fs::metadata(format!("/proc/{}/fd/0", p.0.id()))?;
        Ok((p, input, output, meta.dev(), meta.ino()))
    }
    fn tty() -> io::Result<(File, File)> {
        let fd = unsafe { posix_openpt(0x102) };
        if fd < 0 {
            return Err(io::Error::last_os_error());
        }
        let master = unsafe { File::from_raw_fd(fd) };
        if unsafe { grantpt(fd) } != 0 || unsafe { unlockpt(fd) } != 0 {
            return Err(io::Error::last_os_error());
        }
        let mut name = [0i8; 4096];
        if unsafe { ptsname_r(fd, name.as_mut_ptr(), name.len()) } != 0 {
            return Err(fail("tty name"));
        }
        let path = unsafe { std::ffi::CStr::from_ptr(name.as_ptr()) }
            .to_str()
            .map_err(|_| fail("tty path"))?;
        let slave = OpenOptions::new()
            .read(true)
            .write(true)
            .custom_flags(0x100)
            .open(path)?;
        Ok((master, slave))
    }
    fn pipes() -> io::Result<(File, File)> {
        let mut f = [-1; 2];
        if unsafe { pipe2(f.as_mut_ptr(), 0x80000) } != 0 {
            return Err(io::Error::last_os_error());
        }
        Ok((unsafe { File::from_raw_fd(f[0]) }, unsafe {
            File::from_raw_fd(f[1])
        }))
    }
    fn guardian(helper: &Path, slave: &File) -> io::Result<(Owned, File, File)> {
        let (read, write) = pipes()?;
        let (out, out_write) = pipes()?;
        let read_high = unsafe { fcntl(read.as_raw_fd(), 0, 64) };
        let out_high = unsafe { fcntl(out_write.as_raw_fd(), 0, 64) };
        if read_high < 0 || out_high < 0 {
            return Err(fail("dup descriptors"));
        }
        let high_read = unsafe { File::from_raw_fd(read_high) };
        let high_out = unsafe { File::from_raw_fd(out_high) };
        let mut cmd = Command::new(helper);
        cmd.args(["--operator-input", "5000", "v3-inert-lease-probe"])
            .stdin(Stdio::from(slave.try_clone()?))
            .stdout(Stdio::from(slave.try_clone()?))
            .stderr(Stdio::null());
        unsafe {
            cmd.pre_exec(move || {
                if dup2(read_high, 3) != 3 || dup2(out_high, 4) != 4 {
                    return Err(io::Error::last_os_error());
                }
                Ok(())
            });
        }
        let child = Owned(cmd.spawn()?);
        drop(cmd);
        drop(read);
        drop(out_write);
        drop(high_read);
        drop(high_out);
        Ok((child, write, out))
    }
    fn entry(pid: u32, name: &[u8; 16], secret: &[u8; 32], dev: u64, ino: u64) -> Vec<u8> {
        let mut b = pid.to_be_bytes().to_vec();
        b.extend(name);
        b.extend(secret);
        b.extend(dev.to_be_bytes());
        b.extend(ino.to_be_bytes());
        b
    }
    fn request(target: u32, name: &[u8; 16], secret: &[u8; 32], dev: u64, ino: u64) -> Vec<u8> {
        entry(target, name, secret, dev, ino)
    }
    fn held(path: &Path) -> io::Result<bool> {
        let file = OpenOptions::new().read(true).write(true).open(path)?;
        let result = unsafe { flock(file.as_raw_fd(), 2 | 4) };
        if result == 0 {
            Ok(false)
        } else if io::Error::last_os_error().kind() == io::ErrorKind::WouldBlock {
            Ok(true)
        } else {
            Err(io::Error::last_os_error())
        }
    }
    fn eventually_free(paths: &[PathBuf]) -> io::Result<()> {
        let deadline = Instant::now() + Duration::from_secs(5);
        loop {
            if paths.iter().all(|p| held(p).is_ok_and(|v| !v)) {
                return Ok(());
            }
            if Instant::now() >= deadline {
                return Err(fail("last holder remained"));
            }
            std::thread::sleep(Duration::from_millis(10));
        }
    }
    pub fn main() -> io::Result<()> {
        let args: Vec<_> = std::env::args_os().collect();
        if args.len() != 4 {
            return Err(fail(
                "usage: fixture ROOT HELPER normal|guardian-loss|reader-loss|owner-loss|owner-loss-collect",
            ));
        }
        let root = Path::new(&args[1]);
        let helper = Path::new(&args[2]);
        let mode = args[3].to_str().unwrap_or("");
        if !matches!(
            mode,
            "normal" | "guardian-loss" | "reader-loss" | "owner-loss" | "owner-loss-collect"
        ) {
            return Err(fail("bad mode"));
        }
        let mut locks = Vec::new();
        for i in 0..4 {
            locks.push(lock_owner(helper, &root.join(format!("lock-{i}")))?);
        }
        let mut session = control_owner(helper)?;
        let mut host = control_owner(helper)?;
        let (master, slave) = tty()?;
        let (mut guardian, mut input, mut output) = guardian(helper, &slave)?;
        let operation = [37u8; 16];
        let mut names = [[0u8; 16]; 6];
        let mut secrets = [[0u8; 32]; 6];
        for i in 0..6 {
            names[i] = [(40 + i) as u8; 16];
            secrets[i] = [(60 + i) as u8; 32];
            names[i][..4].copy_from_slice(&std::process::id().to_be_bytes());
        }
        let mut body = operation.to_vec();
        body.push(4);
        body.extend(entry(
            session.0 .0.id(),
            &names[0],
            &secrets[0],
            session.3,
            session.4,
        ));
        body.extend(entry(
            host.0 .0.id(),
            &names[1],
            &secrets[1],
            host.3,
            host.4,
        ));
        for i in 0..4 {
            let m = fs::metadata(&locks[i].3)?;
            body.push(0);
            body.extend(operation);
            body.extend(entry(
                locks[i].0 .0.id(),
                &names[i + 2],
                &secrets[i + 2],
                m.dev(),
                m.ino(),
            ));
        }
        packet(&mut input, b'I', &body)?;
        let mut summary = operation.to_vec();
        summary.push(4);
        if frame(&mut output)? != (b'H', summary.clone()) {
            return Err(fail("guardian not ready"));
        }
        for (index, owner) in [&mut session, &mut host].into_iter().enumerate() {
            let mut req = operation.to_vec();
            req.push((index + 1) as u8);
            req.extend(guardian.0.id().to_be_bytes());
            req.extend(names[index]);
            req.extend(secrets[index]);
            packet(&mut owner.1, b'I', &req)?;
            if frame(&mut owner.2)?.0 != b'H' || frame(&mut owner.2)?.0 != b'T' {
                return Err(fail("owner transfer unconfirmed"));
            }
            if index == 0 && mode == "owner-loss-collect" {
                owner.0 .0.kill()?;
                owner.0 .0.wait()?;
                if guardian.0.wait()?.success() {
                    return Err(fail("partial owner loss falsely confirmed"));
                }
                if let Ok((b'C', _)) = frame(&mut output) {
                    return Err(fail("partial owner loss emitted a close receipt"));
                }
                let mut visible = Poll {
                    fd: master.as_raw_fd(),
                    events: 1,
                    revents: 0,
                };
                if unsafe { poll(&mut visible, 1, 0) } != 0 {
                    return Err(fail("inert probe wrote to tty"));
                }
                let paths: Vec<_> = locks.iter().map(|v| v.3.clone()).collect();
                for (p, _, _, _) in &mut locks {
                    p.0.kill()?;
                    p.0.wait()?;
                }
                eventually_free(&paths)?;
                println!("TTY_LEASE_PARTIAL_COLLECTION_OWNER_LOSS_CLEANED");
                return Ok(());
            }
        }
        for i in 0..4 {
            let meta = fs::metadata(&locks[i].3)?;
            let mut data = vec![0];
            data.extend(operation);
            data.extend(request(
                guardian.0.id(),
                &names[i + 2],
                &secrets[i + 2],
                meta.dev(),
                meta.ino(),
            ));
            tx_frame(&mut locks[i].1, b'Y', 2, 1, &data)?;
            if frame(&mut locks[i].2)?.0 != b'Y' {
                return Err(fail("lease transfer failed"));
            }
        }
        let (tag, collected) = frame(&mut output)?;
        if tag != b'L' || collected.len() != 21 || collected[..17] != summary {
            return Err(fail("fork collection failed"));
        }
        let mut visible = Poll {
            fd: master.as_raw_fd(),
            events: 1,
            revents: 0,
        };
        if unsafe { poll(&mut visible, 1, 0) } != 0 {
            return Err(fail("inert probe wrote to tty"));
        }
        let reader = u32::from_be_bytes(collected[17..21].try_into().unwrap()) as i32;
        let paths: Vec<_> = locks.iter().map(|v| v.3.clone()).collect();
        for p in &paths {
            if !held(p)? {
                return Err(fail("lease not held"));
            }
        }
        if mode == "guardian-loss" {
            if unsafe { kill(reader, 19) } != 0 {
                return Err(fail("reader stop failed"));
            }
            guardian.0.kill()?;
            guardian.0.wait()?;
            for (p, _, _, _) in &mut locks {
                p.0.kill()?;
                p.0.wait()?;
            }
            for p in &paths {
                if !held(p)? {
                    unsafe {
                        kill(reader, 18);
                    };
                    return Err(fail("stopped reader lost lease"));
                }
            }
            if unsafe { kill(reader, 18) } != 0 {
                return Err(fail("reader continue failed"));
            }
            eventually_free(&paths)?;
            println!("TTY_LEASE_GUARDIAN_LOSS_RETAINED_UNTIL_READER_EXIT");
            return Ok(());
        }
        if mode == "reader-loss" {
            if unsafe { kill(reader, 9) } != 0 {
                return Err(fail("reader kill failed"));
            }
            input.write_all(b"C")?;
            input.write_all(&operation)?;
            input.flush()?;
            if guardian.0.wait()?.success() {
                return Err(fail("reader loss falsely confirmed"));
            }
            if let Ok((b'C', _)) = frame(&mut output) {
                return Err(fail("reader loss emitted a close receipt"));
            }
            for p in &paths {
                if !held(p)? {
                    return Err(fail("exporter lost original lease"));
                }
            }
            for (p, _, _, _) in &mut locks {
                p.0.kill()?;
                p.0.wait()?;
            }
            eventually_free(&paths)?;
            println!("TTY_LEASE_READER_LOSS_UNCONFIRMED_AND_CLEANED");
            return Ok(());
        }
        if mode == "owner-loss" {
            session.0 .0.kill()?;
            session.0 .0.wait()?;
            if guardian.0.wait()?.success() {
                return Err(fail("owner loss falsely confirmed"));
            }
            if let Ok((b'C', _)) = frame(&mut output) {
                return Err(fail("owner loss emitted a close receipt"));
            }
            for p in &paths {
                if !held(p)? {
                    return Err(fail("exporter lost original lease"));
                }
            }
            for (p, _, _, _) in &mut locks {
                p.0.kill()?;
                p.0.wait()?;
            }
            eventually_free(&paths)?;
            println!("TTY_LEASE_OWNER_LOSS_UNCONFIRMED_AND_CLEANED");
            return Ok(());
        }
        input.write_all(b"C")?;
        input.write_all(&operation)?;
        input.flush()?;
        for (p, writer, output, _) in &mut locks {
            let mut data = vec![0];
            data.extend(operation);
            tx_frame(writer, b'K', 3, 1, &data)?;
            let (kind, _) = frame(output)?;
            if kind != b'K' {
                return Err(fail("settlement failed"));
            }
            let _ = p;
        }
        if frame(&mut output)? != (b'C', summary) || !guardian.0.wait()?.success() {
            return Err(fail("guardian close failed"));
        }
        for p in &paths {
            if !held(p)? {
                return Err(fail("original exporter unexpectedly lost lease"));
            }
        }
        for (p, writer, output, _) in &mut locks {
            tx_frame(writer, b'R', 4, 1, &[])?;
            if frame(output)?.0 != b'R' || !p.0.wait()?.success() {
                return Err(fail("original release failed"));
            }
        }
        eventually_free(&paths)?;
        println!("TTY_FOUR_LEASES_TWO_OWNER_CONTROLS_REAPED_AND_SETTLED");
        Ok(())
    }
}
#[cfg(target_os = "linux")]
fn main() {
    if let Err(e) = linux::main() {
        eprintln!("{e}");
        std::process::exit(1);
    }
}
#[cfg(not(target_os = "linux"))]
fn main() {
    std::process::exit(1);
}
