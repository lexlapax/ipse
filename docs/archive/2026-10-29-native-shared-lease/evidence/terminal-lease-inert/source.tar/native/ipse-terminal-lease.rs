//! Inert matched-tty guardian/reader lease-ownership probe. It never writes
//! the terminal or accepts protected payloads; no user-facing mode invokes it.
use crate::ipse_lease_sink as sink;
use crate::ipse_owner_control as controls;
use std::fs::File;
use std::io::{self, Read, Write};
use std::os::fd::{AsRawFd, FromRawFd};
use std::os::unix::net::UnixStream;
use std::time::{Duration, Instant};

#[repr(C)]
struct Poll {
    fd: i32,
    events: i16,
    revents: i16,
}
unsafe extern "C" {
    fn poll(fds: *mut Poll, count: usize, timeout: i32) -> i32;
    fn pipe2(fds: *mut i32, flags: i32) -> i32;
    fn fork() -> i32;
    fn kill(pid: i32, signal: i32) -> i32;
    fn waitpid(pid: i32, status: *mut i32, options: i32) -> i32;
    fn _exit(status: i32) -> !;
}
const INPUT: i16 = 1;
const OUTPUT: i16 = 4;
const BAD: i16 = 8 | 16 | 32;
fn err() -> String {
    "terminal lease probe unavailable".into()
}

struct ChildGuard(i32);
impl Drop for ChildGuard {
    fn drop(&mut self) {
        if self.0 <= 0 {
            return;
        }
        unsafe {
            kill(self.0, 9);
        }
        let mut status = 0;
        loop {
            let n = unsafe { waitpid(self.0, &mut status, 0) };
            if n == self.0
                || (n < 0 && io::Error::last_os_error().kind() != io::ErrorKind::Interrupted)
            {
                break;
            }
        }
    }
}

fn frame(
    output: &mut File,
    control: i32,
    watched: &[i32],
    kind: u8,
    body: &[u8],
    deadline: Instant,
) -> Result<(), String> {
    let mut frame = vec![kind];
    frame.extend_from_slice(&(body.len() as u32).to_be_bytes());
    frame.extend_from_slice(body);
    let mut at = 0;
    while at < frame.len() {
        sink::ready_watch(output.as_raw_fd(), OUTPUT, control, watched, deadline)
            .map_err(|_| err())?;
        match output.write(&frame[at..]) {
            Ok(0) => return Err(err()),
            Ok(n) => at += n,
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(_) => return Err(err()),
        }
    }
    Ok(())
}

fn read_command(
    control: &mut File,
    watched: &[i32],
    deadline: Instant,
    out: &mut [u8],
) -> Result<(), String> {
    let mut at = 0;
    while at < out.len() {
        let left = deadline.saturating_duration_since(Instant::now());
        if left.is_zero() {
            return Err(err());
        }
        let mut fds = vec![Poll {
            fd: control.as_raw_fd(),
            events: INPUT,
            revents: 0,
        }];
        fds.extend(watched.iter().map(|fd| Poll {
            fd: *fd,
            events: INPUT,
            revents: 0,
        }));
        let n = unsafe {
            poll(
                fds.as_mut_ptr(),
                fds.len(),
                left.as_millis().max(1).min(20) as i32,
            )
        };
        if n < 0 && io::Error::last_os_error().kind() == io::ErrorKind::Interrupted {
            continue;
        }
        if n < 0 || fds[0].revents & BAD != 0 || fds.iter().skip(1).any(|p| p.revents != 0) {
            return Err(err());
        }
        if fds[0].revents & INPUT == 0 {
            continue;
        }
        match control.read(&mut out[at..]) {
            Ok(0) => return Err(err()),
            Ok(n) => at += n,
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(_) => return Err(err()),
        }
    }
    Ok(())
}

fn send_peer(
    peer: &mut UnixStream,
    bytes: &[u8],
    control: i32,
    watched: &[i32],
    deadline: Instant,
) -> Result<(), String> {
    let mut at = 0;
    while at < bytes.len() {
        sink::ready_watch(peer.as_raw_fd(), OUTPUT, control, watched, deadline)
            .map_err(|_| err())?;
        match peer.write(&bytes[at..]) {
            Ok(0) => return Err(err()),
            Ok(n) => at += n,
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(_) => return Err(err()),
        }
    }
    Ok(())
}
fn read_peer(
    peer: &mut UnixStream,
    bytes: &mut [u8],
    control: i32,
    watched: &[i32],
    deadline: Instant,
) -> Result<(), String> {
    let mut at = 0;
    while at < bytes.len() {
        sink::ready_watch(peer.as_raw_fd(), INPUT, control, watched, deadline)
            .map_err(|_| err())?;
        match peer.read(&mut bytes[at..]) {
            Ok(0) => return Err(err()),
            Ok(n) => at += n,
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(_) => return Err(err()),
        }
    }
    Ok(())
}

pub(crate) fn run(
    mut control: File,
    mut output: File,
    tty: File,
    channel: File,
    deadline: Instant,
) -> Result<(), String> {
    sink::nonblocking(control.as_raw_fd()).map_err(|_| err())?;
    sink::nonblocking(output.as_raw_fd()).map_err(|_| err())?;
    let control_fd = control.as_raw_fd();
    let mut header = [0u8; 5];
    sink::read_exact(&mut control, &mut header, None, None, deadline).map_err(|_| err())?;
    let size = u32::from_be_bytes(header[1..].try_into().unwrap()) as usize;
    if header[0] != b'I' || !(238..=493).contains(&size) {
        return Err(err());
    }
    let mut body = vec![0u8; size];
    sink::read_exact(&mut control, &mut body, None, None, deadline).map_err(|_| err())?;
    let operation: [u8; 16] = body[..16].try_into().unwrap();
    let count = body[16] as usize;
    if operation.iter().all(|b| *b == 0) || !(1..=4).contains(&count) || size != 153 + 85 * count {
        return Err(err());
    }
    let session_entry = &body[17..85];
    let host_entry = &body[85..153];
    let mut raw = Vec::new();
    for entry in [session_entry, host_entry] {
        raw.push(entry);
    }
    let mut requests = Vec::new();
    for chunk in body[153..].chunks_exact(85) {
        if chunk[0] > 2 || chunk[1..17].iter().all(|b| *b == 0) {
            return Err(err());
        }
        let op: [u8; 16] = chunk[1..17].try_into().unwrap();
        requests.push((chunk[0], op, &chunk[17..85]));
        raw.push(&chunk[17..85]);
    }
    for (i, a) in raw.iter().enumerate() {
        for b in raw.iter().skip(i + 1) {
            if a[4..20] == b[4..20] || a[20..52] == b[20..52] || a[52..68] == b[52..68] {
                return Err(err());
            }
        }
    }
    let mut ready = operation.to_vec();
    ready.push(count as u8);
    frame(&mut output, control_fd, &[], b'H', &ready, deadline)?;
    let mut owners = Vec::new();
    let mut watched = Vec::new();
    for (role, entry) in [(1, session_entry), (2, host_entry)] {
        let (owner, expected, peer) =
            controls::collect(entry, &operation, role, control_fd, &watched, deadline)?;
        watched.extend([
            owner.as_raw_fd(),
            expected.process.as_raw_fd(),
            peer.as_raw_fd(),
        ]);
        owners.push((owner, expected, peer));
    }
    let mut leases = Vec::new();
    let mut entries = Vec::new();
    let mut peers = Vec::new();
    for (slot, op, bytes) in requests {
        let item = sink::expected(bytes).map_err(|_| err())?;
        if entries
            .iter()
            .any(|(prior_slot, _, old): &(u8, [u8; 16], sink::Expected)| {
                *prior_slot == slot && old.pid == item.pid
            })
        {
            return Err(err());
        }
        let mut peer =
            sink::open_peer_watch(&item, control_fd, &watched, deadline).map_err(|_| err())?;
        let lease =
            sink::receive_watch(&peer, &item, control_fd, &watched, deadline).map_err(|_| err())?;
        let mut guards = watched.clone();
        guards.push(item.process.as_raw_fd());
        send_peer(&mut peer, b"A", control_fd, &guards, deadline)?;
        watched.push(item.process.as_raw_fd());
        leases.push(lease);
        entries.push((slot, op, item));
        peers.push(peer);
    }
    // Both forked processes inherit every exact lease and owner descriptor.
    let mut pipe = [-1; 2];
    if unsafe { pipe2(pipe.as_mut_ptr(), 0x80000 | 0x800) } != 0 {
        return Err(err());
    }
    let mut reader_control = unsafe { File::from_raw_fd(pipe[0]) };
    let mut guardian_control = unsafe { File::from_raw_fd(pipe[1]) };
    let child = unsafe { fork() };
    if child < 0 {
        return Err(err());
    }
    if child == 0 {
        drop(guardian_control);
        let mut fds = vec![Poll {
            fd: reader_control.as_raw_fd(),
            events: INPUT,
            revents: 0,
        }];
        fds.extend(watched.iter().map(|fd| Poll {
            fd: *fd,
            events: INPUT,
            revents: 0,
        }));
        loop {
            let n = unsafe { poll(fds.as_mut_ptr(), fds.len(), 20) };
            if n < 0 && io::Error::last_os_error().kind() == io::ErrorKind::Interrupted {
                continue;
            }
            if n < 0 || fds.iter().skip(1).any(|p| p.revents != 0) || fds[0].revents & BAD != 0 {
                unsafe { _exit(2) }
            }
            if fds[0].revents & INPUT != 0 {
                let mut byte = [0];
                let success = matches!(reader_control.read(&mut byte), Ok(1)) && byte == [b'C'];
                unsafe { _exit(if success { 0 } else { 2 }) }
            }
        }
    }
    drop(reader_control);
    let mut child_guard = ChildGuard(child);
    let mut collected = ready.clone();
    collected.extend_from_slice(&(child as u32).to_be_bytes());
    frame(
        &mut output,
        control_fd,
        &watched,
        b'L',
        &collected,
        deadline,
    )?;
    let mut close = [0u8; 17];
    read_command(&mut control, &watched, deadline, &mut close)?;
    if close[0] != b'C' || close[1..] != operation {
        return Err(err());
    }
    guardian_control.write_all(b"C").map_err(|_| err())?;
    let mut status = 0;
    loop {
        let n = unsafe { waitpid(child, &mut status, 1) };
        if n == child {
            break;
        }
        if n < 0 && io::Error::last_os_error().kind() != io::ErrorKind::Interrupted {
            return Err(err());
        }
        if Instant::now() >= deadline
            || !crate::ipse_lease_transfer::control_quiet(control_fd)
            || watched
                .iter()
                .any(|fd| !crate::ipse_lease_transfer::control_quiet(*fd))
        {
            return Err(err());
        }
        std::thread::sleep(Duration::from_millis(1));
    }
    child_guard.0 = -1;
    if status != 0 {
        return Err(err());
    }
    drop(leases);
    for (index, (slot, op, _)) in entries.iter().enumerate() {
        let mut receipt = [0u8; 18];
        receipt[0] = b'C';
        receipt[1..17].copy_from_slice(op);
        receipt[17] = *slot;
        send_peer(&mut peers[index], &receipt, control_fd, &watched, deadline)?;
    }
    for (index, (slot, op, _)) in entries.iter().enumerate() {
        let mut ack = [0u8; 18];
        read_peer(&mut peers[index], &mut ack, control_fd, &watched, deadline)?;
        if ack[0] != b'F' || ack[1..17] != *op || ack[17] != *slot {
            return Err(err());
        }
        ack[0] = b'G';
        send_peer(&mut peers[index], &ack, control_fd, &watched, deadline)?;
        let mut fds = [Poll {
            fd: peers[index].as_raw_fd(),
            events: INPUT,
            revents: 0,
        }];
        loop {
            if Instant::now() >= deadline
                || !crate::ipse_lease_transfer::control_quiet(control_fd)
                || watched
                    .iter()
                    .any(|fd| !crate::ipse_lease_transfer::control_quiet(*fd))
            {
                return Err(err());
            }
            let n = unsafe { poll(fds.as_mut_ptr(), fds.len(), 10) };
            if n < 0 && io::Error::last_os_error().kind() == io::ErrorKind::Interrupted {
                continue;
            }
            if n < 0 || fds[0].revents & (8 | 32) != 0 {
                return Err(err());
            }
            if fds[0].revents & (INPUT | 16) != 0 {
                let mut byte = [0u8; 1];
                match peers[index].read(&mut byte) {
                    Ok(0) => break,
                    Err(e)
                        if matches!(
                            e.kind(),
                            io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                        ) =>
                    {
                        ()
                    }
                    _ => return Err(err()),
                }
            }
        }
    }
    // Retain matched tty, channel, owner controls and peer state until all
    // original exporters have completed their per-slot close protocol.
    drop((tty, channel, owners, peers));
    frame(&mut output, control_fd, &[], b'C', &ready, deadline)?;
    Ok(())
}
