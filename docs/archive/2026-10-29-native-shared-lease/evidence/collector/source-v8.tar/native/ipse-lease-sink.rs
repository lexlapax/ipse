//! Inert Linux lease collector. This mode cannot display or deliver payloads.
//! It authenticates the process and file identity of each transferred lease,
//! retains the descriptions, and reports a close only after dropping them.
use std::ffi::c_void;
use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::mem::size_of;
use std::os::fd::{AsRawFd, FromRawFd};
use std::os::unix::fs::MetadataExt;
use std::os::unix::net::UnixStream;
use std::time::{Duration, Instant};

#[repr(C)]
struct Poll {
    fd: i32,
    events: i16,
    revents: i16,
}
#[repr(C)]
struct Peer {
    pid: i32,
    uid: u32,
    gid: u32,
}
#[repr(C)]
struct IoVec {
    base: *mut c_void,
    len: usize,
}
#[repr(C)]
struct Message {
    name: *mut c_void,
    name_len: u32,
    iov: *mut IoVec,
    iov_len: usize,
    control: *mut c_void,
    control_len: usize,
    flags: i32,
}
#[repr(C)]
struct Header {
    len: usize,
    level: i32,
    kind: i32,
}
#[repr(C, align(8))]
struct Control([u8; 4096]);
#[repr(C)]
struct Address {
    family: u16,
    path: [u8; 108],
}
unsafe extern "C" {
    fn poll(fds: *mut Poll, count: usize, timeout: i32) -> i32;
    fn socket(domain: i32, kind: i32, protocol: i32) -> i32;
    fn connect(fd: i32, address: *const c_void, len: u32) -> i32;
    fn getsockopt(fd: i32, level: i32, name: i32, value: *mut c_void, length: *mut u32) -> i32;
    fn recvmsg(fd: i32, message: *mut Message, flags: i32) -> isize;
    fn fcntl(fd: i32, command: i32, ...) -> i32;
    #[cfg(any(target_arch = "x86_64", target_arch = "aarch64"))]
    fn syscall(number: i64, ...) -> i64;
    fn geteuid() -> u32;
}

const INPUT: i16 = 1;
const OUTPUT: i16 = 4;
const BAD: i16 = 8 | 16 | 32;
// Up to 128 external sources, the separately held live Session, and Identity
// plus Consent. The live Session can exist even if no proof refers to it.
const MAX_LEASES: usize = 131;
const ENTRY_SIZE: usize = 68;

struct Expected {
    pid: u32,
    name: [u8; 16],
    secret: [u8; 32],
    dev: u64,
    ino: u64,
    process: File,
}

fn error() -> io::Error {
    io::Error::other("lease collection refused")
}

fn ready(
    fd: i32,
    events: i16,
    control: Option<i32>,
    process: Option<i32>,
    deadline: Instant,
) -> io::Result<()> {
    loop {
        let left = deadline.saturating_duration_since(Instant::now());
        if left.is_zero() {
            return Err(error());
        }
        let mut fds = [
            Poll {
                fd,
                events,
                revents: 0,
            },
            Poll {
                fd: control.unwrap_or(-1),
                events: INPUT,
                revents: 0,
            },
            Poll {
                fd: process.unwrap_or(-1),
                events: INPUT,
                revents: 0,
            },
        ];
        let result = unsafe {
            poll(
                fds.as_mut_ptr(),
                fds.len(),
                left.as_millis().max(1).min(i32::MAX as u128) as i32,
            )
        };
        if result < 0 {
            let e = io::Error::last_os_error();
            if e.kind() == io::ErrorKind::Interrupted {
                continue;
            }
            return Err(e);
        }
        if fds[1].revents != 0 || fds[2].revents != 0 || fds[0].revents & BAD != 0 {
            return Err(error());
        }
        if fds[0].revents & events != 0 {
            return Ok(());
        }
    }
}

fn read_exact<R: Read + AsRawFd>(
    input: &mut R,
    bytes: &mut [u8],
    control: Option<i32>,
    process: Option<i32>,
    deadline: Instant,
) -> io::Result<()> {
    let mut at = 0;
    while at < bytes.len() {
        ready(input.as_raw_fd(), INPUT, control, process, deadline)?;
        match input.read(&mut bytes[at..]) {
            Ok(0) => return Err(error()),
            Ok(n) => at += n,
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(e) => return Err(e),
        }
    }
    Ok(())
}

fn nonblocking(fd: i32) -> io::Result<()> {
    let flags = unsafe { fcntl(fd, 3) };
    if flags < 0 || unsafe { fcntl(fd, 4, flags | 0x800) } < 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(())
}

fn pidfd(pid: u32) -> io::Result<File> {
    // Linux pidfd_open has the same syscall number on x86-64 and aarch64.
    #[cfg(any(target_arch = "x86_64", target_arch = "aarch64"))]
    let fd = unsafe { syscall(434, pid, 0u32) };
    #[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
    let fd = -1;
    if fd < 0 {
        return Err(error());
    }
    Ok(unsafe { File::from_raw_fd(fd as i32) })
}

fn same_helper(pid: u32) -> io::Result<()> {
    let mine = fs::metadata("/proc/self/exe")?;
    let peer = fs::metadata(format!("/proc/{pid}/exe"))?;
    if mine.dev() != peer.dev() || mine.ino() != peer.ino() {
        return Err(error());
    }
    Ok(())
}

fn expected(entry: &[u8]) -> io::Result<Expected> {
    let pid = u32::from_be_bytes(entry[0..4].try_into().unwrap());
    let name: [u8; 16] = entry[4..20].try_into().unwrap();
    let secret: [u8; 32] = entry[20..52].try_into().unwrap();
    let dev = u64::from_be_bytes(entry[52..60].try_into().unwrap());
    let ino = u64::from_be_bytes(entry[60..68].try_into().unwrap());
    if pid == 0 || name.iter().all(|x| *x == 0) || secret.iter().all(|x| *x == 0) || ino == 0 {
        return Err(error());
    }
    let process = pidfd(pid)?;
    same_helper(pid)?;
    Ok(Expected {
        pid,
        name,
        secret,
        dev,
        ino,
        process,
    })
}

fn open_peer(item: &Expected, deadline: Instant) -> io::Result<UnixStream> {
    let mut address = Address {
        family: 1,
        path: [0; 108],
    };
    address.path[1..15].copy_from_slice(b"ipse-lease-v1-");
    address.path[15..31].copy_from_slice(&item.name);
    let mut stream = loop {
        let fd = unsafe { socket(1, 1 | 0x800 | 0x80000, 0) };
        if fd < 0 {
            return Err(io::Error::last_os_error());
        }
        let stream = unsafe { UnixStream::from_raw_fd(fd) };
        let result = unsafe {
            connect(
                fd,
                (&address as *const Address).cast(),
                (size_of::<u16>() + 31) as u32,
            )
        };
        if result == 0 {
            break stream;
        }
        let cause = io::Error::last_os_error();
        if !matches!(
            cause.kind(),
            io::ErrorKind::NotFound | io::ErrorKind::ConnectionRefused | io::ErrorKind::WouldBlock
        ) {
            return Err(cause);
        }
        let left = deadline.saturating_duration_since(Instant::now());
        if left.is_zero() {
            return Err(error());
        }
        let mut fds = [
            Poll {
                fd: 0,
                events: INPUT,
                revents: 0,
            },
            Poll {
                fd: item.process.as_raw_fd(),
                events: INPUT,
                revents: 0,
            },
        ];
        let result = unsafe {
            poll(
                fds.as_mut_ptr(),
                fds.len(),
                left.as_millis().max(1).min(5) as i32,
            )
        };
        if result < 0 && io::Error::last_os_error().kind() != io::ErrorKind::Interrupted {
            return Err(error());
        }
        if fds.iter().any(|fd| fd.revents != 0) {
            return Err(error());
        }
    };
    let fd = stream.as_raw_fd();
    let mut peer = Peer {
        pid: 0,
        uid: 0,
        gid: 0,
    };
    let mut len = size_of::<Peer>() as u32;
    if unsafe { getsockopt(fd, 1, 17, (&mut peer as *mut Peer).cast(), &mut len) } != 0
        || len as usize != size_of::<Peer>()
        || peer.pid <= 0
        || peer.pid as u32 != item.pid
        || peer.uid != unsafe { geteuid() }
    {
        return Err(error());
    }
    same_helper(item.pid)?;
    let mut at = 0;
    while at < item.secret.len() {
        ready(
            fd,
            OUTPUT,
            Some(0),
            Some(item.process.as_raw_fd()),
            deadline,
        )?;
        match stream.write(&item.secret[at..]) {
            Ok(0) => return Err(error()),
            Ok(n) => at += n,
            Err(e)
                if matches!(
                    e.kind(),
                    io::ErrorKind::Interrupted | io::ErrorKind::WouldBlock
                ) =>
            {
                ()
            }
            Err(e) => return Err(e),
        }
    }
    Ok(stream)
}

fn receive(stream: &UnixStream, item: &Expected, deadline: Instant) -> io::Result<File> {
    ready(
        stream.as_raw_fd(),
        INPUT,
        Some(0),
        Some(item.process.as_raw_fd()),
        deadline,
    )?;
    let mut byte = [0u8];
    let mut iov = IoVec {
        base: byte.as_mut_ptr().cast(),
        len: 1,
    };
    let mut control = Control([0; 4096]);
    let mut message = Message {
        name: std::ptr::null_mut(),
        name_len: 0,
        iov: &mut iov,
        iov_len: 1,
        control: control.0.as_mut_ptr().cast(),
        control_len: control.0.len(),
        flags: 0,
    };
    let result = unsafe { recvmsg(stream.as_raw_fd(), &mut message, 0x4000_0000) };
    let mut files = Vec::new();
    let mut offset = 0usize;
    let mut valid = true;
    while offset + size_of::<Header>() <= message.control_len {
        let header = unsafe { &*(control.0.as_ptr().add(offset).cast::<Header>()) };
        if header.len < size_of::<Header>() || header.len > message.control_len - offset {
            valid = false;
            break;
        }
        let count = header.len - size_of::<Header>();
        if header.level == 1 && header.kind == 1 && count % size_of::<i32>() == 0 {
            for index in 0..count / size_of::<i32>() {
                let ptr = unsafe {
                    control
                        .0
                        .as_ptr()
                        .add(offset + size_of::<Header>() + index * size_of::<i32>())
                };
                let fd = unsafe { std::ptr::read_unaligned(ptr.cast::<i32>()) };
                if fd < 0 {
                    valid = false;
                } else {
                    files.push(unsafe { File::from_raw_fd(fd) });
                }
            }
        } else {
            valid = false;
        }
        offset += (header.len + size_of::<usize>() - 1) & !(size_of::<usize>() - 1);
    }
    if result != 1 || byte != [b'L'] || message.flags & 8 != 0 || !valid || files.len() != 1 {
        return Err(error());
    }
    let file = files.pop().unwrap();
    let m = file.metadata()?;
    let flags = unsafe { fcntl(file.as_raw_fd(), 1) };
    if flags < 0
        || flags & 1 == 0
        || !m.is_file()
        || m.uid() != unsafe { geteuid() }
        || m.nlink() != 1
        || m.mode() & 0o7777 != 0o600
        || m.len() != 0
        || m.dev() != item.dev
        || m.ino() != item.ino
    {
        return Err(error());
    }
    Ok(file)
}

pub(crate) fn run(args: &[String]) -> Result<(), String> {
    if args.len() != 2 {
        return Err("invalid lease collector arguments".into());
    }
    nonblocking(0).map_err(|_| "lease collector unavailable")?;
    // Read the descriptor directly: Stdin's buffered reader can prefetch the
    // body, leaving poll unable to observe those already buffered bytes.
    let mut input = unsafe { File::from_raw_fd(0) };
    let setup_deadline = Instant::now() + Duration::from_secs(5);
    let mut header = [0u8; 5];
    read_exact(&mut input, &mut header, None, None, setup_deadline)
        .map_err(|_| "lease collector request unavailable")?;
    let len = u32::from_be_bytes(header[1..].try_into().unwrap()) as usize;
    if header[0] != b'I' || len < 9 || len > 9 + ENTRY_SIZE * MAX_LEASES {
        return Err("invalid lease collector request".into());
    }
    let mut body = vec![0; len];
    read_exact(&mut input, &mut body, None, None, setup_deadline)
        .map_err(|_| "lease collector request unavailable")?;
    let ms = u64::from_be_bytes(body[..8].try_into().unwrap());
    let count = body[8] as usize;
    if !(1..=30_000).contains(&ms)
        || count == 0
        || count > MAX_LEASES
        || len != 9 + count * ENTRY_SIZE
    {
        return Err("invalid lease collector request".into());
    }
    let deadline = Instant::now() + Duration::from_millis(ms);
    let mut expected_items = Vec::new();
    for entry in body[9..].chunks_exact(ENTRY_SIZE) {
        let item = expected(entry).map_err(|_| "lease helper unavailable")?;
        if expected_items
            .iter()
            .any(|old: &Expected| old.dev == item.dev && old.ino == item.ino)
        {
            return Err("duplicate lease identity".into());
        }
        expected_items.push(item);
    }
    let mut leases = Vec::new();
    let mut peers = Vec::new();
    for item in &expected_items {
        let mut peer = open_peer(item, deadline).map_err(|_| "lease helper unavailable")?;
        let file = receive(&peer, item, deadline).map_err(|_| "lease descriptor unavailable")?;
        ready(
            peer.as_raw_fd(),
            OUTPUT,
            Some(0),
            Some(item.process.as_raw_fd()),
            deadline,
        )
        .map_err(|_| "lease acknowledgment unavailable")?;
        peer.write_all(b"A")
            .map_err(|_| "lease acknowledgment unavailable")?;
        leases.push(file);
        peers.push(peer);
    }
    // This is a collection observation only; process death can still race the
    // following response and must be fenced separately before any future use.
    if Instant::now() >= deadline {
        return Err("lease collection expired".into());
    }
    let mut live = vec![Poll {
        fd: 0,
        events: INPUT,
        revents: 0,
    }];
    live.extend(expected_items.iter().map(|item| Poll {
        fd: item.process.as_raw_fd(),
        events: INPUT,
        revents: 0,
    }));
    if unsafe { poll(live.as_mut_ptr(), live.len(), 0) } != 0 {
        return Err("lease collection lost its owner or helper".into());
    }
    super::frame(b'L', &[count as u8]).map_err(|_| "lease collector output unavailable")?;
    let mut close = [0u8; 1];
    read_exact(&mut input, &mut close, None, None, deadline)
        .map_err(|_| "lease collector close unavailable")?;
    if close != [b'C'] {
        return Err("invalid lease collector close".into());
    }
    drop(leases);
    drop(peers);
    super::frame(b'C', &[count as u8]).map_err(|_| "lease collector output unavailable")?;
    Ok(())
}
