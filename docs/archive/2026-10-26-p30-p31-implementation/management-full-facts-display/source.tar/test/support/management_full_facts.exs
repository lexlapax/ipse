# Local trusted-source fixture; signed records and protected storage are real.
# This does not claim a genuine original assertion or Review permit.
ExUnit.start(autorun: false)
Code.require_file("../ipse/extension/collection_normalizer_v3_integration_test.exs", __DIR__)
import ExUnit.Assertions
alias Ipse.{JSON, Usage}
alias Ipse.CLI.Knowledge.Management

alias Ipse.Extension.{
  Artifact,
  Bundles,
  Consent,
  ProjectIdentity,
  SemanticAdmission,
  SemanticConsent
}

alias Ipse.Extension.CollectionNormalizerV3IntegrationTest, as: Fixture

defmodule Ipse.Test.ManagementDisplayProbe do
  def pause_close(owned, guardian) do
    send(Process.whereis(:management_display_probe), {:close_paused, self(), owned, guardian})

    receive do
      :continue -> :ok
    after
      10_000 -> :error
    end
  end

  def pause_snapshot do
    send(Process.whereis(:management_display_probe), {:snapshot_paused, self()})

    receive do
      :continue -> :ok
    after
      10_000 -> :error
    end
  end

  def pause(owned, reader, guardian, ids, journal) do
    send(
      Process.whereis(:management_display_probe),
      {:display_paused, self(), owned, reader, guardian, ids, journal}
    )

    receive do
      :continue -> :ok
    after
      10_000 -> :error
    end
  end

  def stopped?(pid, attempts \\ 500)
  def stopped?(_, 0), do: false

  def stopped?(pid, attempts) do
    case File.read("/proc/#{pid}/status") do
      {:ok, status} ->
        if Enum.any?(
             String.split(status, "\n"),
             &(String.starts_with?(&1, "State:") and String.contains?(&1, "stopped"))
           ),
           do: true,
           else:
             (
               Process.sleep(10)
               stopped?(pid, attempts - 1)
             )

      _ ->
        false
    end
  end

  def gone?(pid, attempts \\ 600)
  def gone?(_, 0), do: false

  def gone?(pid, attempts) do
    case File.read("/proc/#{pid}/stat") do
      {:error, :enoent} ->
        true

      {:ok, stat} ->
        if Regex.match?(~r/\) Z /, stat),
          do: true,
          else:
            (
              Process.sleep(10)
              gone?(pid, attempts - 1)
            )

      _ ->
        false
    end
  end

  def acquire(path, attempts \\ 600)
  def acquire(_, 0), do: {:error, :still_locked}

  def acquire(path, attempts) do
    case Ipse.Runner.protected_lock(path) do
      {:ok, _} = result ->
        result

      _ ->
        Process.sleep(10)
        acquire(path, attempts - 1)
    end
  end
end

[root | rest] = System.argv()
{:ok, _} = Application.ensure_all_started(:ipse)
home = Path.join(root, "home")
cwd = Path.join(root, "work")
File.mkdir_p!(home)
File.mkdir!(cwd)
File.chmod!(home, 0o700)
{:ok, binding} = ProjectIdentity.admit(home, cwd, :folder)
{:ok, namespace} = SemanticConsent.namespace(binding["project_id"], "knowledge")
assert {:ok, _} = Bundles.install("knowledge", home)
{:ok, entries} = Bundles.inventory()
%{digest: digest} = Enum.find(entries, &(&1.id == "knowledge"))

{:ok, sidecar_bytes} =
  Artifact.read_declared(Path.join(home, "extensions/artifacts"), digest, "operator.json", 65_536)

{:ok, sidecar} = JSON.decode_unique(sidecar_bytes)
opts = %{Fixture.options(1, 0) | recipe: sidecar["recipes"]["note"]}

opts =
  if rest == ["large"] do
    quote = String.duplicate("\\\"", 200)
    digest = JSON.sha256(quote)
    [original] = opts.verified_sources

    source =
      original
      |> Map.put("quote", quote)
      |> Map.put("end_byte", byte_size(quote))
      |> Map.put("quote_sha256", digest)
      |> Map.put("content_sha256", digest)

    {:ok, key, value} =
      IpseKnowledge.Knowledge.Records.capture(
        %{
          "text" => quote,
          "category" => "ordinary",
          "reason" => "trusted fixture source",
          "event_at_ms" => nil
        },
        source,
        10 * 86_400_000
      )

    %{
      opts
      | verified_sources: [source],
        request:
          put_in(opts.request, ["changes"], [
            %{"key" => key, "expected_revision" => 0, "value" => value}
          ])
    }
  else
    opts
  end

c = %{
  home: home,
  cwd: cwd,
  binding: binding,
  root: SemanticAdmission.collection_root(home),
  namespace: namespace
}

scope = %{
  namespace: namespace,
  format: "managed-metadata-v3",
  operation_id: Usage.id(),
  initialize: true
}

assert {:ok, _} = Fixture.publish(c, opts, scope, first: true)
[key] = Enum.map(opts.request["changes"], & &1["key"])

assert {:ok, %{"epoch" => 1}} =
         Consent.revoke(SemanticAdmission.control_root(home), binding["project_id"], 0)

if rest == ["closure-loss"] do
  source = File.read!("lib/ipse/runner/management_terminal.ex")
  needle = ":ok <- Resources.management_control_prepare_close(owned.cli_control),"
  assert length(String.split(source, needle)) == 2

  source =
    String.replace(
      source,
      needle,
      ":ok <- Ipse.Test.ManagementDisplayProbe.pause_close(owned, pid),\n             " <> needle
    )

  File.write!(Path.join(root, "management-terminal-close-instrumented.ex"), source)
  Code.compiler_options(ignore_module_conflict: true)

  [{Ipse.Runner.ManagementTerminal, beam}] =
    Code.compile_string(source, "management-terminal-close-instrumented.ex")

  File.write!(Path.join(root, "management-terminal-close-instrumented.beam"), beam)
  Process.register(self(), :management_display_probe)

  task =
    Task.async(fn ->
      Management.full_facts_display_candidate(
        %{home: home},
        cwd,
        key,
        "Forget selected synthetic claim"
      )
    end)

  assert_receive {:close_paused, effect, owned, guardian}, 5_000

  paths = [
    Path.join(owned.directory, owned.id <> ".lock"),
    Path.join([home, "project-identities", ".lock"]),
    Path.join([SemanticAdmission.control_root(home), binding["project_id"], ".lock"]),
    Path.join([SemanticAdmission.collection_root(home), namespace, ".lock"])
  ]

  for path <- paths, do: assert({:error, _} = Ipse.Runner.protected_lock(path))
  monitor = Process.monitor(effect)
  Process.exit(effect, :kill)
  assert_receive {:DOWN, ^monitor, :process, _, _}, 5_000
  assert {:unknown, _} = Task.await(task, 10_000)
  assert Ipse.Test.ManagementDisplayProbe.gone?(guardian)

  for path <- paths do
    assert {:ok, lock} = Ipse.Test.ManagementDisplayProbe.acquire(path)
    assert :ok = Ipse.Runner.unlock(lock)
  end

  IO.puts("\nMANAGEMENT_CLOSE_ACK_LOSS_UNKNOWN_NO_THAW_CLAIM")
else
  if rest == ["stale"] do
    source = File.read!("lib/ipse/cli/knowledge/management.ex")
    needle = "controlled_share_journal_candidate(config, cwd, overall, fn owned ->"
    assert length(String.split(source, needle)) == 2

    source =
      String.replace(
        source,
        needle,
        ":ok = Ipse.Test.ManagementDisplayProbe.pause_snapshot()\n      " <> needle
      )

    File.write!(Path.join(root, "management-instrumented.ex"), source)
    Code.compiler_options(ignore_module_conflict: true)

    [{Ipse.CLI.Knowledge.Management, beam}] =
      Code.compile_string(source, "management-instrumented.ex")

    File.write!(Path.join(root, "management-instrumented.beam"), beam)
    Process.register(self(), :management_display_probe)

    task =
      Task.async(fn ->
        Management.full_facts_display_candidate(
          %{home: home},
          cwd,
          key,
          "Forget selected synthetic claim"
        )
      end)

    assert_receive {:snapshot_paused, caller}, 5_000
    assert caller == task.pid

    assert {:ok, %{"epoch" => 2}} =
             Consent.revoke(SemanticAdmission.control_root(home), binding["project_id"], 1)

    send(caller, :continue)
    assert {:unknown, _} = Task.await(task, 10_000)
    IO.puts("MANAGEMENT_STALE_EPOCH_REFUSED_BEFORE_DISPLAY")
  else
    if rest in [["loss"], ["journal-loss"], ["cli-loss"]] do
      source = File.read!("lib/ipse/runner/management_terminal.ex")
      assert length(String.split(source, "_reader::32")) == 2
      source = String.replace(source, "_reader::32", "reader::32")
      needle = ":ok <- send_frame(port, ?A, body),"
      assert length(String.split(source, needle)) == 2

      source =
        String.replace(
          source,
          needle,
          needle <>
            "\n             :ok <- Ipse.Test.ManagementDisplayProbe.pause(owned, reader, pid, ids, journal),"
        )

      File.write!(Path.join(root, "management-terminal-instrumented.ex"), source)
      Code.compiler_options(ignore_module_conflict: true)

      [{Ipse.Runner.ManagementTerminal, beam}] =
        Code.compile_string(source, "management-terminal-instrumented.ex")

      File.write!(Path.join(root, "management-terminal-instrumented.beam"), beam)
      Process.register(self(), :management_display_probe)

      task =
        Task.async(fn ->
          Management.full_facts_display_candidate(
            %{home: home},
            cwd,
            key,
            "Forget selected synthetic claim"
          )
        end)

      Process.unlink(task.pid)
      assert_receive {:display_paused, effect, owned, reader, guardian, ids, journal}, 5_000
      assert owned.cli_owner == task.pid and owned.journal_owner == effect
      assert Ipse.Test.ManagementDisplayProbe.stopped?(reader)
      assert {_, 0} = System.cmd("kill", ["-STOP", Integer.to_string(guardian)])

      paths = [
        Path.join(owned.directory, owned.id <> ".lock"),
        Path.join([home, "project-identities", ".lock"]),
        Path.join([SemanticAdmission.control_root(home), binding["project_id"], ".lock"]),
        Path.join([SemanticAdmission.collection_root(home), namespace, ".lock"])
      ]

      try do
        caller_ref = Process.monitor(task.pid)
        effect_ref = Process.monitor(effect)

        if rest == ["loss"] or rest == ["cli-loss"] do
          Process.exit(task.pid, :kill)
          assert_receive {:DOWN, ^caller_ref, :process, _, _}, 5_000

          if rest == ["loss"] do
            Process.exit(effect, :kill)
            assert_receive {:DOWN, ^effect_ref, :process, _, _}, 5_000
          else
            assert Process.alive?(effect)
          end
        else
          Process.exit(effect, :kill)
          assert_receive {:DOWN, ^effect_ref, :process, _, _}, 5_000
          assert {:unknown, _} = Task.await(task, 10_000)
        end

        assert {_, 0} = System.cmd("kill", ["-KILL", Integer.to_string(guardian)])

        if rest != ["cli-loss"] do
          assert Ipse.Test.ManagementDisplayProbe.gone?(journal.pid)
          assert Ipse.Test.ManagementDisplayProbe.gone?(hd(ids).pid)
        end

        for path <- paths, do: assert({:error, _} = Ipse.Runner.protected_lock(path))
        assert {_, 0} = System.cmd("kill", ["-CONT", Integer.to_string(reader)])

        if rest == ["cli-loss"] do
          send(effect, :continue)
          assert_receive {:DOWN, ^effect_ref, :process, _, _}, 10_000
        end

        for path <- paths do
          assert {:ok, lock} = Ipse.Test.ManagementDisplayProbe.acquire(path)
          assert :ok = Ipse.Runner.unlock(lock)
        end

        IO.puts(
          if(rest == ["cli-loss"],
            do: "\nMANAGEMENT_CLI_LOSS_WITH_LIVE_EFFECT_UNKNOWN_AND_RELEASED",
            else:
              "\nMANAGEMENT_ADMITTED_WRITE_OWNER_LOSS_UNKNOWN_FOUR_LOCKS_HELD_UNTIL_READER_EXIT"
          )
        )
      after
        System.cmd("kill", ["-CONT", Integer.to_string(reader)], stderr_to_stdout: true)
        System.cmd("kill", ["-KILL", Integer.to_string(reader)], stderr_to_stdout: true)
        System.cmd("kill", ["-CONT", Integer.to_string(guardian)], stderr_to_stdout: true)
        System.cmd("kill", ["-KILL", Integer.to_string(guardian)], stderr_to_stdout: true)
      end
    else
      assert {:closed, {:ok, receipt}} =
               Management.full_facts_display_candidate(
                 %{home: home},
                 cwd,
                 key,
                 "Forget selected synthetic claim"
               )

      assert receipt.facts_sha256 =~ ~r/\A[0-9a-f]{64}\z/
      assert receipt.display_sha256 =~ ~r/\A[0-9a-f]{64}\z/

      IO.puts(
        "\nMANAGEMENT_FULL_FACTS_DISPLAY_CLOSED #{receipt.facts_sha256} #{receipt.display_sha256} #{key}"
      )
    end
  end
end
