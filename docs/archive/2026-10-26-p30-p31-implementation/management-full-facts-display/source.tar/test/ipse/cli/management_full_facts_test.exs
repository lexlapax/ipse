defmodule Ipse.CLI.ManagementFullFactsTest do
  use ExUnit.Case, async: false
  alias Ipse.{JSON, Usage}
  @moduletag :native_sandbox
  @moduletag skip: if(:os.type() == {:unix, :linux}, do: false, else: "Linux native candidate")

  setup do
    root = Path.join(System.tmp_dir!(), "ipse-management-facts-wrapper-" <> Usage.id())
    File.mkdir!(root)
    File.chmod!(root, 0o700)
    on_exit(fn -> File.rm_rf!(root) end)
    driver = Path.join(root, "driver")

    assert {"", 0} =
             System.cmd(
               "rustc",
               ["--edition=2021", "-D", "warnings", "test/support/operator_pty.rs", "-o", driver],
               stderr_to_stdout: true
             )

    %{root: root, driver: driver}
  end

  @tag :management_facts_positive
  test "actual retained signed target renders complete exact management facts without granting input",
       c do
    {output, status} = run(c, "large")
    assert status == 0, output
    output = String.replace(output, "\r\n", "\n")

    assert [_, display, json, _challenge, facts_sha, display_sha, key] =
             Regex.run(
               ~r/(Retained management target at [0-9]+: signed deadline elapsed\. Original source availability and current-use eligibility are not checked\.\nReview the complete proposed facts below\. This confirmation applies only to this exact review\.\n(\{.*?\})\nType forget ([0-9a-f]{16}) to confirm, or anything else to cancel\.\n> )\nMANAGEMENT_FULL_FACTS_DISPLAY_CLOSED ([0-9a-f]{64}) ([0-9a-f]{64}) (note\.[0-9a-f]{64})/s,
               output
             )

    assert {:ok, facts} = JSON.decode_unique(json)
    assert JSON.digest([facts]) == facts_sha
    assert JSON.sha256(display) == display_sha
    assert facts["target"]["key"] == key
    assert facts["target"]["value"]["text"] == String.duplicate("\\\"", 200)
    assert facts["metadata"]["valid_until_ms"] < System.system_time(:millisecond)
    assert facts["context"]["management_epoch"] == 1
    assert facts["target"]["revision"] == 1
    assert facts["target"]["value"]["evidence"]["sources"] != []
  end

  @tag :management_facts_stale
  test "changed management epoch refuses before native protected display", c do
    {output, status} = run(c, "stale")
    assert status == 0, output
    assert output =~ "MANAGEMENT_STALE_EPOCH_REFUSED_BEFORE_DISPLAY"
    refute output =~ "Review the complete proposed facts"
  end

  defp run(c, mode) do
    home = Path.join(c.root, "case")
    File.mkdir!(home)

    paths =
      :code.get_path()
      |> Enum.reject(&(&1 == ~c"."))
      |> Enum.flat_map(&["-pa", List.to_string(&1)])

    System.cmd(
      c.driver,
      [System.find_executable("elixir"), "--erl", "+S 2:2"] ++
        paths ++ ["test/support/management_full_facts.exs", home, mode], stderr_to_stdout: true)
  end
end
