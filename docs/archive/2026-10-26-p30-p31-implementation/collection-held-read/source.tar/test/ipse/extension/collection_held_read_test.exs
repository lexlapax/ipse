defmodule Ipse.Extension.CollectionHeldReadTest do
  use ExUnit.Case, async: false
  alias Ipse.Extension.Collection
  alias Ipse.JSON

  @moduletag :collection_held_read

  setup do
    parent = Path.join(System.tmp_dir!(), "ipse-collection-held-read-" <> Ipse.Usage.id())
    File.mkdir!(parent)
    File.chmod!(parent, 0o700)
    on_exit(fn -> File.rm_rf!(parent) end)
    c = %{root: Path.join(parent, "collections"), project: JSON.sha256("held read")}
    assert {:ok, _} = commit(c, 0, 0, "original")
    Map.put(c, :root_file, Path.join([c.root, c.project, "root.json"]))
  end

  defp commit(c, generation, revision, text) do
    Collection.execute(
      c.root,
      c.project,
      %{
        "op" => "commit",
        "expected_generation" => generation,
        "advance_floor" => false,
        "changes" => [
          %{"key" => "selected", "expected_revision" => revision, "value" => %{"text" => text}}
        ]
      },
      Ipse.Usage.id()
    )
  end

  test "the actual Collection owner stays locked across every observation and callback", c do
    before = File.read!(c.root_file)
    parent = self()

    task =
      Task.async(fn ->
        Collection.with_managed_read(c.root, c.project, fn witness, read ->
          assert {:ok, record} = read.("selected")
          assert record["revision"] == 1
          assert record["value"] == %{"text" => "original"}
          assert witness["root"]["generation"] == 1
          assert witness["root_bytes"] == before
          assert witness["root_sha256"] == JSON.sha256(before)
          refute Map.has_key?(witness, "operation_id")
          send(parent, {:held, self()})
          receive do: (:continue -> :ok)
          assert {:ok, ^record} = read.("selected")
          {:ok, record}
        end)
      end)

    assert_receive {:held, callback}, 5000
    assert {:error, _} = commit(c, 1, 1, "contender")
    assert File.read!(c.root_file) == before
    send(callback, :continue)
    assert {:ok, %{"value" => %{"text" => "original"}}} = Task.await(task, 5000)
    assert File.read!(c.root_file) == before
    assert {:ok, _} = commit(c, 1, 1, "later explicit change")
  end

  test "read closures refuse cross-process use, escape and nested writes", c do
    assert {:ok, read} =
             Collection.with_managed_read(c.root, c.project, fn _, read ->
               assert {:error, :managed_read_refused} =
                        Task.async(fn -> read.("selected") end) |> Task.await()

               assert {:error, :collection_lock_order} = commit(c, 1, 1, "nested")

               assert {:error, :collection_lock_order} =
                        Collection.with_managed_read(c.root, c.project, fn _, _ ->
                          flunk("reentry")
                        end)

               assert {:ok, %{"value" => %{"text" => "original"}}} = read.("selected")
               {:ok, read}
             end)

    assert {:error, :managed_read_refused} = read.("selected")

    assert {:ok, %{"record" => %{"value" => %{"text" => "original"}}}} =
             Collection.execute(
               c.root,
               c.project,
               %{"op" => "get", "key" => "selected"},
               Ipse.Usage.id()
             )
  end

  test "the shared 32-unit read allowance is sticky and invalidates a nominal success", c do
    before = File.read!(c.root_file)

    assert {:error, :managed_read_refused} =
             Collection.with_managed_read(c.root, c.project, fn _, read ->
               for _ <- 1..32, do: assert({:ok, _} = read.("selected"))
               assert {:error, :managed_read_refused} = read.("selected")
               assert {:error, :managed_read_refused} = read.("missing")
               {:ok, :must_not_escape}
             end)

    assert File.read!(c.root_file) == before
  end

  test "native owner death allows a fresh owner but prevents the old callback succeeding", c do
    parent = self()

    task =
      Task.async(fn ->
        Collection.with_managed_read(c.root, c.project, fn _, read ->
          assert {:ok, _} = read.("selected")
          cap = Process.get({Collection, :lock_held})
          {:os_pid, native} = Port.info(cap.port, :os_pid)
          send(parent, {:native, self(), native})
          receive do: (:continue -> :ok)
          assert {:error, :managed_read_refused} = read.("selected")
          {:ok, :old_snapshot}
        end)
      end)

    assert_receive {:native, callback, native}, 5000
    assert {_, 0} = System.cmd("kill", ["-KILL", Integer.to_string(native)])
    assert {:ok, _} = commit(c, 1, 1, "new owner")
    send(callback, :continue)
    assert {:unknown, :collection_lock_lost} = Task.await(task, 5000)
  end

  test "unknown callback outcomes stay typed and malformed callback outcomes refuse", c do
    before = File.read!(c.root_file)

    assert {:unknown, :synthetic_unconfirmed} =
             Collection.with_managed_read(c.root, c.project, fn _, _ ->
               {:unknown, :synthetic_unconfirmed}
             end)

    assert {:error, :managed_read_refused} =
             Collection.with_managed_read(c.root, c.project, fn _, _ -> :ok end)

    assert {:error, :invalid_collection_request} =
             Collection.with_managed_read(c.root, c.project, nil)

    assert File.read!(c.root_file) == before
  end
end
