defmodule Ipse.Extension.CollectionStoreSessionTest do
  use ExUnit.Case, async: false
  @moduletag :document_store_boundary
  alias Ipse.{Session, Journal, JSON, Usage}

  alias Ipse.Extension.{
    Artifact,
    Catalog,
    Config,
    Registry,
    ProjectIdentity,
    CollectionStore,
    Actions
  }

  alias Ipse.Extension.Collection
  alias Ipse.Extension.Collection.Profile

  defmodule NoModel do
    def complete(_, _, _, _), do: raise("storage fixture attempted inference")
  end

  setup_all do
    source = Path.join(System.tmp_dir!(), "ipse-document-store-artifact-" <> Usage.id())
    File.mkdir_p!(Path.join(source, "ebin"))
    on_exit(fn -> File.rm_rf!(source) end)
    name = "Independent.DocumentStore#{System.unique_integer([:positive])}"
    caps = ~w(invoke.command host.actions host.actions.mixed host.collection.store)

    exports =
      Map.put(Catalog.empty(), "commands", [
        %{
          "id" => "exercise",
          "description" => "Exercise bounded document storage",
          "arguments_schema" => %{"type" => "object"},
          "result_schema" => %{"type" => "object"}
        }
      ])

    code = """
    defmodule #{name} do
      @behaviour Ipse.Extension
      def describe, do: %{"sdk" => 1, "capabilities" => #{inspect(caps)}, "exports" => #{inspect(exports)}}
      def init(options), do: {:ok, options}
      def handle("invoke.command", payload, state) do
        bytes = Jason.encode!(%{"paragraphs" => for(n <- 1..9, do: Integer.to_string(n) <> ":" <> String.duplicate("x",4096))})
        epoch = Base.encode16(:crypto.strong_rand_bytes(16), case: :lower)
        state = Map.merge(state, %{"bytes" => bytes, "sha256" => hash(bytes), "epoch" => epoch,
          "step" => "open", "offset" => 0, "result" => "", "mode" => payload["arguments"]["mode"]})
        call(%{"op" => "snapshot"}, state)
      end
      def handle("host.actions", %{"outcome" => %{"status" => "ok", "value" => wrapped}}, state) do
        result = wrapped["result"]
        next(state["step"], result, Map.put(state,"generation",result["generation"]))
      end
      def handle("host.actions", %{"outcome" => outcome}, state), do: {:ok,%{"api_version" => 1,"kind" => "result", "value" => outcome},state}
      defp next("open", _, s) do
        call(%{"op" => "value.open", "slot" => 0, "epoch" => s["epoch"], "key" => "packed.fixture",
          "expected_revision" => 0, "byte_count" => byte_size(s["bytes"]), "sha256" => s["sha256"],
          "generation" => s["generation"]}, Map.put(s,"step","append"))
      end
      defp next("append", _, s) do
        offset = s["offset"]
        if offset < byte_size(s["bytes"]) do
          n = min(6144,byte_size(s["bytes"])-offset)
          call(%{"op" => "value.append", "slot" => 0, "epoch" => s["epoch"], "offset" => offset,
            "data" => binary_part(s["bytes"],offset,n), "generation" => s["generation"]}, Map.put(s,"offset",offset+n))
        else
          call(%{"op" => "value.seal", "slot" => 0, "epoch" => s["epoch"], "generation" => s["generation"]},Map.put(s,"step","commit"))
        end
      end
      defp next("commit", _, s) do
        call(%{"op" => "commit", "stages" => [%{"slot" => 0, "epoch" => s["epoch"]}],
          "generation" => s["generation"]},Map.put(s,"step","read"))
      end
      defp next("read", _, s), do: page(s,0)
      defp next("page", result, s) do
        s = Map.put(s,"result",s["result"]<>result["data"])
        if result["next"] do
          page(s,result["next"])
        else
          {:ok,%{"api_version" => 1,"kind" => "result", "value" => %{"equal" => s["result"]===s["bytes"],
            "sha256" => hash(s["result"]), "byte_count" => byte_size(s["result"])}},s}
        end
      end
      defp page(s,offset), do: call(%{"op" => "value.read", "key" => "packed.fixture", "offset" => offset,
        "generation" => s["generation"]},Map.put(s,"step","page"))
      defp call(inner,state), do: {:ok,%{"api_version" => 1,"kind" => "host_call",
        "request" => %{"op" => "collection.store","scope" => "project","request" => inner}},state}
      defp hash(bytes), do: Base.encode16(:crypto.hash(:sha256,bytes),case: :lower)
    end
    """

    path = Path.join(source, "fixture.ex")
    File.write!(path, code)

    assert {"", 0} =
             System.cmd(
               System.find_executable("elixirc"),
               [
                 "--erl",
                 "+S 2:2",
                 "-pa",
                 Application.app_dir(:ipse, "ebin"),
                 "-pa",
                 Application.app_dir(:jason, "ebin"),
                 "-o",
                 Path.join(source, "ebin"),
                 path
               ],
               stderr_to_stdout: true
             )

    File.rm!(path)
    File.write!(Path.join(source, "LICENSE"), "MIT synthetic fixture")

    files =
      for path <- ["LICENSE", "ebin/Elixir.#{name}.beam"] do
        bytes = File.read!(Path.join(source, path))
        %{"path" => path, "bytes" => byte_size(bytes), "sha256" => JSON.sha256(bytes)}
      end

    File.write!(
      Path.join(source, "extension.json"),
      Jason.encode!(%{
        "format" => 1,
        "id" => "fixture/document-store",
        "version" => "0.1.0",
        "sdk" => 1,
        "protocol" => 1,
        "backend" => "elixir_worker",
        "entrypoint" => name,
        "license_file" => "LICENSE",
        "files" => files,
        "capabilities" => caps,
        "exports" => exports,
        "options_schema" => %{"type" => "object"},
        "runtime" => %{
          "elixir" => ">= 1.18.0",
          "otp" => [String.to_integer(System.otp_release())],
          "platforms" => [to_string(:erlang.system_info(:system_architecture))]
        }
      })
    )

    %{source: source}
  end

  defp open(c, options \\ []) do
    dir = Path.join(System.tmp_dir!(), "ipse-document-store-session-" <> Usage.id())
    home = Path.join(dir, "home")
    cwd = Path.join(dir, "workspace")
    File.mkdir_p!(home)
    File.mkdir!(cwd)
    File.chmod!(home, 0o700)
    on_exit(fn -> File.rm_rf!(dir) end)
    {:ok, artifact} = Artifact.import(c.source, Path.join(home, "extensions/artifacts"))

    trust = %{
      "artifact" => artifact.digest,
      "capabilities" => artifact.manifest["capabilities"],
      "allow_project" => false,
      "allow_children" => false,
      "collection_bindings" => [
        %{
          "instance" => "documents",
          "version" => 1,
          "id" => "documents",
          "scope" => "project",
          "profile" => Profile.documents()
        }
      ]
    }

    data = %{
      "extensions" => [
        %{
          "instance" => "documents",
          "artifact" => artifact.digest,
          "enabled" => true,
          "options" => %{},
          "order" => 0,
          "lifetime" => "session"
        }
      ],
      "extension_trust" => [trust]
    }

    {:ok, selected} =
      Config.resolve([%{scope: "operator", path: "/fixture/config.json", data: data}], [])

    {:ok, entries} = Registry.prepare(selected, home)

    binding =
      if Keyword.get(options, :admit, true),
        do: elem(ProjectIdentity.admit(home, cwd, :folder), 1)

    config = %{
      provider: :demo,
      provider_module: NoModel,
      model: "synthetic",
      home: home,
      extensions: entries,
      approval: Keyword.get(options, :approval, :ask),
      approval_origin: :interactive,
      headless: false,
      compact: false
    }

    opts = [config: config, cwd: cwd, state_dir: Path.join(home, "sessions"), subscriber: self()]
    assert {:ok, pid} = DynamicSupervisor.start_child(Ipse.Sessions, {Session, opts})
    on_exit(fn -> if Process.alive?(pid), do: Session.close_confirmed(pid) end)

    %{
      pid: pid,
      id: Session.info(pid).id,
      opts: opts,
      dir: opts[:state_dir],
      home: home,
      binding: binding,
      data: data
    }
  end

  defp wait(run, approvals \\ 0, allow_refusal \\ false) do
    receive do
      {:ipse, pid, {:approval, ref, "extension:collection.store", proposed}}
      when pid == run.pid ->
        assert CollectionStore.validate(proposed["request"]) == :ok
        assert proposed["effect_binding"]["project"] === run.binding
        assert proposed["effect_binding"]["profile"] == Profile.documents()
        assert :ok = Session.approve(pid, ref, true)
        wait(run, approvals + 1, allow_refusal)

      {:ipse, pid, {:done, :ok}} when pid == run.pid ->
        {Session.info(pid).extension_result, approvals}

      {:ipse, pid, {:error, error}} when pid == run.pid ->
        {:ok, events} = Journal.load(run.dir, run.id)

        trace =
          for event <- events,
              event["type"] in ~w(extension_action_intent extension_action_result extension_invocation_result),
              do:
                {event["type"], get_in(event, ["request", "request", "op"]),
                 get_in(event, ["outcome", "status"]), get_in(event, ["outcome", "value"])}

        if allow_refusal,
          do: {nil, approvals},
          else:
            flunk(
              "document store error: #{inspect({error, trace}, limit: :infinity, printable_limit: 2000)}"
            )

      {:ipse, pid, _} when pid == run.pid ->
        wait(run, approvals, allow_refusal)
    after
      20_000 -> flunk("document store timed out")
    end
  end

  @tag :document_decision_session
  test "actual Session transports every bounded part, asks full mutation arguments and reconstructs exact large value",
       c do
    run = open(c)
    assert :ok = Session.invoke_export(run.pid, :command, "ext__documents__exercise", %{})
    {result, approvals} = wait(run)
    assert result["value"]["equal"] == true, inspect(result)
    assert result["value"]["byte_count"] > 32_768
    assert approvals == 10
    id = Session.info(run.pid).id
    {:ok, events} = Journal.load(run.dir, id)
    actions = Enum.filter(events, &(&1["type"] == "extension_action_result"))
    assert length(actions) > 16
    assert Enum.all?(actions, &Actions.valid_result?/1)
    assert Enum.all?(actions, &(Ipse.Extension.validate(Actions.resume(&1)) == :ok))
    assert Enum.count(actions, &(get_in(&1, ["request", "request", "op"]) == "value.append")) == 7
    assert Enum.all?(actions, &(&1["approval"] != "saved_consent"))
    namespace = CollectionStore.namespace(run.binding["project_id"])

    assert {:ok, %{"record" => nil}} =
             Collection.execute_profile(
               CollectionStore.root(run.home),
               namespace,
               %{"op" => "get", "key" => "host.stage.0.header"},
               Usage.id(),
               Profile.documents()
             )

    assert {:ok, _} = Session.Saved.restore(events, id)
  end

  test "ordinary denial never initializes document storage and no identity is silently admitted",
       c do
    for opts <- [[approval: :deny], [admit: false]] do
      run = open(c, opts)
      assert :ok = Session.invoke_export(run.pid, :command, "ext__documents__exercise", %{})
      {result, approvals} = wait(run, 0, true)
      assert approvals == 0
      refute get_in(result || %{}, ["value", "equal"])
      assert Path.wildcard(Path.join(CollectionStore.root(run.home), "*/root.json")) == []

      if opts[:admit] == false,
        do: assert({:ok, nil} = ProjectIdentity.existing(run.home, run.opts[:cwd]))
    end
  end

  test "store capability requires its separate operator grant and read namespace binding", c do
    run = open(c)
    [trust] = run.data["extension_trust"]
    data = Map.put(run.data, "extension_trust", [Map.delete(trust, "collection_bindings")])

    assert {:ok, selected} =
             Config.resolve([%{scope: "operator", path: "/fixture/config.json", data: data}], [])

    assert {:error, _} = Registry.prepare(selected, run.home)

    invalid =
      put_in(
        run.data,
        ["extension_trust", Access.at(0), "collection_bindings", Access.at(0), "profile"],
        "notes-v1"
      )

    assert {:error, _} =
             Config.resolve(
               [%{scope: "operator", path: "/fixture/config.json", data: invalid}],
               []
             )

    request = %{
      "op" => "collection.store",
      "scope" => "project",
      "request" => %{"op" => "snapshot"}
    }

    [entry] = run.opts[:config][:extensions]

    assert {:ok, binding} =
             CollectionStore.prepare(run.home, run.opts[:cwd], entry.identity, request, run.id)

    event = %{
      "request" => request,
      "effect_binding" => binding,
      "outcome" => %{
        "status" => "ok",
        "value" => %{"result" => %{"project" => binding["namespace"]}}
      }
    }

    assert CollectionStore.bound_outcome?(event)

    refute CollectionStore.bound_outcome?(
             put_in(event, ["outcome", "value", "result", "project"], JSON.sha256("other"))
           )

    assert {:error, :document_store_refused} =
             CollectionStore.prepare(
               run.home,
               run.opts[:cwd],
               Map.delete(entry.identity, "collection_binding"),
               request,
               run.id
             )
  end

  test "native publication uncertainty reaches the actual journal as unknown and resume does not replay",
       c do
    run = open(c)
    id = Session.info(run.pid).id
    handler = "document-store-unknown-" <> Usage.id()
    owner = self()

    assert :ok =
             :telemetry.attach(
               handler,
               [:ipse, :extension, :collection, :staged],
               fn _, _, metadata, _ ->
                 if metadata.generation == 2 do
                   cap = Process.get({Collection, :lock_held})
                   Port.close(cap.port)
                   send(owner, :document_native_lost)
                 end
               end,
               nil
             )

    on_exit(fn -> :telemetry.detach(handler) end)
    assert :ok = Session.invoke_export(run.pid, :command, "ext__documents__exercise", %{})
    {_, _} = wait(run, 0, true)
    assert_receive :document_native_lost
    :telemetry.detach(handler)
    {:ok, before} = Journal.load(run.dir, id)
    results = Enum.filter(before, &(&1["type"] == "extension_action_result"))
    assert get_in(List.last(results), ["outcome", "status"]) == "unknown"
    assert get_in(List.last(results), ["request", "request", "op"]) == "value.append"
    refute Enum.any?(results, &(get_in(&1, ["request", "request", "op"]) == "value.seal"))
    if Process.alive?(run.pid), do: assert(:ok = Session.close_confirmed(run.pid))

    files = fn ->
      Path.wildcard(Path.join(CollectionStore.root(run.home), "**/*"), match_dot: true)
      |> Enum.filter(&File.regular?/1)
      |> Map.new(&{&1, JSON.sha256(File.read!(&1))})
    end

    retained = files.()

    assert {:ok, resumed} =
             DynamicSupervisor.start_child(
               Ipse.Sessions,
               {Session, Keyword.put(run.opts, :id, id)}
             )

    assert :ok = Session.close_confirmed(resumed)
    assert {:ok, ^before} = Journal.load(run.dir, id)
    assert files.() == retained
  end
end
