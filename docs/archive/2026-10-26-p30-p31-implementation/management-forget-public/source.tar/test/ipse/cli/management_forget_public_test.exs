defmodule Ipse.CLI.ManagementForgetPublicTest do
  use ExUnit.Case, async: true
  alias Ipse.CLI.Knowledge.Management

  test "public forget refuses denied, headless and narrowed modes before touching storage" do
    root = Path.join(System.tmp_dir!(), "ipse-public-forget-mode-" <> Ipse.Usage.id())
    config = %{home: root, headless: false, approval: :ask, approval_origin: :interactive}
    key = "note." <> Ipse.JSON.sha256("synthetic public forget target")

    for extra <- [
          %{approval: :deny},
          %{headless: true},
          %{approval_origin: :yes},
          %{execution_mode: :read_only},
          %{execution_mode: :planning},
          %{execution_mode: :draft},
          %{enclosing_mode: :planning}
        ] do
      assert {:error, :knowledge_management_refused} =
               Management.forget(Map.merge(config, extra), root, key)

      refute File.exists?(root)
    end
  end

  test "public retention choices remain fenced" do
    key = "note." <> Ipse.JSON.sha256("synthetic public retention target")

    assert {:error, :native_review_publication_fence_unavailable} =
             Management.retain(%{}, "/", key, %{"kind" => "session"})

    for policy <- [
          %{"kind" => "pin"},
          %{"kind" => "ordinary"},
          %{"kind" => "duration", "duration_ms" => 86_400_000}
        ] do
      assert {:error, :collection_deadline_fence_unavailable} =
               Management.retain(%{}, "/", key, policy)
    end
  end
end
