defmodule Ipse.Runner.Review do
  @moduledoc """
  Native terminal review with an owner-bound, one-use consumption permit.

  This internal host primitive observes exact terminal input; it grants no
  effect permission, source truth or current storage authority. Its trusted
  caller must supply the complete proposed facts, release all locks before
  review, and revalidate those facts and authority under the effect's locks
  before consuming. No worker/SDK or serialized-observation constructor exists.
  """
  alias Ipse.{JSON, Runner, Session.Resources}
  @slot {__MODULE__, :permit}
  @lifetime 30_000
  @facts_bytes 16_384
  @display_bytes 65_536
  @error {:error, :native_review_refused}
  @unknown {:unknown, :native_review_unconfirmed}

  defmodule Permit do
    @moduledoc false
    @enforce_keys [:owner, :ref]
    defstruct @enforce_keys

    defimpl Inspect do
      def inspect(_, _), do: "#NativeReview<private>"
    end
  end

  @doc "Observe a fresh exact command/challenge, then enter a bounded host callback without holding terminal IO locks."
  def with_review(command, facts, fun), do: with_review(command, facts, fun, nil)

  @doc false
  def with_review(command, facts, fun, guard)
      when is_function(fun, 1) and (is_nil(guard) or is_function(guard, 1)) do
    review(command, facts, fun, guard, :direct)
  end

  def with_review(_, _, _, _), do: @error

  # The coordinator is an internal Host task, never a worker-supplied PID or
  # observation. It accepts only the tracked publication peer and one fresh
  # ticket, and performs the actual native input in an owned cleanup scope.
  @doc false
  def with_coordinated_review(command, facts, fun, guard, {coordinator, ticket})
      when is_function(fun, 1) and is_function(guard, 1) and is_pid(coordinator) and
             node(coordinator) == node() and is_reference(ticket) do
    review(command, facts, fun, guard, {:coordinator, coordinator, ticket})
  end

  def with_coordinated_review(_, _, _, _, _), do: @error

  # This entry accepts only the live, same-process handle produced by the
  # retained native management display, never a serialized observation.
  @doc false
  def with_management_input(command, facts, handle, fun) when is_function(fun, 1) do
    with true <- command === "forget",
         true <- is_nil(Process.get(@slot)),
         true <- valid?(command, facts) and Resources.active?(),
         upstream when is_pid(upstream) <- Resources.file_effect_owner(),
         true <- Process.alive?(upstream),
         scope = Resources.current(),
         {:ok, observation, challenge, deadline} <-
           Ipse.Runner.ManagementTerminal.finish_review(handle, facts),
         observed_at = System.system_time(:millisecond),
         input = command <> " " <> challenge,
         true <- JSON.safe_uint?(observed_at),
         true <- observation["text"] === input,
         true <- Ipse.Session.Input.valid_observation?(Map.delete(observation, "text"), input, 2),
         true <-
           Resources.current() === scope and Resources.active?() and Process.alive?(upstream),
         true <- now() < deadline do
      receipt = %{
        "version" => 1,
        "kind" => "native_review",
        "command" => command,
        "event_id" => observation["event_id"],
        "display_sha256" => observation["display_sha256"],
        "challenge" => challenge,
        "input_sha256" => observation["text_sha256"],
        "observed_at_ms" => observed_at,
        "facts_sha256" => JSON.digest([facts])
      }

      enter(command, facts, receipt, upstream, scope, deadline, fun)
    else
      {:unknown, _} -> @unknown
      _ -> @error
    end
  rescue
    _ -> @error
  catch
    _, _ -> @error
  end

  def with_management_input(_, _, _, _), do: @error

  defp review(command, facts, fun, guard, input_source) do
    with true <- is_nil(Process.get(@slot)),
         true <- valid?(command, facts) and Resources.active?(),
         upstream = Resources.file_effect_owner(),
         true <- is_pid(upstream) and Process.alive?(upstream),
         scope = Resources.current(),
         challenge = Base.encode16(:crypto.strong_rand_bytes(8), case: :lower),
         input = command <> " " <> challenge,
         display = display(command, facts, challenge),
         true <- byte_size(display) <= @display_bytes,
         {:ok, observation} <- review_input(display, guard, input_source),
         observed_at = System.system_time(:millisecond),
         deadline = now() + @lifetime,
         true <- JSON.safe_uint?(observed_at),
         true <- observation["text"] === input,
         true <-
           Ipse.Session.Input.valid_observation?(Map.delete(observation, "text"), input, 2),
         true <- observation["display_sha256"] == JSON.sha256(display),
         true <- Resources.current() === scope and Resources.active?(),
         true <- Process.alive?(upstream),
         true <- now() < deadline do
      receipt = %{
        "version" => 1,
        "kind" => "native_review",
        "command" => command,
        "event_id" => observation["event_id"],
        "display_sha256" => observation["display_sha256"],
        "challenge" => challenge,
        "input_sha256" => observation["text_sha256"],
        "observed_at_ms" => observed_at,
        "facts_sha256" => JSON.digest([facts])
      }

      enter(command, facts, receipt, upstream, scope, deadline, fun)
    else
      {:unknown, _} -> @unknown
      _ -> @error
    end
  rescue
    _ -> @error
  catch
    _, _ -> @error
  end

  defp review_input(display, nil, :direct), do: Runner.operator_input(display, 120_000, 2)

  defp review_input(display, guard, :direct),
    do: Runner.operator_input(display, 120_000, 2, guard)

  defp review_input(display, guard, {:coordinator, coordinator, ticket}) do
    monitor = Process.monitor(coordinator)
    deadline = now() + 130_000
    send(coordinator, {:managed_review_input, ticket, self(), display, guard})

    try do
      receive do
        {:managed_review_guard_authority, ^ticket, ^coordinator, secret}
        when is_reference(secret) ->
          coordinated_guard(display, guard, coordinator, ticket, secret, monitor, deadline)

        {:managed_review_result, ^ticket, ^coordinator, {:unknown, _} = result} ->
          result

        {:managed_review_result, ^ticket, ^coordinator, {:error, _} = result} ->
          result

        {:DOWN, ^monitor, :process, ^coordinator, _} ->
          @unknown
      after
        max(deadline - now(), 0) -> @unknown
      end
    after
      Process.demonitor(monitor, [:flush])
    end
  end

  defp coordinated_guard(_display, guard, coordinator, ticket, secret, coordinator_ref, deadline) do
    receive do
      {:managed_review_guard, ^ticket, ^secret, child, guard_ref}
      when is_pid(child) and node(child) == node() and is_reference(guard_ref) ->
        child_ref = Process.monitor(child)
        owner = self()
        used = :atomics.new(1, [])

        continuation = fn wall ->
          if self() == owner and :atomics.compare_exchange(used, 1, 0, 1) == :ok do
            send(child, {:managed_review_deadline, ticket, owner, guard_ref, wall})

            result =
              receive do
                {:managed_review_displayed, ^ticket, ^child, ^guard_ref, result} -> result
                {:DOWN, ^child_ref, :process, ^child, _} -> @unknown
                {:DOWN, ^coordinator_ref, :process, ^coordinator, _} -> @unknown
              after
                max(deadline - now(), 0) -> @unknown
              end

            if result === :ok, do: :atomics.put(used, 1, 2)
            result
          else
            :atomics.put(used, 1, 3)
            @error
          end
        end

        guard_result =
          try do
            guard.(continuation)
          rescue
            _ -> @error
          catch
            _, _ -> @error
          end

        accepted = guard_result === :ok and :atomics.get(used, 1) == 2
        :atomics.put(used, 1, 3)
        release = if accepted, do: :ok, else: @error
        send(child, {:managed_review_release, ticket, owner, guard_ref, release})
        Process.demonitor(child_ref, [:flush])

        receive do
          {:managed_review_result, ^ticket, ^coordinator, result} ->
            cond do
              match?({:unknown, _}, guard_result) -> @unknown
              accepted or match?({:unknown, _}, result) -> result
              true -> @error
            end

          {:DOWN, ^coordinator_ref, :process, ^coordinator, _} ->
            @unknown
        after
          max(deadline - now(), 0) -> @unknown
        end

      {:managed_review_result, ^ticket, ^coordinator, {:unknown, _} = result} ->
        result

      {:managed_review_result, ^ticket, ^coordinator, {:error, _} = result} ->
        result

      {:DOWN, ^coordinator_ref, :process, ^coordinator, _} ->
        @unknown
    after
      max(deadline - now(), 0) -> @unknown
    end
  end

  @doc "Check an exact live review before reserving its bounded effect; does not consume permission."
  def check(permit, command, facts) do
    with {:ok, _} <- pending(permit, command, facts, :available), do: :ok
  end

  @doc "Return the actual consumed review only to its same live owner and exact facts."
  def consumed_receipt(permit, command, facts) do
    with {:ok, pending} <- pending(permit, command, facts, :consumed),
         do: {:ok, pending.receipt}
  end

  defp pending(%Permit{owner: owner, ref: ref}, command, facts, status) when owner == self() do
    case Process.get(@slot) do
      %{ref: ^ref, status: ^status} = pending ->
        if command === pending.command and facts === pending.facts and live?(pending),
          do: {:ok, pending},
          else: @error

      _ ->
        @error
    end
  end

  defp pending(_, _, _, _), do: @error

  @doc "Consume once against the exact revalidated facts, before attempting the bound effect."
  def consume(%Permit{owner: owner, ref: ref}, command, facts) when owner == self() do
    case Process.get(@slot) do
      %{ref: ^ref, status: :available} = pending ->
        # A real owner's first attempt spends the permit even when its facts
        # changed. It cannot silently rebase to another target or retry a write.
        Process.put(@slot, %{pending | status: :refused})

        if command === pending.command and facts === pending.facts and live?(pending) do
          Process.put(@slot, %{pending | status: :consumed})
          {:ok, pending.receipt}
        else
          @error
        end

      _ ->
        @error
    end
  end

  def consume(_, _, _), do: @error

  defp enter(command, facts, receipt, upstream, scope, deadline, fun) do
    ref = make_ref()

    pending = %{
      ref: ref,
      status: :available,
      command: command,
      facts: facts,
      receipt: receipt,
      upstream: upstream,
      scope: scope,
      deadline: deadline
    }

    Process.put(@slot, pending)

    try do
      result = fun.(%Permit{owner: self(), ref: ref})

      case Process.get(@slot) do
        %{ref: ^ref, status: :consumed} = current ->
          if (result === :ok or match?({:ok, _}, result)) and live?(current),
            do: result,
            else: @unknown

        %{ref: ^ref, status: :available} ->
          if match?({:error, _}, result), do: result, else: @error

        _ ->
          @error
      end
    rescue
      _ -> interrupted()
    catch
      _, _ -> interrupted()
    after
      Process.delete(@slot)
    end
  end

  defp interrupted do
    case Process.get(@slot) do
      %{status: :consumed} -> @unknown
      _ -> @error
    end
  end

  defp live?(pending) do
    remaining = pending.deadline - now()

    remaining > 0 and Process.alive?(pending.upstream) and
      Resources.current() === pending.scope and Resources.active?(min(remaining, 5_000)) and
      now() < pending.deadline and Process.alive?(pending.upstream) and
      Resources.current() === pending.scope
  end

  defp valid?(command, facts),
    do:
      is_binary(command) and Regex.match?(~r/\A[a-z][a-z0-9_-]{0,31}\z/, command) and
        is_map(facts) and map_size(facts) > 0 and JSON.validate_object(facts) == :ok and
        byte_size(Jason.encode!(facts)) <= @facts_bytes

  # Private rendering candidate only. A generated challenge is not an input
  # observation or a Review permit, and callers must not treat it as one.
  @doc false
  def preview_display(command, facts) do
    with true <- valid?(command, facts),
         challenge = Base.encode16(:crypto.strong_rand_bytes(8), case: :lower),
         display = display(command, facts, challenge),
         true <- byte_size(display) <= @display_bytes do
      {:ok, display, challenge}
    else
      _ -> {:error, :review_unavailable}
    end
  rescue
    _ -> {:error, :review_unavailable}
  end

  @doc false
  def preview_management_display(command, facts, checked_at)
      when is_integer(checked_at) and checked_at >= 0 do
    with {:ok, body, challenge} <- preview_display(command, facts),
         deadline <- get_in(facts, ["metadata", "valid_until_ms"]),
         true <- is_nil(deadline) or (is_integer(deadline) and deadline >= 0),
         status =
           (cond do
              is_nil(deadline) -> "no signed deadline"
              deadline <= checked_at -> "signed deadline elapsed"
              true -> "signed deadline not yet elapsed"
            end),
         label =
           "Retained management target at #{checked_at}: #{status}. Original source availability and current-use eligibility are not checked.\n",
         display = label <> body,
         true <- byte_size(display) <= @display_bytes do
      {:ok, display, challenge}
    else
      _ -> {:error, :review_unavailable}
    end
  end

  def preview_management_display(_, _, _), do: {:error, :review_unavailable}

  defp display(command, facts, challenge) do
    Ipse.CLI.Terminal.escape(
      "Review the complete proposed facts below. This confirmation applies only to this exact review.\n" <>
        Jason.encode!(facts, pretty: true) <>
        "\nType #{command} #{challenge} to confirm, or anything else to cancel.\n> "
    )
  end

  defp now, do: System.monotonic_time(:millisecond)
end
