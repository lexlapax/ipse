[destination] = System.argv()
false = File.exists?(destination)
File.mkdir_p!(destination)
Process.flag(:max_heap_size, %{size: 16_000_000, kill: true, error_logger: true})
started = System.monotonic_time(:millisecond)
spawn_link(fn ->
  Process.sleep(30_000)
  File.write!(Path.join(destination, "deadline-failure.txt"), "30-second acquisition guard\n")
  System.halt(124)
end)
spawn_link(fn ->
  Enum.each(1..600, fn _ ->
    Process.sleep(50)
    if :erlang.memory(:total) > 536_870_912, do: System.halt(137)
  end)
end)

fetch = fn url, basename, limit ->
  request = Finch.build(:get, url, [{"accept", if(basename == "release.json", do: "application/json", else: "application/octet-stream")}])
  case Ipse.HTTP.bounded_request(request, limit, 10_000) do
    {:ok, 200, body} ->
      File.write!(Path.join(destination, basename), body, [:exclusive])
      body
    other ->
      File.write!(Path.join(destination, basename <> ".failure.txt"), inspect(other, limit: 8, printable_limit: 256))
      raise "bounded TLS acquisition failed for #{basename}"
  end
end

archive = fetch.("https://repo.hex.pm/tarballs/msgpax-2.4.0.tar", "msgpax-2.4.0.tar", 65_536)
metadata = fetch.("https://hex.pm/api/packages/msgpax/releases/2.4.0", "release.json", 16_384)
sha = fn bytes -> Base.encode16(:crypto.hash(:sha256, bytes), case: :lower) end
outer = "ca933891b0e7075701a17507c61642bf6e0407bb244040d5d0a58597a06369d2"
true = sha.(archive) == outer
true = Jason.decode!(metadata)["checksum"] == outer
{:ok, outer_files} = :erl_tar.extract({:binary, archive}, [:memory])
outer_files = Map.new(outer_files, fn {name, bytes} -> {List.to_string(name), bytes} end)
true = Enum.sort(Map.keys(outer_files)) == ["CHECKSUM", "VERSION", "contents.tar.gz", "metadata.config"]
inner = "4647575c87cb0c43b93266438242c21f71f196cafa268f45f91498541148c15d"
true = String.downcase(String.trim(outer_files["CHECKSUM"])) == inner
true = sha.(outer_files["VERSION"] <> outer_files["metadata.config"] <> outer_files["contents.tar.gz"]) == inner
{:ok, source_files} = :erl_tar.extract({:binary, outer_files["contents.tar.gz"]}, [:compressed, :memory])
true = length(source_files) in 1..32
true = Enum.sum(Enum.map(source_files, fn {_, bytes} -> byte_size(bytes) end)) <= 1_048_576
names = Enum.map(source_files, fn {name, _} -> List.to_string(name) end)
true = length(Enum.uniq(names)) == length(names)
true = Enum.all?(names, fn name -> Path.type(name) == :relative and Enum.all?(Path.split(name), &(&1 not in ["..", ".", ""])) end)
source = Path.join(destination, "source")
File.mkdir!(source)
for {name, bytes} <- source_files do
  path = Path.join(source, List.to_string(name))
  File.mkdir_p!(Path.dirname(path))
  File.write!(path, bytes, [:exclusive])
end
license = File.read!(Path.join(source, "LICENSE"))
true = sha.(license) == "d0cb97131715936f32c4eff82496903c97d921f4675f71b24821fdacb9dbaed4"
true = sha.(File.read!(Path.join(source, "mix.exs"))) == "e51d7daf1f4b5b8928ea83e0ef4f2e3d69b378e39a9eb3dca6bebac59df07538"
report = %{acquisition: "Ipse.HTTP.bounded_request/3 (Finch/Mint verified TLS defaults)", urls: ["https://repo.hex.pm/tarballs/msgpax-2.4.0.tar", "https://hex.pm/api/packages/msgpax/releases/2.4.0"], outer_sha256: outer, inner_sha256: inner, license_sha256: sha.(license), source_files: Enum.map(source_files, fn {name, bytes} -> %{name: List.to_string(name), bytes: byte_size(bytes), sha256: sha.(bytes)} end), elapsed_ms: System.monotonic_time(:millisecond) - started, package_code_executed: false, native_calls: 0, model_calls: 0, tls_verification_weakened: false, script_sha256: sha.(File.read!(__ENV__.file))}
File.write!(Path.join(destination, "acquisition.json"), Jason.encode!(report, pretty: true))
IO.puts("verified bounded TLS acquisition; #{length(source_files)} source files; no package code executed")
