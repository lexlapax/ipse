base = "/tmp/ipse-adaptive-proof-20261027-05"
pkg = "/tmp/ipse-msgpax-http-evaluation-20261027-03"
archive = "docs/archive/2026-10-26-p30-p31-implementation"
sha = fn bytes -> Base.encode16(:crypto.hash(:sha256, bytes), case: :lower) end
before = Jason.decode!(File.read!(base <> "/artifacts/freeze-before.json"))
after_files = Map.new(before["files"],fn {p,_}->{p,sha.(File.read!(p))} end)
true = after_files == before["files"]
File.write!(base<>"/artifacts/freeze-after.json",Jason.encode!(%{count: map_size(after_files), files: after_files, unchanged: true},pretty: true))
sources = Path.wildcard("dev/knowledge/managed_metadata_adaptive*.ex*") ++ ["test/dev/managed_metadata_adaptive_test.exs"]
true = length(sources) == 6
for p<-sources, do: true = File.read!(p) == File.read!(base<>"/project/"<>p)
for p<-sources, do: File.cp!(p,base<>"/artifacts/"<>Path.basename(p))
for p<-[__ENV__.file,"/tmp/ipse-adaptive-batch-http-20261027.exs","/tmp/ipse-adaptive-controls-20261027.exs","/tmp/ipse-adaptive-aggregate-20261027.exs","/tmp/ipse-adaptive-strict-20261027-05.exs","/tmp/ipse-adaptive-format118-20261027.exs"], do: File.cp!(p,base<>"/artifacts/"<>Path.basename(p))
groups = for n<-1..5 do
 root="/tmp/ipse-adaptive-proof-20261027-"<>String.pad_leading(Integer.to_string(n),2,"0")
 {"proof#{n}",Path.wildcard(root<>"/artifacts/**/*") |> Enum.filter(&File.regular?/1), root<>"/artifacts"}
end
groups = groups ++ [{"prototype",Path.wildcard(base<>"/strict-prototype-beams/*.beam"),base<>"/strict-prototype-beams"},{"package-http", Path.wildcard(pkg<>"/**/*") |> Enum.filter(&File.regular?/1),pkg},{"package-curl-diagnostic",Path.wildcard("/tmp/ipse-msgpax-evaluation-20261027-01/download/*") ++ ["/tmp/ipse-msgpax-evaluation-20261027-01/inspection-compile.log"],"/tmp/ipse-msgpax-evaluation-20261027-01"}]
groups = groups ++ for n<-1..2 do
 root="/tmp/ipse-msgpax-http-evaluation-20261027-"<>String.pad_leading(Integer.to_string(n),2,"0")
 {"http-refusal#{n}",Path.wildcard(root<>"/**/*") |> Enum.filter(&File.regular?/1),root}
end
extra=Path.wildcard("/tmp/ipse-adaptive-empty-sentinel-negative-20261027.*")
groups=groups++[{"negative-sentinel",extra,"/tmp"}]
members = for {label,paths,root}<-groups,p<-Enum.sort(paths) do
 name=label<>"/"<>Path.relative_to(p,root)
 true=not String.contains?(name,"..")
 bytes=File.read!(p)
 {name,p,bytes}
end
true=length(Enum.uniq_by(members,&elem(&1,0)))==length(members)
tar=archive<>"/managed-adaptive-proof-evidence.tar.gz"
:ok=:erl_tar.create(String.to_charlist(tar),Enum.map(members,fn {name,_,bytes}->{String.to_charlist(name),bytes} end),[:compressed])
manifest=%{kind: "pure_adaptive_stage1_artifacts",actual_publications: 0,native_calls: 0,model_calls: 0,qualification_passed: false,final_freeze_files_unchanged: map_size(after_files),sources: Enum.map(sources,fn p->%{path: p,bytes: File.stat!(p).size,sha256: sha.(File.read!(p))} end),bundle: %{path: tar,bytes: File.stat!(tar).size,sha256: sha.(File.read!(tar))},members: Enum.map(members,fn {name,p,bytes}->%{member: name,original_location: p,bytes: byte_size(bytes),sha256: sha.(bytes)} end),summary: Jason.decode!(File.read!(base<>"/artifacts/summary.json")),controls: Jason.decode!(File.read!(base<>"/artifacts/control-summary.json")),acquisition: Jason.decode!(File.read!(pkg<>"/acquisition.json"))}
File.write!(archive<>"/managed-adaptive-proof-artifacts.json",Jason.encode!(manifest,pretty: true))
IO.puts("#{length(members)} preserved artifacts, #{File.stat!(tar).size} compressed bytes, #{map_size(after_files)} unchanged bindings")
