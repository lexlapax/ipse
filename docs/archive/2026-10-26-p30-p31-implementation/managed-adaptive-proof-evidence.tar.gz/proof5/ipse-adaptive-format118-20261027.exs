true = System.version() == "1.18.5"
files = Path.wildcard("dev/knowledge/managed_metadata_adaptive*.ex*") ++ ["test/dev/managed_metadata_adaptive_test.exs"]
failed = Enum.filter(files, fn path -> File.read!(path) != IO.iodata_to_binary(Code.format_file!(path)) end)
IO.inspect(%{version: System.version(), files: length(files), differences: failed})
if failed != [], do: System.halt(1)
