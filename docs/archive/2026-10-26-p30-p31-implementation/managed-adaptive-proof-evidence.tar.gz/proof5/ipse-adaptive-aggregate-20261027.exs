base = "/tmp/ipse-adaptive-proof-20261027-05"
dir = base <> "/artifacts"
plan = Jason.decode!(File.read!(dir <> "/jobs.json"))
reports = Map.new(plan["jobs"], fn input ->
  name = Enum.join(input, "-")
  p = dir <> "/" <> name <> ".json"
  r = Jason.decode!(File.read!(p))
  true = r["binding_before"] == r["binding_after"]
  true = r["result"]["full_row_and_range_roundtrip"]
  true = r["elapsed_ms"] < 30_000 and r["peak_sampled_memory_bytes"] <= 536_870_912
  true = Jason.decode!(File.read!(p <> ".exit.json"))["exit"] == 0
  {input, r}
end)
part = fn pop, kind, clock, ret, dict -> Map.fetch!(reports, [pop,kind,clock,ret,dict])["result"] end
msg_bytes = fn p -> Enum.sum(Enum.map(p["page_measurements"], & &1["comparison"]["msgpax_schema_value"])) end
cases = for pop <- ~w(frozen3460 year3642), kind <- ~w(anchor_full anchor_native_candidate), clock <- ~w(calendar_2026 safe_width bounded_fixture), ret <- ~w(none sticky_clock target_witness), dict <- ~w(shared distinct) do
  a = part.("year3642",kind,clock,ret,"shared")
  l = part.(pop,"live",clock,"none",dict)
  allowance = 24*1024*1024-l["rows"]*6144
  total = a["page_bytes"]+l["page_bytes"]+6144
  msg_total = msg_bytes.(a)+msg_bytes.(l)+6144
  %{population: pop,kind: kind,clock: clock,retirement: ret,dictionary: dict,anchors: a["rows"],notes: l["rows"],anchor_pages: a["pages"],live_pages: l["pages"],anchor_bytes: a["page_bytes"],live_bytes: l["page_bytes"],format_reserved: 6144,total: total,allowance: allowance,headroom: allowance-total,selected_packing_fits_accounting: total<=allowance,msgpax_total: msg_total,msgpax_headroom: allowance-msg_total,qualification_passed: false}
end
short = for pop <- ~w(days30 days90 fresh2000 fresh4000) do
 a = part.(pop,"anchor_native_candidate","calendar_2026","sticky_clock","shared")
 l = part.(pop,"live","calendar_2026","none","shared")
 allowance=24*1024*1024-l["rows"]*6144
 %{population: pop,notes: l["rows"],anchors: a["rows"],anchor_bytes: a["page_bytes"],live_bytes: l["page_bytes"],total: a["page_bytes"]+l["page_bytes"]+6144,allowance: allowance,headroom: allowance-a["page_bytes"]-l["page_bytes"]-6144,qualification_passed: false}
end
summary = %{kind: "pure_adaptive_stage1_measurements", page_jobs: map_size(reports), joined_original_controls: length(cases), cases: cases, short_cases: short, jobs: Enum.map(reports, fn {input,r}->%{input: input,elapsed_ms: r["elapsed_ms"],peak_sampled_memory_bytes: r["peak_sampled_memory_bytes"],pages: r["result"]["pages"],max_page_bytes: r["result"]["max_page_bytes"]} end), elapsed_range_ms: Enum.min_max(Enum.map(reports,fn {_,r}->r["elapsed_ms"] end)) |> Tuple.to_list(), peak_sampled_memory_bytes: Enum.max(Enum.map(reports,fn {_,r}->r["peak_sampled_memory_bytes"] end)), actual_publications: 0,native_calls: 0,model_calls: 0,qualification_passed: false}
File.write!(dir<>"/summary.json",Jason.encode!(summary,pretty: true))
for c<-cases,c.population=="year3642",c.kind=="anchor_native_candidate",c.retirement in ~w(sticky_clock target_witness), do: IO.inspect(c)
IO.inspect(short,label: "short populations")
