base = "/tmp/ipse-adaptive-proof-20261027-05"
pkg = "/tmp/ipse-msgpax-http-evaluation-20261027-03"
statuses = for {job, expected} <- [{"tests",0},{"msgpax_controls",0},{"deadline_control",124},{"model",0}] do
  output = base <> "/artifacts/" <> job <> ".json"
  false = File.exists?(output)
  argv = ["-pa",base <> "/build/lib/*/ebin","-pa",pkg<>"/build",base<>"/project/dev/knowledge/managed_metadata_adaptive_run.exs",job,output]
  {_, status} = System.cmd("elixir",argv,env: [{"ERL_FLAGS","+S 2:2"},{"HOME",pkg<>"/home"}],stderr_to_stdout: true,into: File.stream!(output<>".log"))
  File.write!(output<>".exit.json",Jason.encode!(%{expected: expected,exit: status,argv: argv}))
  IO.puts("#{job}: #{status} expected #{expected}")
  true = status == expected
  %{job: job,exit: status,expected: expected}
end
old = Jason.decode!(File.read!(base<>"/artifacts/model-input.json"))["result"]
new = Jason.decode!(File.read!(base<>"/artifacts/model.json"))["result"]
true = old == new
File.write!(base<>"/artifacts/control-summary.json",Jason.encode!(%{statuses: statuses,pure_model_results_equal_frozen_input: true,qualification_passed: false},pretty: true))
