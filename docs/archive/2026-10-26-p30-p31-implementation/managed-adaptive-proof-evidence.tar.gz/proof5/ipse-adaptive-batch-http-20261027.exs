[batch_text]=System.argv()
base="/tmp/ipse-adaptive-proof-20261027-05"
pkg="/tmp/ipse-msgpax-http-evaluation-20261027-03/build"
pilot=[
 ["year3642","anchor_native_candidate","calendar_2026","sticky_clock","shared"],
 ["year3642","anchor_full","calendar_2026","sticky_clock","shared"],
 ["year3642","live","calendar_2026","none","shared"],
 ["year3642","live","calendar_2026","none","distinct"],
 ["year3642","live","calendar_2026","none","catalog4"],
 ["year3642","live","calendar_2026","none","catalog8"]]
year=for kind<-~w(anchor_native_candidate anchor_full),clock<-~w(calendar_2026 safe_width bounded_fixture),retirement<-~w(none sticky_clock target_witness),do: ["year3642",kind,clock,retirement,"shared"]
live=for clock<-~w(calendar_2026 safe_width bounded_fixture),dict<-~w(shared distinct),do: ["year3642","live",clock,"none",dict]
short=for pop<-~w(days30 days90 fresh2000 fresh4000),kind<-~w(anchor_native_candidate live),do: [pop,kind,"calendar_2026",if(kind=="live",do: "none",else: "sticky_clock"),"shared"]
extras=[["frozen3460","live","calendar_2026","none","shared"],["year3642","anchor_native_candidate","four_safe_clocks","target_witness","shared"]]
frozen=for clock<-~w(calendar_2026 safe_width bounded_fixture),dict<-~w(shared distinct),do: ["frozen3460","live",clock,"none",dict]
jobs=Enum.uniq(pilot++year++live++short++extras++frozen)
plan=%{jobs: jobs,job_count: length(jobs),batch_width: 6,argv: "pages OUTPUT MODEL POPULATION KIND CLOCK RETIREMENT DICTIONARY msgpax",source_sha256: Base.encode16(:crypto.hash(:sha256,File.read!(__ENV__.file)),case: :lower)}
plan_file=base<>"/artifacts/jobs.json"
if File.exists?(plan_file),do: true=Jason.decode!(File.read!(plan_file))["jobs"]==jobs,else: File.write!(plan_file,Jason.encode!(plan,pretty: true))
batch=String.to_integer(batch_text)
true=batch in 1..div(length(jobs)+5,6)
statuses=Enum.map(Enum.slice(jobs,(batch-1)*6,6),fn input->
 name=Enum.join(input,"-")
 output=base<>"/artifacts/"<>name<>".json"
 true=not File.exists?(output)
 args=["-pa",base<>"/build/lib/*/ebin","-pa",pkg,base<>"/project/dev/knowledge/managed_metadata_adaptive_run.exs","pages",output,base<>"/artifacts/model-input.json"]++input++["msgpax"]
 {_,exit}=System.cmd("elixir",args,env: [{"ERL_FLAGS","+S 2:2"},{"HOME","/tmp/ipse-msgpax-http-evaluation-20261027-03/home"}],stderr_to_stdout: true,into: File.stream!(output<>".log"))
 row=%{input: input,argv: args,exit: exit}
 File.write!(output<>".exit.json",Jason.encode!(row,pretty: true))
 IO.puts("#{name}: #{exit}")
 if exit != 0,do: System.halt(1)
 row
end)
File.write!(base<>"/artifacts/batch#{batch}.json",Jason.encode!(statuses,pretty: true))
