base = "/tmp/ipse-adaptive-proof-20261027-05"
dir = base <> "/project/dev/knowledge"
Code.require_file(base <> "/project/extensions/knowledge/src/notes.ex")
for file <- ~w(managed_metadata.ex managed_metadata_shapes.exs managed_metadata_binary.ex managed_metadata_binary_shapes.exs storage_workload.ex) do
  Code.require_file(Path.join(dir, file))
end
out = base <> "/strict-prototype-beams"
File.mkdir!(out)
sources = Path.wildcard(dir <> "/managed_metadata_adaptive*.ex")
case Kernel.ParallelCompiler.compile_to_path(sources, out, return_diagnostics: true) do
  {:ok, modules, %{compile_warnings: [], runtime_warnings: []}} -> IO.puts("strict #{length(modules)} modules: no warnings")
  other -> IO.inspect(other); System.halt(1)
end
